var At=(e=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(e,{get:(t,r)=>(typeof require<"u"?require:t)[r]}):e)(function(e){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')});function Jf(e){let t=0;for(let r=0;r<e.length;r++)t+=e[r]*e[r];return Math.sqrt(t/e.length)}var ze=new Float32Array(0);function zs(e,t,r=.8,i=.008){if(Jf(e)<i)return null;let a=e.length,n=Math.min(Math.floor(t/70),a>>1),s=Math.max(2,Math.floor(t/1100));ze.length<n+1&&(ze=new Float32Array(n+1));for(let _=0;_<=n;_++){let S=0,k=0,T=a-_;for(let I=0;I<T;I++){let C=e[I],M=e[I+_];S+=C*M,k+=C*C+M*M}ze[_]=k>0?2*S/k:0}let d=[],l=1;for(;l<n&&ze[l]>0;)l++;let p=-1;for(;l<n;l++)ze[l]>0?ze[l]>ze[l-1]&&ze[l]>=ze[l+1]&&(p<0||ze[l]>ze[p])&&(p=l):p>=0&&(d.push(p),p=-1);if(p>=0&&d.push(p),!d.length)return null;let h=0;for(let _ of d)ze[_]>h&&(h=ze[_]);if(h<r)return null;let u=d.find(_=>ze[_]>=.9*h&&_>=s);if(u===void 0)return null;let m=ze[u-1],$=ze[u],f=ze[u+1],y=m-2*$+f,v=y!==0?.5*(m-f)/y:0,x=t/(u+v);return x<70||x>1100?null:{freq:x,clarity:$}}var Rs=e=>69+12*Math.log2(e/440);var Aa=Object.defineProperty,em=Object.getOwnPropertyDescriptor,tm=Object.getOwnPropertyNames,rm=Object.prototype.hasOwnProperty,im=(e=>typeof At<"u"?At:typeof Proxy<"u"?new Proxy(e,{get:(t,r)=>(typeof At<"u"?At:t)[r]}):e)(function(e){if(typeof At<"u")return At.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')}),F=(e,t)=>()=>(e&&(t=e(e=0)),t),pr=(e,t)=>{for(var r in t)Aa(e,r,{get:t[r],enumerable:!0})},am=(e,t,r,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of tm(t))!rm.call(e,a)&&a!==r&&Aa(e,a,{get:()=>t[a],enumerable:!(i=em(t,a))||i.enumerable});return e},Lr=e=>am(Aa({},"__esModule",{value:!0}),e),Zt,yt,qt,Os,za,Ra=F(()=>{"use strict";Zt=new Map,yt=[],qt=(e,t,r)=>{if(t&&typeof t.init=="function"&&typeof t.createInferenceSessionHandler=="function"){let i=Zt.get(e);if(i===void 0)Zt.set(e,{backend:t,priority:r});else{if(i.priority>r)return;if(i.priority===r&&i.backend!==t)throw new Error(`cannot register backend "${e}" using priority ${r}`)}if(r>=0){let a=yt.indexOf(e);a!==-1&&yt.splice(a,1);for(let n=0;n<yt.length;n++)if(Zt.get(yt[n]).priority<=r){yt.splice(n,0,e);return}yt.push(e)}return}throw new TypeError("not a valid backend")},Os=async e=>{let t=Zt.get(e);if(!t)return"backend not found.";if(t.initialized)return t.backend;if(t.aborted)return t.error;{let r=!!t.initPromise;try{return r||(t.initPromise=t.backend.init(e)),await t.initPromise,t.initialized=!0,t.backend}catch(i){return r||(t.error=`${i}`,t.aborted=!0),t.error}finally{delete t.initPromise}}},za=async e=>{let t=e.executionProviders||[],r=t.map(l=>typeof l=="string"?l:l.name),i=r.length===0?yt:r,a,n=[],s=new Set;for(let l of i){let p=await Os(l);typeof p=="string"?n.push({name:l,err:p}):(a||(a=p),a===p&&s.add(l))}if(!a)throw new Error(`no available backend found. ERR: ${n.map(l=>`[${l.name}] ${l.err}`).join(", ")}`);for(let{name:l,err:p}of n)r.includes(l)&&console.warn(`removing requested execution provider "${l}" from session options because it is not available: ${p}`);let d=t.filter(l=>s.has(typeof l=="string"?l:l.name));return[a,new Proxy(e,{get:(l,p)=>p==="executionProviders"?d:Reflect.get(l,p)})]}}),nm=F(()=>{"use strict";Ra()}),td,sm=F(()=>{"use strict";td="1.20.1"}),Ti,He,rd=F(()=>{"use strict";sm(),Ti="warning",He={wasm:{},webgl:{},webgpu:{},versions:{common:td},set logLevel(e){if(e!==void 0){if(typeof e!="string"||["verbose","info","warning","error","fatal"].indexOf(e)===-1)throw new Error(`Unsupported logging level: ${e}`);Ti=e}},get logLevel(){return Ti}},Object.defineProperty(He,"logLevel",{enumerable:!0})}),ge,om=F(()=>{"use strict";rd(),ge=He}),id,ad,um=F(()=>{"use strict";id=(e,t)=>{let r=typeof document<"u"?document.createElement("canvas"):new OffscreenCanvas(1,1);r.width=e.dims[3],r.height=e.dims[2];let i=r.getContext("2d");if(i!=null){let a,n;t?.tensorLayout!==void 0&&t.tensorLayout==="NHWC"?(a=e.dims[2],n=e.dims[3]):(a=e.dims[3],n=e.dims[2]);let s=t?.format!==void 0?t.format:"RGB",d=t?.norm,l,p;d===void 0||d.mean===void 0?l=[255,255,255,255]:typeof d.mean=="number"?l=[d.mean,d.mean,d.mean,d.mean]:(l=[d.mean[0],d.mean[1],d.mean[2],0],d.mean[3]!==void 0&&(l[3]=d.mean[3])),d===void 0||d.bias===void 0?p=[0,0,0,0]:typeof d.bias=="number"?p=[d.bias,d.bias,d.bias,d.bias]:(p=[d.bias[0],d.bias[1],d.bias[2],0],d.bias[3]!==void 0&&(p[3]=d.bias[3]));let h=n*a,u=0,m=h,$=h*2,f=-1;s==="RGBA"?(u=0,m=h,$=h*2,f=h*3):s==="RGB"?(u=0,m=h,$=h*2):s==="RBG"&&(u=0,$=h,m=h*2);for(let y=0;y<n;y++)for(let v=0;v<a;v++){let x=(e.data[u++]-p[0])*l[0],_=(e.data[m++]-p[1])*l[1],S=(e.data[$++]-p[2])*l[2],k=f===-1?255:(e.data[f++]-p[3])*l[3];i.fillStyle="rgba("+x+","+_+","+S+","+k+")",i.fillRect(v,y,1,1)}if("toDataURL"in r)return r.toDataURL();throw new Error("toDataURL is not supported")}else throw new Error("Can not access image data")},ad=(e,t)=>{let r=typeof document<"u"?document.createElement("canvas").getContext("2d"):new OffscreenCanvas(1,1).getContext("2d"),i;if(r!=null){let a,n,s;t?.tensorLayout!==void 0&&t.tensorLayout==="NHWC"?(a=e.dims[2],n=e.dims[1],s=e.dims[3]):(a=e.dims[3],n=e.dims[2],s=e.dims[1]);let d=t!==void 0&&t.format!==void 0?t.format:"RGB",l=t?.norm,p,h;l===void 0||l.mean===void 0?p=[255,255,255,255]:typeof l.mean=="number"?p=[l.mean,l.mean,l.mean,l.mean]:(p=[l.mean[0],l.mean[1],l.mean[2],255],l.mean[3]!==void 0&&(p[3]=l.mean[3])),l===void 0||l.bias===void 0?h=[0,0,0,0]:typeof l.bias=="number"?h=[l.bias,l.bias,l.bias,l.bias]:(h=[l.bias[0],l.bias[1],l.bias[2],0],l.bias[3]!==void 0&&(h[3]=l.bias[3]));let u=n*a;if(t!==void 0&&(t.format!==void 0&&s===4&&t.format!=="RGBA"||s===3&&t.format!=="RGB"&&t.format!=="BGR"))throw new Error("Tensor format doesn't match input tensor dims");let m=4,$=0,f=1,y=2,v=3,x=0,_=u,S=u*2,k=-1;d==="RGBA"?(x=0,_=u,S=u*2,k=u*3):d==="RGB"?(x=0,_=u,S=u*2):d==="RBG"&&(x=0,S=u,_=u*2),i=r.createImageData(a,n);for(let T=0;T<n*a;$+=m,f+=m,y+=m,v+=m,T++)i.data[$]=(e.data[x++]-h[0])*p[0],i.data[f]=(e.data[_++]-h[1])*p[1],i.data[y]=(e.data[S++]-h[2])*p[2],i.data[v]=k===-1?255:(e.data[k++]-h[3])*p[3]}else throw new Error("Can not access image data");return i}}),Cr,nd,sd,od,ud,ld,lm=F(()=>{"use strict";Oa(),Cr=(e,t)=>{if(e===void 0)throw new Error("Image buffer must be defined");if(t.height===void 0||t.width===void 0)throw new Error("Image height and width must be defined");if(t.tensorLayout==="NHWC")throw new Error("NHWC Tensor layout is not supported yet");let{height:r,width:i}=t,a=t.norm??{mean:255,bias:0},n,s;typeof a.mean=="number"?n=[a.mean,a.mean,a.mean,a.mean]:n=[a.mean[0],a.mean[1],a.mean[2],a.mean[3]??255],typeof a.bias=="number"?s=[a.bias,a.bias,a.bias,a.bias]:s=[a.bias[0],a.bias[1],a.bias[2],a.bias[3]??0];let d=t.format!==void 0?t.format:"RGBA",l=t.tensorFormat!==void 0&&t.tensorFormat!==void 0?t.tensorFormat:"RGB",p=r*i,h=l==="RGBA"?new Float32Array(p*4):new Float32Array(p*3),u=4,m=0,$=1,f=2,y=3,v=0,x=p,_=p*2,S=-1;d==="RGB"&&(u=3,m=0,$=1,f=2,y=-1),l==="RGBA"?S=p*3:l==="RBG"?(v=0,_=p,x=p*2):l==="BGR"&&(_=0,x=p,v=p*2);for(let k=0;k<p;k++,m+=u,f+=u,$+=u,y+=u)h[v++]=(e[m]+s[0])/n[0],h[x++]=(e[$]+s[1])/n[1],h[_++]=(e[f]+s[2])/n[2],S!==-1&&y!==-1&&(h[S++]=(e[y]+s[3])/n[3]);return l==="RGBA"?new We("float32",h,[1,4,r,i]):new We("float32",h,[1,3,r,i])},nd=async(e,t)=>{let r=typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement,i=typeof ImageData<"u"&&e instanceof ImageData,a=typeof ImageBitmap<"u"&&e instanceof ImageBitmap,n=typeof e=="string",s,d=t??{},l=()=>{if(typeof document<"u")return document.createElement("canvas");if(typeof OffscreenCanvas<"u")return new OffscreenCanvas(1,1);throw new Error("Canvas is not supported")},p=h=>typeof HTMLCanvasElement<"u"&&h instanceof HTMLCanvasElement||h instanceof OffscreenCanvas?h.getContext("2d"):null;if(r){let h=l();h.width=e.width,h.height=e.height;let u=p(h);if(u!=null){let m=e.height,$=e.width;if(t!==void 0&&t.resizedHeight!==void 0&&t.resizedWidth!==void 0&&(m=t.resizedHeight,$=t.resizedWidth),t!==void 0){if(d=t,t.tensorFormat!==void 0)throw new Error("Image input config format must be RGBA for HTMLImageElement");d.tensorFormat="RGBA",d.height=m,d.width=$}else d.tensorFormat="RGBA",d.height=m,d.width=$;u.drawImage(e,0,0),s=u.getImageData(0,0,$,m).data}else throw new Error("Can not access image data")}else if(i){let h,u;if(t!==void 0&&t.resizedWidth!==void 0&&t.resizedHeight!==void 0?(h=t.resizedHeight,u=t.resizedWidth):(h=e.height,u=e.width),t!==void 0&&(d=t),d.format="RGBA",d.height=h,d.width=u,t!==void 0){let m=l();m.width=u,m.height=h;let $=p(m);if($!=null)$.putImageData(e,0,0),s=$.getImageData(0,0,u,h).data;else throw new Error("Can not access image data")}else s=e.data}else if(a){if(t===void 0)throw new Error("Please provide image config with format for Imagebitmap");let h=l();h.width=e.width,h.height=e.height;let u=p(h);if(u!=null){let m=e.height,$=e.width;return u.drawImage(e,0,0,$,m),s=u.getImageData(0,0,$,m).data,d.height=m,d.width=$,Cr(s,d)}else throw new Error("Can not access image data")}else{if(n)return new Promise((h,u)=>{let m=l(),$=p(m);if(!e||!$)return u();let f=new Image;f.crossOrigin="Anonymous",f.src=e,f.onload=()=>{m.width=f.width,m.height=f.height,$.drawImage(f,0,0,m.width,m.height);let y=$.getImageData(0,0,m.width,m.height);d.height=m.height,d.width=m.width,h(Cr(y.data,d))}});throw new Error("Input data provided is not supported - aborted tensor creation")}if(s!==void 0)return Cr(s,d);throw new Error("Input data provided is not supported - aborted tensor creation")},sd=(e,t)=>{let{width:r,height:i,download:a,dispose:n}=t,s=[1,i,r,4];return new We({location:"texture",type:"float32",texture:e,dims:s,download:a,dispose:n})},od=(e,t)=>{let{dataType:r,dims:i,download:a,dispose:n}=t;return new We({location:"gpu-buffer",type:r??"float32",gpuBuffer:e,dims:i,download:a,dispose:n})},ud=(e,t)=>{let{dataType:r,dims:i,download:a,dispose:n}=t;return new We({location:"ml-tensor",type:r??"float32",mlTensor:e,dims:i,download:a,dispose:n})},ld=(e,t,r)=>new We({location:"cpu-pinned",type:e,data:t,dims:r??[t.length]})}),Ot,ar,Ei,dd,dm=F(()=>{"use strict";Ot=new Map([["float32",Float32Array],["uint8",Uint8Array],["int8",Int8Array],["uint16",Uint16Array],["int16",Int16Array],["int32",Int32Array],["bool",Uint8Array],["float64",Float64Array],["uint32",Uint32Array],["int4",Uint8Array],["uint4",Uint8Array]]),ar=new Map([[Float32Array,"float32"],[Uint8Array,"uint8"],[Int8Array,"int8"],[Uint16Array,"uint16"],[Int16Array,"int16"],[Int32Array,"int32"],[Float64Array,"float64"],[Uint32Array,"uint32"]]),Ei=!1,dd=()=>{if(!Ei){Ei=!0;let e=typeof BigInt64Array<"u"&&BigInt64Array.from,t=typeof BigUint64Array<"u"&&BigUint64Array.from,r=typeof Float16Array<"u"&&Float16Array.from;e&&(Ot.set("int64",BigInt64Array),ar.set(BigInt64Array,"int64")),t&&(Ot.set("uint64",BigUint64Array),ar.set(BigUint64Array,"uint64")),r?(Ot.set("float16",Float16Array),ar.set(Float16Array,"float16")):Ot.set("float16",Uint16Array)}}}),pd,cd,pm=F(()=>{"use strict";Oa(),pd=e=>{let t=1;for(let r=0;r<e.length;r++){let i=e[r];if(typeof i!="number"||!Number.isSafeInteger(i))throw new TypeError(`dims[${r}] must be an integer, got: ${i}`);if(i<0)throw new RangeError(`dims[${r}] must be a non-negative integer, got: ${i}`);t*=i}return t},cd=(e,t)=>{switch(e.location){case"cpu":return new We(e.type,e.data,t);case"cpu-pinned":return new We({location:"cpu-pinned",data:e.data,type:e.type,dims:t});case"texture":return new We({location:"texture",texture:e.texture,type:e.type,dims:t});case"gpu-buffer":return new We({location:"gpu-buffer",gpuBuffer:e.gpuBuffer,type:e.type,dims:t});case"ml-tensor":return new We({location:"ml-tensor",mlTensor:e.mlTensor,type:e.type,dims:t});default:throw new Error(`tensorReshape: tensor location ${e.location} is not supported`)}}}),We,Oa=F(()=>{"use strict";um(),lm(),dm(),pm(),We=class{constructor(e,t,r){dd();let i,a;if(typeof e=="object"&&"location"in e)switch(this.dataLocation=e.location,i=e.type,a=e.dims,e.location){case"cpu-pinned":{let s=Ot.get(i);if(!s)throw new TypeError(`unsupported type "${i}" to create tensor from pinned buffer`);if(!(e.data instanceof s))throw new TypeError(`buffer should be of type ${s.name}`);this.cpuData=e.data;break}case"texture":{if(i!=="float32")throw new TypeError(`unsupported type "${i}" to create tensor from texture`);this.gpuTextureData=e.texture,this.downloader=e.download,this.disposer=e.dispose;break}case"gpu-buffer":{if(i!=="float32"&&i!=="float16"&&i!=="int32"&&i!=="int64"&&i!=="uint32"&&i!=="uint8"&&i!=="bool"&&i!=="uint4"&&i!=="int4")throw new TypeError(`unsupported type "${i}" to create tensor from gpu buffer`);this.gpuBufferData=e.gpuBuffer,this.downloader=e.download,this.disposer=e.dispose;break}case"ml-tensor":{if(i!=="float32"&&i!=="float16"&&i!=="int32"&&i!=="int64"&&i!=="uint32"&&i!=="uint64"&&i!=="int8"&&i!=="uint8"&&i!=="bool")throw new TypeError(`unsupported type "${i}" to create tensor from MLTensor`);this.mlTensorData=e.mlTensor,this.downloader=e.download,this.disposer=e.dispose;break}default:throw new Error(`Tensor constructor: unsupported location '${this.dataLocation}'`)}else{let s,d;if(typeof e=="string")if(i=e,d=r,e==="string"){if(!Array.isArray(t))throw new TypeError("A string tensor's data must be a string array.");s=t}else{let l=Ot.get(e);if(l===void 0)throw new TypeError(`Unsupported tensor type: ${e}.`);if(Array.isArray(t)){if(e==="float16"&&l===Uint16Array||e==="uint4"||e==="int4")throw new TypeError(`Creating a ${e} tensor from number array is not supported. Please use ${l.name} as data.`);e==="uint64"||e==="int64"?s=l.from(t,BigInt):s=l.from(t)}else if(t instanceof l)s=t;else if(t instanceof Uint8ClampedArray)if(e==="uint8")s=Uint8Array.from(t);else throw new TypeError("A Uint8ClampedArray tensor's data must be type of uint8");else throw new TypeError(`A ${i} tensor's data must be type of ${l}`)}else if(d=t,Array.isArray(e)){if(e.length===0)throw new TypeError("Tensor type cannot be inferred from an empty array.");let l=typeof e[0];if(l==="string")i="string",s=e;else if(l==="boolean")i="bool",s=Uint8Array.from(e);else throw new TypeError(`Invalid element type of data array: ${l}.`)}else if(e instanceof Uint8ClampedArray)i="uint8",s=Uint8Array.from(e);else{let l=ar.get(e.constructor);if(l===void 0)throw new TypeError(`Unsupported type for tensor data: ${e.constructor}.`);i=l,s=e}if(d===void 0)d=[s.length];else if(!Array.isArray(d))throw new TypeError("A tensor's dims must be a number array");a=d,this.cpuData=s,this.dataLocation="cpu"}let n=pd(a);if(this.cpuData&&n!==this.cpuData.length&&!((i==="uint4"||i==="int4")&&Math.ceil(n/2)===this.cpuData.length))throw new Error(`Tensor's size(${n}) does not match data length(${this.cpuData.length}).`);this.type=i,this.dims=a,this.size=n}static async fromImage(e,t){return nd(e,t)}static fromTexture(e,t){return sd(e,t)}static fromGpuBuffer(e,t){return od(e,t)}static fromMLTensor(e,t){return ud(e,t)}static fromPinnedBuffer(e,t,r){return ld(e,t,r)}toDataURL(e){return id(this,e)}toImageData(e){return ad(this,e)}get data(){if(this.ensureValid(),!this.cpuData)throw new Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");return this.cpuData}get location(){return this.dataLocation}get texture(){if(this.ensureValid(),!this.gpuTextureData)throw new Error("The data is not stored as a WebGL texture.");return this.gpuTextureData}get gpuBuffer(){if(this.ensureValid(),!this.gpuBufferData)throw new Error("The data is not stored as a WebGPU buffer.");return this.gpuBufferData}get mlTensor(){if(this.ensureValid(),!this.mlTensorData)throw new Error("The data is not stored as a WebNN MLTensor.");return this.mlTensorData}async getData(e){switch(this.ensureValid(),this.dataLocation){case"cpu":case"cpu-pinned":return this.data;case"texture":case"gpu-buffer":case"ml-tensor":{if(!this.downloader)throw new Error("The current tensor is not created with a specified data downloader.");if(this.isDownloading)throw new Error("The current tensor is being downloaded.");try{this.isDownloading=!0;let t=await this.downloader();return this.downloader=void 0,this.dataLocation="cpu",this.cpuData=t,e&&this.disposer&&(this.disposer(),this.disposer=void 0),t}finally{this.isDownloading=!1}}default:throw new Error(`cannot get data from location: ${this.dataLocation}`)}}dispose(){if(this.isDownloading)throw new Error("The current tensor is being downloaded.");this.disposer&&(this.disposer(),this.disposer=void 0),this.cpuData=void 0,this.gpuTextureData=void 0,this.gpuBufferData=void 0,this.mlTensorData=void 0,this.downloader=void 0,this.isDownloading=void 0,this.dataLocation="none"}ensureValid(){if(this.dataLocation==="none")throw new Error("The tensor is disposed.")}reshape(e){if(this.ensureValid(),this.downloader||this.disposer)throw new Error("Cannot reshape a tensor that owns GPU resource.");return cd(this,e)}}}),Oe,Ba=F(()=>{"use strict";Oa(),Oe=We}),qr,Ci,ot,et,hd=F(()=>{"use strict";rd(),qr=(e,t)=>{(typeof He.trace>"u"?!He.wasm.trace:!He.trace)||console.timeStamp(`${e}::ORT::${t}`)},Ci=(e,t)=>{let r=new Error().stack?.split(/\r\n|\r|\n/g)||[],i=!1;for(let a=0;a<r.length;a++){if(i&&!r[a].includes("TRACE_FUNC")){let n=`FUNC_${e}::${r[a].trim().split(" ")[1]}`;t&&(n+=`::${t}`),qr("CPU",n);return}r[a].includes("TRACE_FUNC")&&(i=!0)}},ot=e=>{(typeof He.trace>"u"?!He.wasm.trace:!He.trace)||Ci("BEGIN",e)},et=e=>{(typeof He.trace>"u"?!He.wasm.trace:!He.trace)||Ci("END",e)}}),fd,cm=F(()=>{"use strict";Ra(),Ba(),hd(),fd=class md{constructor(t){this.handler=t}async run(t,r,i){ot();let a={},n={};if(typeof t!="object"||t===null||t instanceof Oe||Array.isArray(t))throw new TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");let s=!0;if(typeof r=="object"){if(r===null)throw new TypeError("Unexpected argument[1]: cannot be null.");if(r instanceof Oe)throw new TypeError("'fetches' cannot be a Tensor");if(Array.isArray(r)){if(r.length===0)throw new TypeError("'fetches' cannot be an empty array.");s=!1;for(let p of r){if(typeof p!="string")throw new TypeError("'fetches' must be a string array or an object.");if(this.outputNames.indexOf(p)===-1)throw new RangeError(`'fetches' contains invalid output name: ${p}.`);a[p]=null}if(typeof i=="object"&&i!==null)n=i;else if(typeof i<"u")throw new TypeError("'options' must be an object.")}else{let p=!1,h=Object.getOwnPropertyNames(r);for(let u of this.outputNames)if(h.indexOf(u)!==-1){let m=r[u];(m===null||m instanceof Oe)&&(p=!0,s=!1,a[u]=m)}if(p){if(typeof i=="object"&&i!==null)n=i;else if(typeof i<"u")throw new TypeError("'options' must be an object.")}else n=r}}else if(typeof r<"u")throw new TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");for(let p of this.inputNames)if(typeof t[p]>"u")throw new Error(`input '${p}' is missing in 'feeds'.`);if(s)for(let p of this.outputNames)a[p]=null;let d=await this.handler.run(t,a,n),l={};for(let p in d)if(Object.hasOwnProperty.call(d,p)){let h=d[p];h instanceof Oe?l[p]=h:l[p]=new Oe(h.type,h.data,h.dims)}return et(),l}async release(){return this.handler.dispose()}static async create(t,r,i,a){ot();let n,s={};if(typeof t=="string"){if(n=t,typeof r=="object"&&r!==null)s=r;else if(typeof r<"u")throw new TypeError("'options' must be an object.")}else if(t instanceof Uint8Array){if(n=t,typeof r=="object"&&r!==null)s=r;else if(typeof r<"u")throw new TypeError("'options' must be an object.")}else if(t instanceof ArrayBuffer||typeof SharedArrayBuffer<"u"&&t instanceof SharedArrayBuffer){let h=t,u=0,m=t.byteLength;if(typeof r=="object"&&r!==null)s=r;else if(typeof r=="number"){if(u=r,!Number.isSafeInteger(u))throw new RangeError("'byteOffset' must be an integer.");if(u<0||u>=h.byteLength)throw new RangeError(`'byteOffset' is out of range [0, ${h.byteLength}).`);if(m=t.byteLength-u,typeof i=="number"){if(m=i,!Number.isSafeInteger(m))throw new RangeError("'byteLength' must be an integer.");if(m<=0||u+m>h.byteLength)throw new RangeError(`'byteLength' is out of range (0, ${h.byteLength-u}].`);if(typeof a=="object"&&a!==null)s=a;else if(typeof a<"u")throw new TypeError("'options' must be an object.")}else if(typeof i<"u")throw new TypeError("'byteLength' must be a number.")}else if(typeof r<"u")throw new TypeError("'options' must be an object.");n=new Uint8Array(h,u,m)}else throw new TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");let[d,l]=await za(s),p=await d.createInferenceSessionHandler(n,l);return et(),new md(p)}startProfiling(){this.handler.startProfiling()}endProfiling(){this.handler.endProfiling()}get inputNames(){return this.handler.inputNames}get outputNames(){return this.handler.outputNames}}}),Qr,hm=F(()=>{"use strict";cm(),Qr=fd}),fm=F(()=>{"use strict"}),mm=F(()=>{"use strict"}),gm=F(()=>{"use strict"}),ym=F(()=>{"use strict"}),Bs,gd,wm=F(()=>{"use strict";Ra(),Ba(),Bs="Training backend could not be resolved. Make sure you're using the correct configuration & WebAssembly files.",gd=class yd{constructor(t,r,i){this.handler=t,this.hasOptimizerModel=r,this.hasEvalModel=i}get trainingInputNames(){return this.handler.inputNames}get trainingOutputNames(){return this.handler.outputNames}get evalInputNames(){if(this.hasEvalModel)return this.handler.evalInputNames;throw new Error("This training session has no evalModel loaded.")}get evalOutputNames(){if(this.hasEvalModel)return this.handler.evalOutputNames;throw new Error("This training session has no evalModel loaded.")}static async create(t,r){let i=t.evalModel||"",a=t.optimizerModel||"",n=r||{},[s,d]=await za(n);if(s.createTrainingSessionHandler){let l=await s.createTrainingSessionHandler(t.checkpointState,t.trainModel,i,a,d);return new yd(l,!!t.optimizerModel,!!t.evalModel)}else throw new Error(Bs)}typeNarrowingForRunStep(t,r,i,a,n){let s={},d={};if(typeof i!="object"||i===null||i instanceof Oe||Array.isArray(i))throw new TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");let l=!0;if(typeof a=="object"){if(a===null)throw new TypeError("Unexpected argument[1]: cannot be null.");if(a instanceof Oe)throw new TypeError("'fetches' cannot be a Tensor");if(Array.isArray(a)){if(a.length===0)throw new TypeError("'fetches' cannot be an empty array.");l=!1;for(let p of a){if(typeof p!="string")throw new TypeError("'fetches' must be a string array or an object.");if(r.indexOf(p)===-1)throw new RangeError(`'fetches' contains invalid output name: ${p}.`);s[p]=null}if(typeof n=="object"&&n!==null)d=n;else if(typeof n<"u")throw new TypeError("'options' must be an object.")}else{let p=!1,h=Object.getOwnPropertyNames(a);for(let u of r)if(h.indexOf(u)!==-1){let m=a[u];(m===null||m instanceof Oe)&&(p=!0,l=!1,s[u]=m)}if(p){if(typeof n=="object"&&n!==null)d=n;else if(typeof n<"u")throw new TypeError("'options' must be an object.")}else d=a}}else if(typeof a<"u")throw new TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");for(let p of t)if(typeof i[p]>"u")throw new Error(`input '${p}' is missing in 'feeds'.`);if(l)for(let p of r)s[p]=null;return[s,d]}convertHandlerReturnTypeToMapOfTensors(t){let r={};for(let i in t)if(Object.hasOwnProperty.call(t,i)){let a=t[i];a instanceof Oe?r[i]=a:r[i]=new Oe(a.type,a.data,a.dims)}return r}async lazyResetGrad(){await this.handler.lazyResetGrad()}async runTrainStep(t,r,i){let[a,n]=this.typeNarrowingForRunStep(this.trainingInputNames,this.trainingOutputNames,t,r,i),s=await this.handler.runTrainStep(t,a,n);return this.convertHandlerReturnTypeToMapOfTensors(s)}async runOptimizerStep(t){if(this.hasOptimizerModel)await this.handler.runOptimizerStep(t||{});else throw new Error("This TrainingSession has no OptimizerModel loaded.")}async runEvalStep(t,r,i){if(this.hasEvalModel){let[a,n]=this.typeNarrowingForRunStep(this.evalInputNames,this.evalOutputNames,t,r,i),s=await this.handler.runEvalStep(t,a,n);return this.convertHandlerReturnTypeToMapOfTensors(s)}else throw new Error("This TrainingSession has no EvalModel loaded.")}async getParametersSize(t=!0){return this.handler.getParametersSize(t)}async loadParametersBuffer(t,r=!0){let i=await this.getParametersSize(r);if(t.length!==4*i)throw new Error("Size of the buffer passed into loadParametersBuffer must match the number of parameters in the model. Please use getParametersSize method to check.");return this.handler.loadParametersBuffer(t,r)}async getContiguousParameters(t=!0){return this.handler.getContiguousParameters(t)}async release(){return this.handler.dispose()}}}),wd,$m=F(()=>{"use strict";wm(),wd=gd}),_m={};pr(_m,{InferenceSession:()=>Qr,TRACE:()=>qr,TRACE_FUNC_BEGIN:()=>ot,TRACE_FUNC_END:()=>et,Tensor:()=>Oe,TrainingSession:()=>wd,env:()=>ge,registerBackend:()=>qt});var tt=F(()=>{"use strict";nm(),om(),hm(),Ba(),fm(),mm(),hd(),gm(),ym(),$m()}),Ma=F(()=>{"use strict"}),$d={};pr($d,{default:()=>_d});var Ii,Ai,_d,bm=F(()=>{"use strict";gh(),Mt(),Xr(),Ii="ort-wasm-proxy-worker",Ai=globalThis.self?.name===Ii,Ai&&(self.onmessage=e=>{let{type:t,in:r}=e.data;try{switch(t){case"init-wasm":Pa(r.wasm).then(()=>{Ja(r).then(()=>{postMessage({type:t})},i=>{postMessage({type:t,err:i})})},i=>{postMessage({type:t,err:i})});break;case"init-ep":{let{epName:i,env:a}=r;en(a,i).then(()=>{postMessage({type:t})},n=>{postMessage({type:t,err:n})});break}case"copy-from":{let{buffer:i}=r,a=Zr(i);postMessage({type:t,out:a});break}case"create":{let{model:i,options:a}=r;tn(i,a).then(n=>{postMessage({type:t,out:n})},n=>{postMessage({type:t,err:n})});break}case"release":rn(r),postMessage({type:t});break;case"run":{let{sessionId:i,inputIndices:a,inputs:n,outputIndices:s,options:d}=r;an(i,a,n,s,new Array(s.length).fill(null),d).then(l=>{l.some(p=>p[3]!=="cpu")?postMessage({type:t,err:"Proxy does not support non-cpu tensor location."}):postMessage({type:t,out:l},sn([...n,...l]))},l=>{postMessage({type:t,err:l})});break}case"end-profiling":nn(r),postMessage({type:t});break;default:}}catch(i){postMessage({type:t,err:i})}}),_d=Ai?null:e=>new Worker(e??Lt,{type:"module",name:Ii})}),bd={};pr(bd,{default:()=>vd});var zi,Ri,vd,vm=F(()=>{"use strict";Ri=(zi=import.meta.url,async function(e={}){function t(){return q.buffer!=j.buffer&&me(),j}function r(){return q.buffer!=j.buffer&&me(),re}function i(){return q.buffer!=j.buffer&&me(),O}function a(){return q.buffer!=j.buffer&&me(),U}function n(){return q.buffer!=j.buffer&&me(),te}function s(){return q.buffer!=j.buffer&&me(),fe}function d(){return q.buffer!=j.buffer&&me(),be}function l(){return q.buffer!=j.buffer&&me(),qe}var p,h,u=Object.assign({},e),m=new Promise((o,c)=>{p=o,h=c}),$=typeof window=="object",f=typeof importScripts=="function",y=f&&self.name=="em-pthread";u.mountExternalData=(o,c)=>{o.startsWith("./")&&(o=o.substring(2)),(u.Fb||(u.Fb=new Map)).set(o,c)},u.unmountExternalData=()=>{delete u.Fb};var v=globalThis.SharedArrayBuffer??new WebAssembly.Memory({initial:0,maximum:0,shared:!0}).buffer.constructor;let x=()=>{let o=(g,w,b)=>(...E)=>{let B=nt,D=w?.();E=g(...E);let L=w?.();return D!==L&&(g=L,b(D),w=b=null),nt!=B?new Promise((V,Q)=>{wi={resolve:V,reject:Q}}):E},c=g=>async(...w)=>{try{if(u.Eb)throw Error("Session already started");let b=u.Eb={fc:w[0],errors:[]},E=await g(...w);if(u.Eb!==b)throw Error("Session mismatch");u.Gb?.flush();let B=b.errors;if(0<B.length){let D=await Promise.all(B);if(D=D.filter(L=>L),0<D.length)throw Error(D.join(`
`))}return E}finally{u.Eb=null}};u._OrtCreateSession=o(u._OrtCreateSession,()=>u._OrtCreateSession,g=>u._OrtCreateSession=g),u._OrtRun=c(o(u._OrtRun,()=>u._OrtRun,g=>u._OrtRun=g)),u._OrtRunWithBinding=c(o(u._OrtRunWithBinding,()=>u._OrtRunWithBinding,g=>u._OrtRunWithBinding=g)),u._OrtBindInput=o(u._OrtBindInput,()=>u._OrtBindInput,g=>u._OrtBindInput=g),x=void 0};u.jsepInit=(o,c)=>{if(x?.(),o==="webgpu"){[u.Gb,u.Ub,u.Yb,u.Nb,u.Xb,u.jb,u.Zb,u.bc,u.Vb,u.Wb,u.$b]=c;let g=u.Gb;u.jsepRegisterBuffer=(w,b,E,B)=>g.registerBuffer(w,b,E,B),u.jsepGetBuffer=w=>g.getBuffer(w),u.jsepCreateDownloader=(w,b,E)=>g.createDownloader(w,b,E),u.jsepOnReleaseSession=w=>{g.onReleaseSession(w)},u.jsepOnRunStart=w=>g.onRunStart(w),u.cc=(w,b)=>{g.upload(w,b)}}else if(o==="webnn"){[u.Gb,u.ac,u.Ob,u.jsepEnsureTensor,u.dc,u.jsepDownloadTensor]=c,u.jsepReleaseTensorId=u.Ob;let g=u.Gb;u.jsepOnRunStart=w=>g.onRunStart(w),u.jsepRegisterMLContext=(w,b)=>{g.registerMLContext(w,b)},u.jsepOnReleaseSession=w=>{g.onReleaseSession(w)},u.jsepCreateMLTensorDownloader=(w,b)=>g.createMLTensorDownloader(w,b),u.jsepRegisterMLTensor=(w,b,E)=>g.registerMLTensor(w,b,E)}};var _,S,k=Object.assign({},u),T="./this.program",I=(o,c)=>{throw c},C="";($||f)&&(f?C=self.location.href:typeof document<"u"&&document.currentScript&&(C=document.currentScript.src),zi&&(C=zi),C=C.startsWith("blob:")?"":C.substr(0,C.replace(/[?#].*/,"").lastIndexOf("/")+1),f&&(S=o=>{var c=new XMLHttpRequest;return c.open("GET",o,!1),c.responseType="arraybuffer",c.send(null),new Uint8Array(c.response)}),_=(o,c,g)=>{var w=new XMLHttpRequest;w.open("GET",o,!0),w.responseType="arraybuffer",w.onload=()=>{w.status==200||w.status==0&&w.response?c(w.response):g()},w.onerror=g,w.send(null)});var M,N=console.log.bind(console),W=console.error.bind(console),J=N,K=W;if(Object.assign(u,k),k=null,y){let o=function(c){try{var g=c.data,w=g.cmd;if(w==="load"){let b=[];self.onmessage=E=>b.push(E),self.startWorker=()=>{postMessage({cmd:"loaded"});for(let E of b)o(E);self.onmessage=o};for(let E of g.handlers)u[E]&&!u[E].proxy||(u[E]=(...B)=>{postMessage({Mb:"callHandler",oc:E,args:B})},E=="print"&&(J=u[E]),E=="printErr"&&(K=u[E]));q=g.wasmMemory,me(),ie(g.wasmModule)}else if(w==="run"){vi(g.pthread_ptr,0,0,1,0,0),mi(g.pthread_ptr),Ph(),vn(),ue||($s(),ue=!0);try{Dh(g.start_routine,g.arg)}catch(b){if(b!="unwind")throw b}}else w==="cancel"?Nt()&&Tr(-1):g.target!=="setimmediate"&&(w==="checkMailbox"?ue&&yr():w&&(K(`worker: received unknown command ${w}`),K(g)))}catch(b){throw _s(),b}};var X=o,ie,ue=!1;K=function(...c){c=c.join(" "),console.error(c)},self.alert=function(...c){postMessage({Mb:"alert",text:c.join(" "),qc:Nt()})},u.instantiateWasm=(c,g)=>new Promise(w=>{ie=b=>{b=new WebAssembly.Instance(b,yn()),g(b),w()}}),self.onunhandledrejection=c=>{throw c.reason||c},self.onmessage=o}u.wasmBinary&&(M=u.wasmBinary);var q,de,se,j,re,O,U,te,fe,be,ke,De,qe,Fe=!1;function me(){var o=q.buffer;u.HEAP8=j=new Int8Array(o),u.HEAP16=O=new Int16Array(o),u.HEAPU8=re=new Uint8Array(o),u.HEAPU16=U=new Uint16Array(o),u.HEAP32=te=new Int32Array(o),u.HEAPU32=fe=new Uint32Array(o),u.HEAPF32=be=new Float32Array(o),u.HEAPF64=qe=new Float64Array(o),u.HEAP64=ke=new BigInt64Array(o),u.HEAPU64=De=new BigUint64Array(o)}if(!y){if(!((q=new WebAssembly.Memory({initial:256,maximum:65536,shared:!0})).buffer instanceof v))throw K("requested a shared WebAssembly.Memory but the returned buffer is not a SharedArrayBuffer, indicating that while the browser has SharedArrayBuffer it does not have WebAssembly threads support - you may need to set a flag"),Error("bad memory");me()}var Ie=[],rt=[],mr=[],Tt=0,ri=null,Yt=null;function cn(){if(--Tt==0&&(ri!==null&&(clearInterval(ri),ri=null),Yt)){var o=Yt;Yt=null,o()}}function Pt(o){throw K(o="Aborted("+o+")"),Fe=!0,se=1,o=new WebAssembly.RuntimeError(o+". Build with -sASSERTIONS for more info."),h(o),o}var ii,hn=o=>o.startsWith("data:application/octet-stream;base64,"),fn=o=>o.startsWith("file://");function mn(o){if(o==ii&&M)return new Uint8Array(M);if(S)return S(o);throw"both async and sync fetching of the wasm failed"}function gn(o,c,g){return function(w){if(!M&&($||f)){if(typeof fetch=="function"&&!fn(w))return fetch(w,{credentials:"same-origin"}).then(b=>{if(!b.ok)throw`failed to load wasm binary file at '${w}'`;return b.arrayBuffer()}).catch(()=>mn(w));if(_)return new Promise((b,E)=>{_(w,B=>b(new Uint8Array(B)),E)})}return Promise.resolve().then(()=>mn(w))}(o).then(w=>WebAssembly.instantiate(w,c)).then(g,w=>{K(`failed to asynchronously prepare wasm: ${w}`),Pt(w)})}function yn(){return{a:{O:Mh,Aa:Bh,b:Uh,aa:Tn,B:In,qa:An,Y:Rn,_:On,ra:Bn,oa:Mn,ha:Pn,na:Dn,L:Fn,Z:Un,W:Nn,pa:Wn,X:Ln,wa:Nh,F:Lh,Q:qh,P:jh,E:Hh,u:Kh,q:Yh,G:Zh,A:af,R:nf,ua:sf,ka:of,U:uf,ba:lf,H:df,ja:mi,ta:pf,t:cf,x:mf,o:gf,l:wf,c:hi,n:$f,j:vf,w:xf,p:Sf,g:kf,s:Tf,m:Ef,e:Cf,k:If,i:Af,h:zf,d:Rf,ea:Of,fa:Bf,ga:Mf,ca:rs,da:is,T:Pf,f:Df,D:Ff,I:Uf,M:Nf,y:Wf,sa:Lf,V:qf,v:ns,z:Vf,N:jf,S:Gf,za:Hf,ya:Kf,la:us,ma:ls,$:ui,C:ds,K:ps,ia:cs,J:hs,a:q,xa:oi,va:gs,r:Qf}}}var ai={868340:(o,c,g,w,b)=>{if(u===void 0||!u.Fb)return 1;if((o=Ae(o>>>0)).startsWith("./")&&(o=o.substring(2)),!(o=u.Fb.get(o)))return 2;if(w>>>=0,(c>>>=0)+(g>>>=0)>o.byteLength)return 3;try{let E=o.subarray(c,c+g);switch(b){case 0:r().set(E,w>>>0);break;case 1:u.cc(w,E);break;default:return 4}return 0}catch{return 4}},869023:(o,c,g)=>{u.dc(o,r().subarray(c>>>0,c+g>>>0))},869086:()=>u.ac(),869127:o=>{u.Ob(o)},869163:()=>{u.Vb()},869194:()=>{u.Wb()},869223:()=>{u.$b()},869248:o=>u.Ub(o),869281:o=>u.Yb(o),869313:(o,c,g)=>{u.Nb(o,c,g,!0)},869352:(o,c,g)=>{u.Nb(o,c,g)},869385:()=>typeof wasmOffsetConverter<"u",869442:o=>{u.jb("Abs",o,void 0)},869493:o=>{u.jb("Neg",o,void 0)},869544:o=>{u.jb("Floor",o,void 0)},869597:o=>{u.jb("Ceil",o,void 0)},869649:o=>{u.jb("Reciprocal",o,void 0)},869707:o=>{u.jb("Sqrt",o,void 0)},869759:o=>{u.jb("Exp",o,void 0)},869810:o=>{u.jb("Erf",o,void 0)},869861:o=>{u.jb("Sigmoid",o,void 0)},869916:(o,c,g)=>{u.jb("HardSigmoid",o,{alpha:c,beta:g})},869995:o=>{u.jb("Log",o,void 0)},870046:o=>{u.jb("Sin",o,void 0)},870097:o=>{u.jb("Cos",o,void 0)},870148:o=>{u.jb("Tan",o,void 0)},870199:o=>{u.jb("Asin",o,void 0)},870251:o=>{u.jb("Acos",o,void 0)},870303:o=>{u.jb("Atan",o,void 0)},870355:o=>{u.jb("Sinh",o,void 0)},870407:o=>{u.jb("Cosh",o,void 0)},870459:o=>{u.jb("Asinh",o,void 0)},870512:o=>{u.jb("Acosh",o,void 0)},870565:o=>{u.jb("Atanh",o,void 0)},870618:o=>{u.jb("Tanh",o,void 0)},870670:o=>{u.jb("Not",o,void 0)},870721:(o,c,g)=>{u.jb("Clip",o,{min:c,max:g})},870790:o=>{u.jb("Clip",o,void 0)},870842:(o,c)=>{u.jb("Elu",o,{alpha:c})},870900:o=>{u.jb("Gelu",o,void 0)},870952:o=>{u.jb("Relu",o,void 0)},871004:(o,c)=>{u.jb("LeakyRelu",o,{alpha:c})},871068:(o,c)=>{u.jb("ThresholdedRelu",o,{alpha:c})},871138:(o,c)=>{u.jb("Cast",o,{to:c})},871196:o=>{u.jb("Add",o,void 0)},871247:o=>{u.jb("Sub",o,void 0)},871298:o=>{u.jb("Mul",o,void 0)},871349:o=>{u.jb("Div",o,void 0)},871400:o=>{u.jb("Pow",o,void 0)},871451:o=>{u.jb("Equal",o,void 0)},871504:o=>{u.jb("Greater",o,void 0)},871559:o=>{u.jb("GreaterOrEqual",o,void 0)},871621:o=>{u.jb("Less",o,void 0)},871673:o=>{u.jb("LessOrEqual",o,void 0)},871732:(o,c,g,w,b)=>{u.jb("ReduceMean",o,{keepDims:!!c,noopWithEmptyAxes:!!g,axes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},871891:(o,c,g,w,b)=>{u.jb("ReduceMax",o,{keepDims:!!c,noopWithEmptyAxes:!!g,axes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},872049:(o,c,g,w,b)=>{u.jb("ReduceMin",o,{keepDims:!!c,noopWithEmptyAxes:!!g,axes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},872207:(o,c,g,w,b)=>{u.jb("ReduceProd",o,{keepDims:!!c,noopWithEmptyAxes:!!g,axes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},872366:(o,c,g,w,b)=>{u.jb("ReduceSum",o,{keepDims:!!c,noopWithEmptyAxes:!!g,axes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},872524:(o,c,g,w,b)=>{u.jb("ReduceL1",o,{keepDims:!!c,noopWithEmptyAxes:!!g,axes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},872681:(o,c,g,w,b)=>{u.jb("ReduceL2",o,{keepDims:!!c,noopWithEmptyAxes:!!g,axes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},872838:(o,c,g,w,b)=>{u.jb("ReduceLogSum",o,{keepDims:!!c,noopWithEmptyAxes:!!g,axes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},872999:(o,c,g,w,b)=>{u.jb("ReduceSumSquare",o,{keepDims:!!c,noopWithEmptyAxes:!!g,axes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},873163:(o,c,g,w,b)=>{u.jb("ReduceLogSumExp",o,{keepDims:!!c,noopWithEmptyAxes:!!g,axes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},873327:o=>{u.jb("Where",o,void 0)},873380:(o,c,g)=>{u.jb("Transpose",o,{perm:c?Array.from(n().subarray(c>>>0,g>>>0)):[]})},873488:(o,c,g,w)=>{u.jb("DepthToSpace",o,{blocksize:c,mode:Ae(g),format:w?"NHWC":"NCHW"})},873621:(o,c,g,w)=>{u.jb("DepthToSpace",o,{blocksize:c,mode:Ae(g),format:w?"NHWC":"NCHW"})},873754:(o,c,g,w,b,E,B,D,L,V,Q,le,he,A,oe)=>{u.jb("ConvTranspose",o,{format:L?"NHWC":"NCHW",autoPad:c,dilations:[g],group:w,kernelShape:[b],pads:[E,B],strides:[D],wIsConst:()=>!!t()[V>>>0],outputPadding:Q?Array.from(n().subarray(Q>>>0,le>>>0)):[],outputShape:he?Array.from(n().subarray(he>>>0,A>>>0)):[],activation:Ae(oe)})},874155:(o,c,g,w,b,E,B,D,L,V,Q,le,he,A)=>{u.jb("ConvTranspose",o,{format:D?"NHWC":"NCHW",autoPad:c,dilations:Array.from(n().subarray(g>>>0,2+(g>>>0)>>>0)),group:w,kernelShape:Array.from(n().subarray(b>>>0,2+(b>>>0)>>>0)),pads:Array.from(n().subarray(E>>>0,4+(E>>>0)>>>0)),strides:Array.from(n().subarray(B>>>0,2+(B>>>0)>>>0)),wIsConst:()=>!!t()[L>>>0],outputPadding:V?Array.from(n().subarray(V>>>0,Q>>>0)):[],outputShape:le?Array.from(n().subarray(le>>>0,he>>>0)):[],activation:Ae(A)})},874720:(o,c,g,w,b,E,B,D,L,V,Q,le,he,A,oe)=>{u.jb("ConvTranspose",o,{format:L?"NHWC":"NCHW",autoPad:c,dilations:[g],group:w,kernelShape:[b],pads:[E,B],strides:[D],wIsConst:()=>!!t()[V>>>0],outputPadding:Q?Array.from(n().subarray(Q>>>0,le>>>0)):[],outputShape:he?Array.from(n().subarray(he>>>0,A>>>0)):[],activation:Ae(oe)})},875121:(o,c,g,w,b,E,B,D,L,V,Q,le,he,A)=>{u.jb("ConvTranspose",o,{format:D?"NHWC":"NCHW",autoPad:c,dilations:Array.from(n().subarray(g>>>0,2+(g>>>0)>>>0)),group:w,kernelShape:Array.from(n().subarray(b>>>0,2+(b>>>0)>>>0)),pads:Array.from(n().subarray(E>>>0,4+(E>>>0)>>>0)),strides:Array.from(n().subarray(B>>>0,2+(B>>>0)>>>0)),wIsConst:()=>!!t()[L>>>0],outputPadding:V?Array.from(n().subarray(V>>>0,Q>>>0)):[],outputShape:le?Array.from(n().subarray(le>>>0,he>>>0)):[],activation:Ae(A)})},875686:(o,c)=>{u.jb("GlobalAveragePool",o,{format:c?"NHWC":"NCHW"})},875777:(o,c,g,w,b,E,B,D,L,V,Q,le,he,A)=>{u.jb("AveragePool",o,{format:A?"NHWC":"NCHW",auto_pad:c,ceil_mode:g,count_include_pad:w,storage_order:b,dilations:E?Array.from(n().subarray(E>>>0,B>>>0)):[],kernel_shape:D?Array.from(n().subarray(D>>>0,L>>>0)):[],pads:V?Array.from(n().subarray(V>>>0,Q>>>0)):[],strides:le?Array.from(n().subarray(le>>>0,he>>>0)):[]})},876192:(o,c)=>{u.jb("GlobalAveragePool",o,{format:c?"NHWC":"NCHW"})},876283:(o,c,g,w,b,E,B,D,L,V,Q,le,he,A)=>{u.jb("AveragePool",o,{format:A?"NHWC":"NCHW",auto_pad:c,ceil_mode:g,count_include_pad:w,storage_order:b,dilations:E?Array.from(n().subarray(E>>>0,B>>>0)):[],kernel_shape:D?Array.from(n().subarray(D>>>0,L>>>0)):[],pads:V?Array.from(n().subarray(V>>>0,Q>>>0)):[],strides:le?Array.from(n().subarray(le>>>0,he>>>0)):[]})},876698:(o,c)=>{u.jb("GlobalMaxPool",o,{format:c?"NHWC":"NCHW"})},876785:(o,c,g,w,b,E,B,D,L,V,Q,le,he,A)=>{u.jb("MaxPool",o,{format:A?"NHWC":"NCHW",auto_pad:c,ceil_mode:g,count_include_pad:w,storage_order:b,dilations:E?Array.from(n().subarray(E>>>0,B>>>0)):[],kernel_shape:D?Array.from(n().subarray(D>>>0,L>>>0)):[],pads:V?Array.from(n().subarray(V>>>0,Q>>>0)):[],strides:le?Array.from(n().subarray(le>>>0,he>>>0)):[]})},877196:(o,c)=>{u.jb("GlobalMaxPool",o,{format:c?"NHWC":"NCHW"})},877283:(o,c,g,w,b,E,B,D,L,V,Q,le,he,A)=>{u.jb("MaxPool",o,{format:A?"NHWC":"NCHW",auto_pad:c,ceil_mode:g,count_include_pad:w,storage_order:b,dilations:E?Array.from(n().subarray(E>>>0,B>>>0)):[],kernel_shape:D?Array.from(n().subarray(D>>>0,L>>>0)):[],pads:V?Array.from(n().subarray(V>>>0,Q>>>0)):[],strides:le?Array.from(n().subarray(le>>>0,he>>>0)):[]})},877694:(o,c,g,w,b)=>{u.jb("Gemm",o,{alpha:c,beta:g,transA:w,transB:b})},877798:o=>{u.jb("MatMul",o,void 0)},877852:(o,c,g,w)=>{u.jb("ArgMax",o,{keepDims:!!c,selectLastIndex:!!g,axis:w})},877960:(o,c,g,w)=>{u.jb("ArgMin",o,{keepDims:!!c,selectLastIndex:!!g,axis:w})},878068:(o,c)=>{u.jb("Softmax",o,{axis:c})},878131:(o,c)=>{u.jb("Concat",o,{axis:c})},878191:(o,c,g,w,b)=>{u.jb("Split",o,{axis:c,numOutputs:g,splitSizes:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},878331:o=>{u.jb("Expand",o,void 0)},878385:(o,c)=>{u.jb("Gather",o,{axis:Number(c)})},878456:(o,c)=>{u.jb("GatherElements",o,{axis:Number(c)})},878535:(o,c,g,w,b,E,B,D,L,V,Q)=>{u.jb("Resize",o,{antialias:c,axes:g?Array.from(n().subarray(g>>>0,w>>>0)):[],coordinateTransformMode:Ae(b),cubicCoeffA:E,excludeOutside:B,extrapolationValue:D,keepAspectRatioPolicy:Ae(L),mode:Ae(V),nearestMode:Ae(Q)})},878881:(o,c,g,w,b,E,B)=>{u.jb("Slice",o,{starts:c?Array.from(n().subarray(c>>>0,g>>>0)):[],ends:w?Array.from(n().subarray(w>>>0,b>>>0)):[],axes:E?Array.from(n().subarray(E>>>0,B>>>0)):[]})},879097:o=>{u.jb("Tile",o,void 0)},879149:(o,c,g)=>{u.jb("InstanceNormalization",o,{epsilon:c,format:g?"NHWC":"NCHW"})},879263:(o,c,g)=>{u.jb("InstanceNormalization",o,{epsilon:c,format:g?"NHWC":"NCHW"})},879377:o=>{u.jb("Range",o,void 0)},879430:(o,c)=>{u.jb("Einsum",o,{equation:Ae(c)})},879511:(o,c,g,w,b)=>{u.jb("Pad",o,{mode:c,value:g,pads:w?Array.from(n().subarray(w>>>0,b>>>0)):[]})},879638:(o,c,g,w,b,E)=>{u.jb("BatchNormalization",o,{epsilon:c,momentum:g,spatial:!!b,trainingMode:!!w,format:E?"NHWC":"NCHW"})},879807:(o,c,g,w,b,E)=>{u.jb("BatchNormalization",o,{epsilon:c,momentum:g,spatial:!!b,trainingMode:!!w,format:E?"NHWC":"NCHW"})},879976:(o,c,g)=>{u.jb("CumSum",o,{exclusive:Number(c),reverse:Number(g)})},880073:(o,c,g)=>{u.jb("DequantizeLinear",o,{axis:c,blockSize:g})},880163:(o,c,g,w,b,E,B,D,L)=>{u.jb("Attention",o,{numHeads:c,isUnidirectional:g,maskFilterValue:w,scale:b,doRotary:E,qkvHiddenSizes:B?Array.from(n().subarray(Number(D)>>>0,Number(D)+B>>>0)):[],pastPresentShareBuffer:!!L})},880435:o=>{u.jb("BiasAdd",o,void 0)},880490:o=>{u.jb("BiasSplitGelu",o,void 0)},880551:o=>{u.jb("FastGelu",o,void 0)},880607:(o,c,g,w,b,E,B,D,L,V,Q,le,he,A,oe,ve)=>{u.jb("Conv",o,{format:le?"NHWC":"NCHW",auto_pad:c,dilations:g?Array.from(n().subarray(g>>>0,w>>>0)):[],group:b,kernel_shape:E?Array.from(n().subarray(E>>>0,B>>>0)):[],pads:D?Array.from(n().subarray(D>>>0,L>>>0)):[],strides:V?Array.from(n().subarray(V>>>0,Q>>>0)):[],w_is_const:()=>!!t()[he>>>0],activation:Ae(A),activation_params:oe?Array.from(d().subarray(oe>>>0,ve>>>0)):[]})},881103:o=>{u.jb("Gelu",o,void 0)},881155:(o,c,g,w)=>{u.jb("GroupQueryAttention",o,{numHeads:c,kvNumHeads:g,scale:w})},881268:(o,c,g,w)=>{u.jb("LayerNormalization",o,{axis:c,epsilon:g,simplified:!!w})},881379:(o,c,g,w)=>{u.jb("LayerNormalization",o,{axis:c,epsilon:g,simplified:!!w})},881490:(o,c,g,w,b,E)=>{u.jb("MatMulNBits",o,{k:c,n:g,accuracyLevel:w,bits:b,blockSize:E})},881617:(o,c,g,w,b,E)=>{u.jb("MultiHeadAttention",o,{numHeads:c,isUnidirectional:g,maskFilterValue:w,scale:b,doRotary:E})},881776:(o,c)=>{u.jb("QuickGelu",o,{alpha:c})},881840:(o,c,g,w,b)=>{u.jb("RotaryEmbedding",o,{interleaved:!!c,numHeads:g,rotaryEmbeddingDim:w,scale:b})},881979:(o,c,g)=>{u.jb("SkipLayerNormalization",o,{epsilon:c,simplified:!!g})},882081:(o,c,g)=>{u.jb("SkipLayerNormalization",o,{epsilon:c,simplified:!!g})},882183:(o,c,g,w)=>{u.jb("GatherBlockQuantized",o,{gatherAxis:c,quantizeAxis:g,blockSize:w})},882304:o=>{u.Zb(o)},882338:(o,c)=>u.bc(o,c,u.Eb.fc,u.Eb.errors)};function Bh(o,c,g){return Qn(async()=>{await u.Xb(o,c,g)})}function Mh(){return typeof wasmOffsetConverter<"u"}function ni(o){this.name="ExitStatus",this.message=`Program terminated with exit(${o})`,this.status=o}var si=o=>{o.terminate(),o.onmessage=()=>{}},wn=o=>{ht.length==0&&(Sn(),xn(ht[0]));var c=ht.pop();if(!c)return 6;Ct.push(c),it[o.Ab]=c,c.Ab=o.Ab;var g={cmd:"run",start_routine:o.hc,arg:o.Qb,pthread_ptr:o.Ab};return c.postMessage(g,o.mc),0},Et=0,_e=(o,c,...g)=>{for(var w=2*g.length,b=ki(),E=Si(8*w),B=E>>>3,D=0;D<g.length;D++){var L=g[D];typeof L=="bigint"?(ke[B+2*D]=1n,ke[B+2*D+1]=L):(ke[B+2*D]=0n,l()[B+2*D+1>>>0]=L)}return o=bs(o,0,w,E,c),Er(b),o};function oi(o){if(y)return _e(0,1,o);if(se=o,!(0<Et)){for(var c of Ct)si(c);for(c of ht)si(c);ht=[],Ct=[],it=[],Fe=!0}I(o,new ni(o))}function $n(o){if(y)return _e(1,0,o);ui(o)}var ui=o=>{if(se=o,y)throw $n(o),"unwind";oi(o)},ht=[],Ct=[],_n=[],it={},bn=o=>{var c=o.Ab;delete it[c],ht.push(o),Ct.splice(Ct.indexOf(o),1),o.Ab=0,xi(c)};function vn(){_n.forEach(o=>o())}var xn=o=>new Promise(c=>{o.onmessage=b=>{var E=(b=b.data).cmd;if(b.targetThread&&b.targetThread!=Nt()){var B=it[b.targetThread];B?B.postMessage(b,b.transferList):K(`Internal error! Worker sent a message "${E}" to target pthread ${b.targetThread}, but that thread no longer exists!`)}else E==="checkMailbox"?yr():E==="spawnThread"?wn(b):E==="cleanupThread"?bn(it[b.thread]):E==="killThread"?(b=b.thread,E=it[b],delete it[b],si(E),xi(b),Ct.splice(Ct.indexOf(E),1),E.Ab=0):E==="cancelThread"?it[b.thread].postMessage({cmd:"cancel"}):E==="loaded"?(o.loaded=!0,c(o)):E==="alert"?alert(`Thread ${b.threadId}: ${b.text}`):b.target==="setimmediate"?o.postMessage(b):E==="callHandler"?u[b.handler](...b.args):E&&K(`worker sent an unknown command ${E}`)},o.onerror=b=>{throw K(`worker sent an error! ${b.filename}:${b.lineno}: ${b.message}`),b};var g,w=[];for(g of[])u.hasOwnProperty(g)&&w.push(g);o.postMessage({cmd:"load",handlers:w,wasmMemory:q,wasmModule:de})});function Sn(){var o=new Worker(new URL(import.meta.url),{type:"module",workerData:"em-pthread",name:"em-pthread"});ht.push(o)}var gr=o=>{for(;0<o.length;)o.shift()(u)},Ph=()=>{var o=Nt(),c=s()[o+52>>>2>>>0];o=s()[o+56>>>2>>>0],xs(c,c-o),Er(c)},Dh=(o,c)=>{Et=0,o=Ss(o,c),0<Et?se=o:Tr(o)};class Fh{constructor(c){this.Jb=c-24}}function Uh(o,c,g){var w=new Fh(o>>>=0);throw c>>>=0,g>>>=0,s()[w.Jb+16>>>2>>>0]=0,s()[w.Jb+4>>>2>>>0]=c,s()[w.Jb+8>>>2>>>0]=g,o}function kn(o,c,g,w){return y?_e(2,1,o,c,g,w):Tn(o,c,g,w)}function Tn(o,c,g,w){if(o>>>=0,c>>>=0,g>>>=0,w>>>=0,v===void 0)return K("Current environment does not support SharedArrayBuffer, pthreads are not available!"),6;var b=[];return y&&b.length===0?kn(o,c,g,w):(o={hc:g,Ab:o,Qb:w,mc:b},y?(o.Mb="spawnThread",postMessage(o,b),0):wn(o))}var En=typeof TextDecoder<"u"?new TextDecoder("utf8"):void 0,Cn=(o,c,g)=>{var w=(c>>>=0)+g;for(g=c;o[g]&&!(g>=w);)++g;if(16<g-c&&o.buffer&&En)return En.decode(o.buffer instanceof v?o.slice(c,g):o.subarray(c,g));for(w="";c<g;){var b=o[c++];if(128&b){var E=63&o[c++];if((224&b)==192)w+=String.fromCharCode((31&b)<<6|E);else{var B=63&o[c++];65536>(b=(240&b)==224?(15&b)<<12|E<<6|B:(7&b)<<18|E<<12|B<<6|63&o[c++])?w+=String.fromCharCode(b):(b-=65536,w+=String.fromCharCode(55296|b>>10,56320|1023&b))}}else w+=String.fromCharCode(b)}return w},Ae=(o,c)=>(o>>>=0)?Cn(r(),o,c):"";function In(o,c,g){return y?_e(3,1,o,c,g):0}function An(o,c){if(y)return _e(4,1,o,c)}var li=o=>{for(var c=0,g=0;g<o.length;++g){var w=o.charCodeAt(g);127>=w?c++:2047>=w?c+=2:55296<=w&&57343>=w?(c+=4,++g):c+=3}return c},zn=(o,c,g,w)=>{if(!(0<w))return 0;var b=g>>>=0;w=g+w-1;for(var E=0;E<o.length;++E){var B=o.charCodeAt(E);if(55296<=B&&57343>=B&&(B=65536+((1023&B)<<10)|1023&o.charCodeAt(++E)),127>=B){if(g>=w)break;c[g++>>>0]=B}else{if(2047>=B){if(g+1>=w)break;c[g++>>>0]=192|B>>6}else{if(65535>=B){if(g+2>=w)break;c[g++>>>0]=224|B>>12}else{if(g+3>=w)break;c[g++>>>0]=240|B>>18,c[g++>>>0]=128|B>>12&63}c[g++>>>0]=128|B>>6&63}c[g++>>>0]=128|63&B}}return c[g>>>0]=0,g-b},Dt=(o,c,g)=>zn(o,r(),c,g);function Rn(o,c){if(y)return _e(5,1,o,c)}function On(o,c,g){if(y)return _e(6,1,o,c,g)}function Bn(o,c,g){return y?_e(7,1,o,c,g):0}function Mn(o,c){if(y)return _e(8,1,o,c)}function Pn(o,c,g){if(y)return _e(9,1,o,c,g)}function Dn(o,c,g,w){if(y)return _e(10,1,o,c,g,w)}function Fn(o,c,g,w){if(y)return _e(11,1,o,c,g,w)}function Un(o,c,g,w){if(y)return _e(12,1,o,c,g,w)}function Nn(o){if(y)return _e(13,1,o)}function Wn(o,c){if(y)return _e(14,1,o,c)}function Ln(o,c,g){if(y)return _e(15,1,o,c,g)}var qn,ft,Nh=()=>{Pt("")},at=o=>{for(var c="";r()[o>>>0];)c+=qn[r()[o++>>>0]];return c},di={},pi={},Wh={};function lt(o,c,g={}){if(!("argPackAdvance"in c))throw new TypeError("registerType registeredInstance requires argPackAdvance");return function(w,b,E={}){var B=b.name;if(!w)throw new ft(`type "${B}" must have a positive integer typeid pointer`);if(pi.hasOwnProperty(w)){if(E.Sb)return;throw new ft(`Cannot register type '${B}' twice`)}pi[w]=b,delete Wh[w],di.hasOwnProperty(w)&&(b=di[w],delete di[w],b.forEach(D=>D()))}(o,c,g)}var Vn=(o,c,g)=>{switch(c){case 1:return g?w=>t()[w>>>0]:w=>r()[w>>>0];case 2:return g?w=>i()[w>>>1>>>0]:w=>a()[w>>>1>>>0];case 4:return g?w=>n()[w>>>2>>>0]:w=>s()[w>>>2>>>0];case 8:return g?w=>ke[w>>>3]:w=>De[w>>>3];default:throw new TypeError(`invalid integer width (${c}): ${o}`)}};function Lh(o,c,g){g>>>=0,lt(o>>>=0,{name:c=at(c>>>0),fromWireType:w=>w,toWireType:function(w,b){if(typeof b!="bigint"&&typeof b!="number")throw b=b===null?"null":(w=typeof b)=="object"||w==="array"||w==="function"?b.toString():""+b,new TypeError(`Cannot convert "${b}" to ${this.name}`);return typeof b=="number"&&(b=BigInt(b)),b},argPackAdvance:mt,readValueFromPointer:Vn(c,g,c.indexOf("u")==-1),Db:null})}var mt=8;function qh(o,c,g,w){lt(o>>>=0,{name:c=at(c>>>0),fromWireType:function(b){return!!b},toWireType:function(b,E){return E?g:w},argPackAdvance:mt,readValueFromPointer:function(b){return this.fromWireType(r()[b>>>0])},Db:null})}var ci=[],dt=[];function hi(o){9<(o>>>=0)&&--dt[o+1]==0&&(dt[o]=void 0,ci.push(o))}var Ve=o=>{if(!o)throw new ft("Cannot use deleted val. handle = "+o);return dt[o]},je=o=>{switch(o){case void 0:return 2;case null:return 4;case!0:return 6;case!1:return 8;default:let c=ci.pop()||dt.length;return dt[c]=o,dt[c+1]=1,c}};function fi(o){return this.fromWireType(s()[o>>>2>>>0])}var Vh={name:"emscripten::val",fromWireType:o=>{var c=Ve(o);return hi(o),c},toWireType:(o,c)=>je(c),argPackAdvance:mt,readValueFromPointer:fi,Db:null};function jh(o){return lt(o>>>0,Vh)}var Gh=(o,c)=>{switch(c){case 4:return function(g){return this.fromWireType(d()[g>>>2>>>0])};case 8:return function(g){return this.fromWireType(l()[g>>>3>>>0])};default:throw new TypeError(`invalid float width (${c}): ${o}`)}};function Hh(o,c,g){g>>>=0,lt(o>>>=0,{name:c=at(c>>>0),fromWireType:w=>w,toWireType:(w,b)=>b,argPackAdvance:mt,readValueFromPointer:Gh(c,g),Db:null})}function Kh(o,c,g,w,b){if(o>>>=0,g>>>=0,c=at(c>>>0),b===-1&&(b=4294967295),b=D=>D,w===0){var E=32-8*g;b=D=>D<<E>>>E}var B=c.includes("unsigned")?function(D,L){return L>>>0}:function(D,L){return L};lt(o,{name:c,fromWireType:b,toWireType:B,argPackAdvance:mt,readValueFromPointer:Vn(c,g,w!==0),Db:null})}function Yh(o,c,g){function w(E){var B=s()[E>>>2>>>0];return E=s()[E+4>>>2>>>0],new b(t().buffer,E,B)}var b=[Int8Array,Uint8Array,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array,BigInt64Array,BigUint64Array][c];lt(o>>>=0,{name:g=at(g>>>0),fromWireType:w,argPackAdvance:mt,readValueFromPointer:w},{Sb:!0})}function Zh(o,c){o>>>=0;var g=(c=at(c>>>0))==="std::string";lt(o,{name:c,fromWireType:function(w){var b=s()[w>>>2>>>0],E=w+4;if(g)for(var B=E,D=0;D<=b;++D){var L=E+D;if(D==b||r()[L>>>0]==0){if(B=Ae(B,L-B),V===void 0)var V=B;else V+="\0",V+=B;B=L+1}}else{for(V=Array(b),D=0;D<b;++D)V[D]=String.fromCharCode(r()[E+D>>>0]);V=V.join("")}return st(w),V},toWireType:function(w,b){b instanceof ArrayBuffer&&(b=new Uint8Array(b));var E=typeof b=="string";if(!(E||b instanceof Uint8Array||b instanceof Uint8ClampedArray||b instanceof Int8Array))throw new ft("Cannot pass non-string to std::string");var B=g&&E?li(b):b.length,D=kr(4+B+1),L=D+4;if(s()[D>>>2>>>0]=B,g&&E)Dt(b,L,B+1);else if(E)for(E=0;E<B;++E){var V=b.charCodeAt(E);if(255<V)throw st(L),new ft("String has UTF-16 code units that do not fit in 8 bits");r()[L+E>>>0]=V}else for(E=0;E<B;++E)r()[L+E>>>0]=b[E];return w!==null&&w.push(st,D),D},argPackAdvance:mt,readValueFromPointer:fi,Db(w){st(w)}})}var jn=typeof TextDecoder<"u"?new TextDecoder("utf-16le"):void 0,Qh=(o,c)=>{for(var g=o>>1,w=g+c/2;!(g>=w)&&a()[g>>>0];)++g;if(32<(g<<=1)-o&&jn)return jn.decode(r().slice(o,g));for(g="",w=0;!(w>=c/2);++w){var b=i()[o+2*w>>>1>>>0];if(b==0)break;g+=String.fromCharCode(b)}return g},Xh=(o,c,g)=>{if(g??=2147483647,2>g)return 0;var w=c;g=(g-=2)<2*o.length?g/2:o.length;for(var b=0;b<g;++b){var E=o.charCodeAt(b);i()[c>>>1>>>0]=E,c+=2}return i()[c>>>1>>>0]=0,c-w},Jh=o=>2*o.length,ef=(o,c)=>{for(var g=0,w="";!(g>=c/4);){var b=n()[o+4*g>>>2>>>0];if(b==0)break;++g,65536<=b?(b-=65536,w+=String.fromCharCode(55296|b>>10,56320|1023&b)):w+=String.fromCharCode(b)}return w},tf=(o,c,g)=>{if(c>>>=0,g??=2147483647,4>g)return 0;var w=c;g=w+g-4;for(var b=0;b<o.length;++b){var E=o.charCodeAt(b);if(55296<=E&&57343>=E&&(E=65536+((1023&E)<<10)|1023&o.charCodeAt(++b)),n()[c>>>2>>>0]=E,(c+=4)+4>g)break}return n()[c>>>2>>>0]=0,c-w},rf=o=>{for(var c=0,g=0;g<o.length;++g){var w=o.charCodeAt(g);55296<=w&&57343>=w&&++g,c+=4}return c};function af(o,c,g){if(o>>>=0,c>>>=0,g=at(g>>>=0),c===2)var w=Qh,b=Xh,E=Jh,B=D=>a()[D>>>1>>>0];else c===4&&(w=ef,b=tf,E=rf,B=D=>s()[D>>>2>>>0]);lt(o,{name:g,fromWireType:D=>{for(var L,V=s()[D>>>2>>>0],Q=D+4,le=0;le<=V;++le){var he=D+4+le*c;le!=V&&B(he)!=0||(Q=w(Q,he-Q),L===void 0?L=Q:(L+="\0",L+=Q),Q=he+c)}return st(D),L},toWireType:(D,L)=>{if(typeof L!="string")throw new ft(`Cannot pass non-string to C++ string type ${g}`);var V=E(L),Q=kr(4+V+c);return s()[Q>>>2>>>0]=V/c,b(L,Q+4,V+c),D!==null&&D.push(st,Q),Q},argPackAdvance:mt,readValueFromPointer:fi,Db(D){st(D)}})}function nf(o,c){lt(o>>>=0,{Tb:!0,name:c=at(c>>>0),argPackAdvance:0,fromWireType:()=>{},toWireType:()=>{}})}var sf=()=>1;function of(o){vi(o>>>0,!f,1,!$,131072,!1),vn()}var Gn=o=>{if(!Fe)try{if(o(),!(0<Et))try{y?Tr(se):ui(se)}catch(c){c instanceof ni||c=="unwind"||I(1,c)}}catch(c){c instanceof ni||c=="unwind"||I(1,c)}};function mi(o){o>>>=0,typeof Atomics.nc=="function"&&(Atomics.nc(n(),o>>>2,o).value.then(yr),o+=128,Atomics.store(n(),o>>>2,1))}var yr=()=>{var o=Nt();o&&(mi(o),Gn(vs))};function uf(o,c){(o>>>=0)==c>>>0?setTimeout(yr):y?postMessage({targetThread:o,cmd:"checkMailbox"}):(o=it[o])&&o.postMessage({cmd:"checkMailbox"})}var gi=[];function lf(o,c,g,w,b){for(c>>>=0,w/=2,gi.length=w,g=b>>>0>>>3,b=0;b<w;b++)gi[b]=ke[g+2*b]?ke[g+2*b+1]:l()[g+2*b+1>>>0];return(c?ai[c]:Xf[o])(...gi)}function df(o){o>>>=0,y?postMessage({cmd:"cleanupThread",thread:o}):bn(it[o])}function pf(o){}var yi=(o,c)=>{var g=pi[o];if(g===void 0)throw o=ws(o),g=at(o),st(o),new ft(`${c} has unknown type ${g}`);return g},Hn=(o,c,g)=>{var w=[];return o=o.toWireType(w,g),w.length&&(s()[c>>>2>>>0]=je(w)),o};function cf(o,c,g){return c>>>=0,g>>>=0,o=Ve(o>>>0),c=yi(c,"emval::as"),Hn(c,g,o)}var wr=o=>{try{o()}catch(c){Pt(c)}},gt=0,nt=null,Kn=0,$r=[],Yn={},Zn={},hf=0,wi=null,ff=[];function Qn(o){return function(c){if(!Fe){if(gt===0){var g=!1,w=!1;c((b=0)=>{if(!Fe&&(Kn=b,g=!0,w)){gt=2,wr(()=>Es(nt)),typeof Browser<"u"&&Browser.Kb.Rb&&Browser.Kb.resume(),b=!1;try{var E=function(){var L=n()[nt+8>>>2>>>0];return L=Z[Zn[L]],--Et,L()}()}catch(L){E=L,b=!0}var B=!1;if(!nt){var D=wi;D&&(wi=null,(b?D.reject:D.resolve)(E),B=!0)}if(b&&!B)throw E}}),w=!0,g||(gt=1,nt=function(){var b=kr(65548),E=b+12;s()[b>>>2>>>0]=E,s()[b+4>>>2>>>0]=E+65536,E=$r[0];var B=Yn[E];return B===void 0&&(B=hf++,Yn[E]=B,Zn[B]=E),E=B,n()[b+8>>>2>>>0]=E,b}(),typeof Browser<"u"&&Browser.Kb.Rb&&Browser.Kb.pause(),wr(()=>ks(nt)))}else gt===2?(gt=0,wr(Cs),st(nt),nt=null,ff.forEach(Gn)):Pt(`invalid state: ${gt}`);return Kn}}(c=>{o().then(c)})}function mf(o){return o>>>=0,Qn(()=>(o=Ve(o)).then(je))}var _r=[];function gf(o,c,g,w){return g>>>=0,w>>>=0,(o=_r[o>>>0])(null,c=Ve(c>>>0),g,w)}var yf={},br=o=>{var c=yf[o];return c===void 0?at(o):c};function wf(o,c,g,w,b){return g>>>=0,w>>>=0,b>>>=0,(o=_r[o>>>0])(c=Ve(c>>>0),c[g=br(g)],w,b)}var Xn=()=>typeof globalThis=="object"?globalThis:Function("return this")();function $f(o){return(o>>>=0)==0?je(Xn()):(o=br(o),je(Xn()[o]))}var _f=o=>{var c=_r.length;return _r.push(o),c},bf=(o,c)=>{for(var g=Array(o),w=0;w<o;++w)g[w]=yi(s()[c+4*w>>>2>>>0],"parameter "+w);return g},Jn=(o,c)=>Object.defineProperty(c,"name",{value:o});function vf(o,c,g){var w=(c=bf(o,c>>>0)).shift();o--;var b=`return function (obj, func, destructorsRef, args) {
`,E=0,B=[];g===0&&B.push("obj");for(var D=["retType"],L=[w],V=0;V<o;++V)B.push("arg"+V),D.push("argType"+V),L.push(c[V]),b+=`  var arg${V} = argType${V}.readValueFromPointer(args${E?"+"+E:""});
`,E+=c[V].argPackAdvance;return b+=`  var rv = ${g===1?"new func":"func.call"}(${B.join(", ")});
`,w.Tb||(D.push("emval_returnValue"),L.push(Hn),b+=`  return emval_returnValue(retType, destructorsRef, rv);
`),D.push(b+`};
`),o=function(Q){var le=Function;if(!(le instanceof Function))throw new TypeError(`new_ called with constructor type ${typeof le} which is not a function`);var he=Jn(le.name||"unknownFunctionName",function(){});return he.prototype=le.prototype,he=new he,(Q=le.apply(he,Q))instanceof Object?Q:he}(D)(...L),g=`methodCaller<(${c.map(Q=>Q.name).join(", ")}) => ${w.name}>`,_f(Jn(g,o))}function xf(o){return o=br(o>>>0),je(u[o])}function Sf(o,c){return c>>>=0,o=Ve(o>>>0),c=Ve(c),je(o[c])}function kf(o){9<(o>>>=0)&&(dt[o+1]+=1)}function Tf(){return je([])}function Ef(o){o=Ve(o>>>0);for(var c=Array(o.length),g=0;g<o.length;g++)c[g]=o[g];return je(c)}function Cf(o){return je(br(o>>>0))}function If(){return je({})}function Af(o){for(var c=Ve(o>>>=0);c.length;){var g=c.pop();c.pop()(g)}hi(o)}function zf(o,c,g){c>>>=0,g>>>=0,o=Ve(o>>>0),c=Ve(c),g=Ve(g),o[c]=g}function Rf(o,c){return c>>>=0,o=(o=yi(o>>>0,"_emval_take_value")).readValueFromPointer(c),je(o)}function Of(o,c){o=-9007199254740992>o||9007199254740992<o?NaN:Number(o),c>>>=0,o=new Date(1e3*o),n()[c>>>2>>>0]=o.getUTCSeconds(),n()[c+4>>>2>>>0]=o.getUTCMinutes(),n()[c+8>>>2>>>0]=o.getUTCHours(),n()[c+12>>>2>>>0]=o.getUTCDate(),n()[c+16>>>2>>>0]=o.getUTCMonth(),n()[c+20>>>2>>>0]=o.getUTCFullYear()-1900,n()[c+24>>>2>>>0]=o.getUTCDay(),o=(o.getTime()-Date.UTC(o.getUTCFullYear(),0,1,0,0,0,0))/864e5|0,n()[c+28>>>2>>>0]=o}var Ft=o=>o%4==0&&(o%100!=0||o%400==0),es=[0,31,60,91,121,152,182,213,244,274,305,335],ts=[0,31,59,90,120,151,181,212,243,273,304,334];function Bf(o,c){o=-9007199254740992>o||9007199254740992<o?NaN:Number(o),c>>>=0,o=new Date(1e3*o),n()[c>>>2>>>0]=o.getSeconds(),n()[c+4>>>2>>>0]=o.getMinutes(),n()[c+8>>>2>>>0]=o.getHours(),n()[c+12>>>2>>>0]=o.getDate(),n()[c+16>>>2>>>0]=o.getMonth(),n()[c+20>>>2>>>0]=o.getFullYear()-1900,n()[c+24>>>2>>>0]=o.getDay();var g=(Ft(o.getFullYear())?es:ts)[o.getMonth()]+o.getDate()-1|0;n()[c+28>>>2>>>0]=g,n()[c+36>>>2>>>0]=-60*o.getTimezoneOffset(),g=new Date(o.getFullYear(),6,1).getTimezoneOffset();var w=new Date(o.getFullYear(),0,1).getTimezoneOffset();o=0|(g!=w&&o.getTimezoneOffset()==Math.min(w,g)),n()[c+32>>>2>>>0]=o}function Mf(o){o>>>=0;var c=new Date(n()[o+20>>>2>>>0]+1900,n()[o+16>>>2>>>0],n()[o+12>>>2>>>0],n()[o+8>>>2>>>0],n()[o+4>>>2>>>0],n()[o>>>2>>>0],0),g=n()[o+32>>>2>>>0],w=c.getTimezoneOffset(),b=new Date(c.getFullYear(),6,1).getTimezoneOffset(),E=new Date(c.getFullYear(),0,1).getTimezoneOffset(),B=Math.min(E,b);return 0>g?n()[o+32>>>2>>>0]=+(b!=E&&B==w):0<g!=(B==w)&&(b=Math.max(E,b),c.setTime(c.getTime()+6e4*((0<g?B:b)-w))),n()[o+24>>>2>>>0]=c.getDay(),g=(Ft(c.getFullYear())?es:ts)[c.getMonth()]+c.getDate()-1|0,n()[o+28>>>2>>>0]=g,n()[o>>>2>>>0]=c.getSeconds(),n()[o+4>>>2>>>0]=c.getMinutes(),n()[o+8>>>2>>>0]=c.getHours(),n()[o+12>>>2>>>0]=c.getDate(),n()[o+16>>>2>>>0]=c.getMonth(),n()[o+20>>>2>>>0]=c.getYear(),o=c.getTime(),BigInt(isNaN(o)?-1:o/1e3)}function rs(o,c,g,w,b,E,B){return y?_e(16,1,o,c,g,w,b,E,B):-52}function is(o,c,g,w,b,E){if(y)return _e(17,1,o,c,g,w,b,E)}function Pf(o,c,g,w){o>>>=0,c>>>=0,g>>>=0,w>>>=0;var b=new Date().getFullYear(),E=new Date(b,0,1),B=new Date(b,6,1);b=E.getTimezoneOffset();var D=B.getTimezoneOffset(),L=Math.max(b,D);s()[o>>>2>>>0]=60*L,n()[c>>>2>>>0]=+(b!=D),E=(o=V=>V.toLocaleTimeString(void 0,{hour12:!1,timeZoneName:"short"}).split(" ")[1])(E),B=o(B),D<b?(Dt(E,g,17),Dt(B,w,17)):(Dt(E,w,17),Dt(B,g,17))}var $i=[],as=(o,c)=>{$i.length=0;for(var g;g=r()[o++>>>0];){var w=g!=105;c+=(w&=g!=112)&&c%8?4:0,$i.push(g==112?s()[c>>>2>>>0]:g==106?ke[c>>>3]:g==105?n()[c>>>2>>>0]:l()[c>>>3>>>0]),c+=w?8:4}return $i};function Df(o,c,g){return o>>>=0,c=as(c>>>0,g>>>0),ai[o](...c)}function Ff(o,c,g){return o>>>=0,c=as(c>>>0,g>>>0),ai[o](...c)}var Uf=()=>{},Nf=()=>Date.now();function Wf(o,c){return K(Ae(o>>>0,c>>>0))}var ns,Lf=()=>{throw Et+=1,"unwind"};function qf(){return 4294901760}ns=()=>performance.timeOrigin+performance.now();var Vf=()=>navigator.hardwareConcurrency;function jf(){return Pt("Cannot use emscripten_pc_get_function without -sUSE_OFFSET_CONVERTER"),0}function Gf(o){o>>>=0;var c=r().length;if(o<=c||4294901760<o)return!1;for(var g=1;4>=g;g*=2){var w=c*(1+.2/g);w=Math.min(w,o+100663296);var b=Math;w=Math.max(o,w);e:{b=(b.min.call(b,4294901760,w+(65536-w%65536)%65536)-q.buffer.byteLength+65535)/65536;try{q.grow(b),me();var E=1;break e}catch{}E=void 0}if(E)return!0}return!1}var vr=()=>(Pt("Cannot use convertFrameToPC (needed by __builtin_return_address) without -sUSE_OFFSET_CONVERTER"),0),Ut={},ss=o=>{o.forEach(c=>{var g=vr();g&&(Ut[g]=c)})};function Hf(){var o=Error().stack.toString().split(`
`);return o[0]=="Error"&&o.shift(),ss(o),Ut.Pb=vr(),Ut.ec=o,Ut.Pb}function Kf(o,c,g){if(o>>>=0,c>>>=0,Ut.Pb==o)var w=Ut.ec;else(w=Error().stack.toString().split(`
`))[0]=="Error"&&w.shift(),ss(w);for(var b=3;w[b]&&vr()!=o;)++b;for(o=0;o<g&&w[o+b];++o)n()[c+4*o>>>2>>>0]=vr();return o}var _i,bi={},os=()=>{if(!_i){var o,c={USER:"web_user",LOGNAME:"web_user",PATH:"/",PWD:"/",HOME:"/home/web_user",LANG:(typeof navigator=="object"&&navigator.languages&&navigator.languages[0]||"C").replace("-","_")+".UTF-8",_:T||"./this.program"};for(o in bi)bi[o]===void 0?delete c[o]:c[o]=bi[o];var g=[];for(o in c)g.push(`${o}=${c[o]}`);_i=g}return _i};function us(o,c){if(y)return _e(18,1,o,c);o>>>=0,c>>>=0;var g=0;return os().forEach((w,b)=>{var E=c+g;for(b=s()[o+4*b>>>2>>>0]=E,E=0;E<w.length;++E)t()[b++>>>0]=w.charCodeAt(E);t()[b>>>0]=0,g+=w.length+1}),0}function ls(o,c){if(y)return _e(19,1,o,c);o>>>=0,c>>>=0;var g=os();s()[o>>>2>>>0]=g.length;var w=0;return g.forEach(b=>w+=b.length+1),s()[c>>>2>>>0]=w,0}function ds(o){return y?_e(20,1,o):52}function ps(o,c,g,w){return y?_e(21,1,o,c,g,w):52}function cs(o,c,g,w){return y?_e(22,1,o,c,g,w):70}var Yf=[null,[],[]];function hs(o,c,g,w){if(y)return _e(23,1,o,c,g,w);c>>>=0,g>>>=0,w>>>=0;for(var b=0,E=0;E<g;E++){var B=s()[c>>>2>>>0],D=s()[c+4>>>2>>>0];c+=8;for(var L=0;L<D;L++){var V=r()[B+L>>>0],Q=Yf[o];V===0||V===10?((o===1?J:K)(Cn(Q,0)),Q.length=0):Q.push(V)}b+=D}return s()[w>>>2>>>0]=b,0}var fs=[31,29,31,30,31,30,31,31,30,31,30,31],ms=[31,28,31,30,31,30,31,31,30,31,30,31],Zf=(o,c)=>{t().set(o,c>>>0)};function gs(o,c,g,w){function b(A,oe,ve){for(A=typeof A=="number"?A.toString():A||"";A.length<oe;)A=ve[0]+A;return A}function E(A,oe){return b(A,oe,"0")}function B(A,oe){function ve(As){return 0>As?-1:0<As?1:0}var It;return(It=ve(A.getFullYear()-oe.getFullYear()))===0&&(It=ve(A.getMonth()-oe.getMonth()))===0&&(It=ve(A.getDate()-oe.getDate())),It}function D(A){switch(A.getDay()){case 0:return new Date(A.getFullYear()-1,11,29);case 1:return A;case 2:return new Date(A.getFullYear(),0,3);case 3:return new Date(A.getFullYear(),0,2);case 4:return new Date(A.getFullYear(),0,1);case 5:return new Date(A.getFullYear()-1,11,31);case 6:return new Date(A.getFullYear()-1,11,30)}}function L(A){var oe=A.Bb;for(A=new Date(new Date(A.Cb+1900,0,1).getTime());0<oe;){var ve=A.getMonth(),It=(Ft(A.getFullYear())?fs:ms)[ve];if(!(oe>It-A.getDate())){A.setDate(A.getDate()+oe);break}oe-=It-A.getDate()+1,A.setDate(1),11>ve?A.setMonth(ve+1):(A.setMonth(0),A.setFullYear(A.getFullYear()+1))}return ve=new Date(A.getFullYear()+1,0,4),oe=D(new Date(A.getFullYear(),0,4)),ve=D(ve),0>=B(oe,A)?0>=B(ve,A)?A.getFullYear()+1:A.getFullYear():A.getFullYear()-1}o>>>=0,c>>>=0,g>>>=0,w>>>=0;var V=s()[w+40>>>2>>>0];for(var Q in w={kc:n()[w>>>2>>>0],jc:n()[w+4>>>2>>>0],Hb:n()[w+8>>>2>>>0],Lb:n()[w+12>>>2>>>0],Ib:n()[w+16>>>2>>>0],Cb:n()[w+20>>>2>>>0],ub:n()[w+24>>>2>>>0],Bb:n()[w+28>>>2>>>0],rc:n()[w+32>>>2>>>0],ic:n()[w+36>>>2>>>0],lc:V?Ae(V):""},g=Ae(g),V={"%c":"%a %b %d %H:%M:%S %Y","%D":"%m/%d/%y","%F":"%Y-%m-%d","%h":"%b","%r":"%I:%M:%S %p","%R":"%H:%M","%T":"%H:%M:%S","%x":"%m/%d/%y","%X":"%H:%M:%S","%Ec":"%c","%EC":"%C","%Ex":"%m/%d/%y","%EX":"%H:%M:%S","%Ey":"%y","%EY":"%Y","%Od":"%d","%Oe":"%e","%OH":"%H","%OI":"%I","%Om":"%m","%OM":"%M","%OS":"%S","%Ou":"%u","%OU":"%U","%OV":"%V","%Ow":"%w","%OW":"%W","%Oy":"%y"})g=g.replace(new RegExp(Q,"g"),V[Q]);var le="Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),he="January February March April May June July August September October November December".split(" ");for(Q in V={"%a":A=>le[A.ub].substring(0,3),"%A":A=>le[A.ub],"%b":A=>he[A.Ib].substring(0,3),"%B":A=>he[A.Ib],"%C":A=>E((A.Cb+1900)/100|0,2),"%d":A=>E(A.Lb,2),"%e":A=>b(A.Lb,2," "),"%g":A=>L(A).toString().substring(2),"%G":L,"%H":A=>E(A.Hb,2),"%I":A=>((A=A.Hb)==0?A=12:12<A&&(A-=12),E(A,2)),"%j":A=>{for(var oe=0,ve=0;ve<=A.Ib-1;oe+=(Ft(A.Cb+1900)?fs:ms)[ve++]);return E(A.Lb+oe,3)},"%m":A=>E(A.Ib+1,2),"%M":A=>E(A.jc,2),"%n":()=>`
`,"%p":A=>0<=A.Hb&&12>A.Hb?"AM":"PM","%S":A=>E(A.kc,2),"%t":()=>"	","%u":A=>A.ub||7,"%U":A=>E(Math.floor((A.Bb+7-A.ub)/7),2),"%V":A=>{var oe=Math.floor((A.Bb+7-(A.ub+6)%7)/7);if(2>=(A.ub+371-A.Bb-2)%7&&oe++,oe)oe==53&&((ve=(A.ub+371-A.Bb)%7)==4||ve==3&&Ft(A.Cb)||(oe=1));else{oe=52;var ve=(A.ub+7-A.Bb-1)%7;(ve==4||ve==5&&Ft(A.Cb%400-1))&&oe++}return E(oe,2)},"%w":A=>A.ub,"%W":A=>E(Math.floor((A.Bb+7-(A.ub+6)%7)/7),2),"%y":A=>(A.Cb+1900).toString().substring(2),"%Y":A=>A.Cb+1900,"%z":A=>{var oe=0<=(A=A.ic);return A=Math.abs(A)/60,(oe?"+":"-")+("0000"+(A/60*100+A%60)).slice(-4)},"%Z":A=>A.lc,"%%":()=>"%"},g=g.replace(/%%/g,"\0\0"),V)g.includes(Q)&&(g=g.replace(new RegExp(Q,"g"),V[Q](w)));return Q=function(A){var oe=Array(li(A)+1);return zn(A,oe,0,oe.length),oe}(g=g.replace(/\0\0/g,"%")),Q.length>c?0:(Zf(Q,o),Q.length-1)}function Qf(o,c,g,w){return gs(o>>>0,c>>>0,g>>>0,w>>>0)}y||function(){for(var o=u.numThreads-1;o--;)Sn();Ie.unshift(()=>{Tt++,function(c){y?c():Promise.all(ht.map(xn)).then(c)}(()=>cn())})}();for(var ys=Array(256),xr=0;256>xr;++xr)ys[xr]=String.fromCharCode(xr);qn=ys,ft=u.BindingError=class extends Error{constructor(o){super(o),this.name="BindingError"}},u.InternalError=class extends Error{constructor(o){super(o),this.name="InternalError"}},dt.push(0,1,void 0,1,null,1,!0,1,!1,1),u.count_emval_handles=()=>dt.length/2-5-ci.length;var Xf=[oi,$n,kn,In,An,Rn,On,Bn,Mn,Pn,Dn,Fn,Un,Nn,Wn,Ln,rs,is,us,ls,ds,ps,cs,hs],Z=function(){function o(g,w){return Z=g.exports,Z=function(){var b=Z,E={};for(let[B,D]of Object.entries(b))E[B]=typeof D=="function"?(...L)=>{$r.push(B);try{return D(...L)}finally{Fe||($r.pop(),nt&&gt===1&&$r.length===0&&(gt=0,Et+=1,wr(Ts),typeof Fibers<"u"&&Fibers.sc()))}}:D;return E}(),Z=function(){var b=Z,E=D=>L=>D(L)>>>0,B=D=>()=>D()>>>0;return(b=Object.assign({},b)).Ca=E(b.Ca),b.fb=B(b.fb),b.gb=E(b.gb),b.emscripten_main_runtime_thread_id=B(b.emscripten_main_runtime_thread_id),b.sb=E(b.sb),b.tb=B(b.tb),b}(),_n.push(Z.ib),rt.unshift(Z.Ba),de=w,cn(),Z}var c=yn();if(Tt++,u.instantiateWasm)try{return u.instantiateWasm(c,o)}catch(g){K(`Module.instantiateWasm callback failed with error: ${g}`),h(g)}return ii||=u.locateFile?hn("ort-wasm-simd-threaded.jsep.wasm")?"ort-wasm-simd-threaded.jsep.wasm":u.locateFile?u.locateFile("ort-wasm-simd-threaded.jsep.wasm",C):C+"ort-wasm-simd-threaded.jsep.wasm":new URL("ort-wasm-simd-threaded.jsep.wasm",import.meta.url).href,function(g,w){var b=ii;return M||typeof WebAssembly.instantiateStreaming!="function"||hn(b)||fn(b)||typeof fetch!="function"?gn(b,g,w):fetch(b,{credentials:"same-origin"}).then(E=>WebAssembly.instantiateStreaming(E,g).then(w,function(B){return K(`wasm streaming compile failed: ${B}`),K("falling back to ArrayBuffer instantiation"),gn(b,g,w)}))}(c,function(g){o(g.instance,g.module)}).catch(h),{}}(),ws=o=>(ws=Z.Ca)(o),$s=()=>($s=Z.Da)();u._OrtInit=(o,c)=>(u._OrtInit=Z.Ea)(o,c),u._OrtGetLastError=(o,c)=>(u._OrtGetLastError=Z.Fa)(o,c),u._OrtCreateSessionOptions=(o,c,g,w,b,E,B,D,L,V)=>(u._OrtCreateSessionOptions=Z.Ga)(o,c,g,w,b,E,B,D,L,V),u._OrtAppendExecutionProvider=(o,c)=>(u._OrtAppendExecutionProvider=Z.Ha)(o,c),u._OrtAddFreeDimensionOverride=(o,c,g)=>(u._OrtAddFreeDimensionOverride=Z.Ia)(o,c,g),u._OrtAddSessionConfigEntry=(o,c,g)=>(u._OrtAddSessionConfigEntry=Z.Ja)(o,c,g),u._OrtReleaseSessionOptions=o=>(u._OrtReleaseSessionOptions=Z.Ka)(o),u._OrtCreateSession=(o,c,g)=>(u._OrtCreateSession=Z.La)(o,c,g),u._OrtReleaseSession=o=>(u._OrtReleaseSession=Z.Ma)(o),u._OrtGetInputOutputCount=(o,c,g)=>(u._OrtGetInputOutputCount=Z.Na)(o,c,g),u._OrtGetInputName=(o,c)=>(u._OrtGetInputName=Z.Oa)(o,c),u._OrtGetOutputName=(o,c)=>(u._OrtGetOutputName=Z.Pa)(o,c),u._OrtFree=o=>(u._OrtFree=Z.Qa)(o),u._OrtCreateTensor=(o,c,g,w,b,E)=>(u._OrtCreateTensor=Z.Ra)(o,c,g,w,b,E),u._OrtGetTensorData=(o,c,g,w,b)=>(u._OrtGetTensorData=Z.Sa)(o,c,g,w,b),u._OrtReleaseTensor=o=>(u._OrtReleaseTensor=Z.Ta)(o),u._OrtCreateRunOptions=(o,c,g,w)=>(u._OrtCreateRunOptions=Z.Ua)(o,c,g,w),u._OrtAddRunConfigEntry=(o,c,g)=>(u._OrtAddRunConfigEntry=Z.Va)(o,c,g),u._OrtReleaseRunOptions=o=>(u._OrtReleaseRunOptions=Z.Wa)(o),u._OrtCreateBinding=o=>(u._OrtCreateBinding=Z.Xa)(o),u._OrtBindInput=(o,c,g)=>(u._OrtBindInput=Z.Ya)(o,c,g),u._OrtBindOutput=(o,c,g,w)=>(u._OrtBindOutput=Z.Za)(o,c,g,w),u._OrtClearBoundOutputs=o=>(u._OrtClearBoundOutputs=Z._a)(o),u._OrtReleaseBinding=o=>(u._OrtReleaseBinding=Z.$a)(o),u._OrtRunWithBinding=(o,c,g,w,b)=>(u._OrtRunWithBinding=Z.ab)(o,c,g,w,b),u._OrtRun=(o,c,g,w,b,E,B,D)=>(u._OrtRun=Z.bb)(o,c,g,w,b,E,B,D),u._OrtEndProfiling=o=>(u._OrtEndProfiling=Z.cb)(o),u._JsepOutput=(o,c,g)=>(u._JsepOutput=Z.db)(o,c,g),u._JsepGetNodeName=o=>(u._JsepGetNodeName=Z.eb)(o);var Sr,Nt=()=>(Nt=Z.fb)(),kr=u._malloc=o=>(kr=u._malloc=Z.gb)(o),st=u._free=o=>(st=u._free=Z.hb)(o),vi=(o,c,g,w,b,E)=>(vi=Z.kb)(o,c,g,w,b,E),_s=()=>(_s=Z.lb)(),bs=(o,c,g,w,b)=>(bs=Z.mb)(o,c,g,w,b),xi=o=>(xi=Z.nb)(o),Tr=o=>(Tr=Z.ob)(o),vs=()=>(vs=Z.pb)(),xs=(o,c)=>(xs=Z.qb)(o,c),Er=o=>(Er=Z.rb)(o),Si=o=>(Si=Z.sb)(o),ki=()=>(ki=Z.tb)(),Ss=u.dynCall_ii=(o,c)=>(Ss=u.dynCall_ii=Z.vb)(o,c),ks=o=>(ks=Z.wb)(o),Ts=()=>(Ts=Z.xb)(),Es=o=>(Es=Z.yb)(o),Cs=()=>(Cs=Z.zb)();function Is(){0<Tt||(y?(p(u),y||gr(rt),startWorker(u)):(gr(Ie),0<Tt||Sr||(Sr=!0,u.calledRun=!0,Fe||(y||gr(rt),p(u),y||gr(mr)))))}return u.___start_em_js=882450,u.___stop_em_js=882672,u.stackSave=()=>ki(),u.stackRestore=o=>Er(o),u.stackAlloc=o=>Si(o),u.UTF8ToString=Ae,u.stringToUTF8=Dt,u.lengthBytesUTF8=li,Yt=function o(){Sr||Is(),Sr||(Yt=o)},Is(),m}),vd=Ri,globalThis.self?.name==="em-pthread"&&Ri()}),Lt,Ms,Ps,Ds,Oi,xd,Fs,Sd,Xr=F(()=>{"use strict";Ma(),Lt=import.meta.url??(typeof document<"u"?document.currentScript?.src:typeof self<"u"?self.location?.href:void 0),Ms=typeof location>"u"?void 0:location.origin,Ps=(e,t)=>{try{let r=t??Lt;return(r?new URL(e,r):new URL(e)).origin===Ms}catch{return!1}},Ds=async e=>{let t=await(await fetch(e,{credentials:"same-origin"})).blob();return URL.createObjectURL(t)},Oi=(bm(),Lr($d)).default,xd=async()=>{if(!Lt)throw new Error("Failed to load proxy worker: cannot determine the script source URL.");if(Ps(Lt))return[void 0,Oi()];let e=await Ds(Lt);return[e,Oi(e)]},Fs=(vm(),Lr(bd)).default,Sd=async(e,t,r)=>[void 0,Fs]}),Bi,Ir,Qt,Mi,Us,Ns,Pa,Ce,Mt=F(()=>{"use strict";Xr(),Ir=!1,Qt=!1,Mi=!1,Us=()=>{if(typeof SharedArrayBuffer>"u")return!1;try{return typeof MessageChannel<"u"&&new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)),WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,5,4,1,3,1,1,10,11,1,9,0,65,0,254,16,2,0,26,11]))}catch{return!1}},Ns=()=>{try{return WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,10,30,1,28,0,65,0,253,15,253,12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,253,186,1,26,11]))}catch{return!1}},Pa=async e=>{if(Ir)return Promise.resolve();if(Qt)throw new Error("multiple calls to 'initializeWebAssembly()' detected.");if(Mi)throw new Error("previous call to 'initializeWebAssembly()' failed.");Qt=!0;let t=e.initTimeout,r=e.numThreads;if(!Ns())throw new Error("WebAssembly SIMD is not supported in the current environment.");let i=Us();r>1&&!i&&(typeof self<"u"&&!self.crossOriginIsolated&&console.warn("env.wasm.numThreads is set to "+r+", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."),console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."),e.numThreads=r=1);let a=e.wasmPaths,n=typeof a=="string"?a:void 0,s=a?.mjs,d=s?.href??s,l=a?.wasm,p=l?.href??l,h=e.wasmBinary,[u,m]=await Sd(d,n,r>1),$=!1,f=[];if(t>0&&f.push(new Promise(y=>{setTimeout(()=>{$=!0,y()},t)})),f.push(new Promise((y,v)=>{let x={numThreads:r};h?x.wasmBinary=h:(p||n)&&(x.locateFile=(_,S)=>p??(n??S)+_),m(x).then(_=>{Qt=!1,Ir=!0,Bi=_,y(),u&&URL.revokeObjectURL(u)},_=>{Qt=!1,Mi=!0,v(_)})})),await Promise.race(f),$)throw new Error(`WebAssembly backend initializing failed due to timeout: ${t}ms`)},Ce=()=>{if(Ir&&Bi)return Bi;throw new Error("WebAssembly is not initialized yet.")}}),Re,Vr,xe,Da=F(()=>{"use strict";Mt(),Re=(e,t)=>{let r=Ce(),i=r.lengthBytesUTF8(e)+1,a=r._malloc(i);return r.stringToUTF8(e,a,i),t.push(a),a},Vr=(e,t,r,i)=>{if(typeof e=="object"&&e!==null){if(r.has(e))throw new Error("Circular reference in options");r.add(e)}Object.entries(e).forEach(([a,n])=>{let s=t?t+a:a;if(typeof n=="object")Vr(n,s+".",r,i);else if(typeof n=="string"||typeof n=="number")i(s,n.toString());else if(typeof n=="boolean")i(s,n?"1":"0");else throw new Error(`Can't handle extra config type: ${typeof n}`)})},xe=e=>{let t=Ce(),r=t.stackSave();try{let i=t.stackAlloc(8);t._OrtGetLastError(i,i+4);let a=t.HEAP32[i/4],n=t.HEAPU32[i/4+1],s=n?t.UTF8ToString(n):"";throw new Error(`${e} ERROR_CODE: ${a}, ERROR_MESSAGE: ${s}`)}finally{t.stackRestore(r)}}}),kd,xm=F(()=>{"use strict";Mt(),Da(),kd=e=>{let t=Ce(),r=0,i=[],a=e||{};try{if(e?.logSeverityLevel===void 0)a.logSeverityLevel=2;else if(typeof e.logSeverityLevel!="number"||!Number.isInteger(e.logSeverityLevel)||e.logSeverityLevel<0||e.logSeverityLevel>4)throw new Error(`log serverity level is not valid: ${e.logSeverityLevel}`);if(e?.logVerbosityLevel===void 0)a.logVerbosityLevel=0;else if(typeof e.logVerbosityLevel!="number"||!Number.isInteger(e.logVerbosityLevel))throw new Error(`log verbosity level is not valid: ${e.logVerbosityLevel}`);e?.terminate===void 0&&(a.terminate=!1);let n=0;return e?.tag!==void 0&&(n=Re(e.tag,i)),r=t._OrtCreateRunOptions(a.logSeverityLevel,a.logVerbosityLevel,!!a.terminate,n),r===0&&xe("Can't create run options."),e?.extra!==void 0&&Vr(e.extra,"",new WeakSet,(s,d)=>{let l=Re(s,i),p=Re(d,i);t._OrtAddRunConfigEntry(r,l,p)!==0&&xe(`Can't set a run config entry: ${s} - ${d}.`)}),[r,i]}catch(n){throw r!==0&&t._OrtReleaseRunOptions(r),i.forEach(s=>t._free(s)),n}}}),Ws,Ls,qs,Vs,Td,Sm=F(()=>{"use strict";Mt(),Da(),Ws=e=>{switch(e){case"disabled":return 0;case"basic":return 1;case"extended":return 2;case"all":return 99;default:throw new Error(`unsupported graph optimization level: ${e}`)}},Ls=e=>{switch(e){case"sequential":return 0;case"parallel":return 1;default:throw new Error(`unsupported execution mode: ${e}`)}},qs=e=>{e.extra||(e.extra={}),e.extra.session||(e.extra.session={});let t=e.extra.session;t.use_ort_model_bytes_directly||(t.use_ort_model_bytes_directly="1"),e.executionProviders&&e.executionProviders.some(r=>(typeof r=="string"?r:r.name)==="webgpu")&&(e.enableMemPattern=!1)},Vs=(e,t,r)=>{for(let i of t){let a=typeof i=="string"?i:i.name;switch(a){case"webnn":if(a="WEBNN",typeof i!="string"){let s=i?.deviceType;if(s){let d=Re("deviceType",r),l=Re(s,r);Ce()._OrtAddSessionConfigEntry(e,d,l)!==0&&xe(`Can't set a session config entry: 'deviceType' - ${s}.`)}}break;case"webgpu":if(a="JS",typeof i!="string"){let s=i;if(s?.preferredLayout){if(s.preferredLayout!=="NCHW"&&s.preferredLayout!=="NHWC")throw new Error(`preferredLayout must be either 'NCHW' or 'NHWC': ${s.preferredLayout}`);let d=Re("preferredLayout",r),l=Re(s.preferredLayout,r);Ce()._OrtAddSessionConfigEntry(e,d,l)!==0&&xe(`Can't set a session config entry: 'preferredLayout' - ${s.preferredLayout}.`)}}break;case"wasm":case"cpu":continue;default:throw new Error(`not supported execution provider: ${a}`)}let n=Re(a,r);Ce()._OrtAppendExecutionProvider(e,n)!==0&&xe(`Can't append execution provider: ${a}.`)}},Td=e=>{let t=Ce(),r=0,i=[],a=e||{};qs(a);try{let n=Ws(a.graphOptimizationLevel??"all"),s=Ls(a.executionMode??"sequential"),d=typeof a.logId=="string"?Re(a.logId,i):0,l=a.logSeverityLevel??2;if(!Number.isInteger(l)||l<0||l>4)throw new Error(`log serverity level is not valid: ${l}`);let p=a.logVerbosityLevel??0;if(!Number.isInteger(p)||p<0||p>4)throw new Error(`log verbosity level is not valid: ${p}`);let h=typeof a.optimizedModelFilePath=="string"?Re(a.optimizedModelFilePath,i):0;if(r=t._OrtCreateSessionOptions(n,!!a.enableCpuMemArena,!!a.enableMemPattern,s,!!a.enableProfiling,0,d,l,p,h),r===0&&xe("Can't create session options."),a.executionProviders&&Vs(r,a.executionProviders,i),a.enableGraphCapture!==void 0){if(typeof a.enableGraphCapture!="boolean")throw new Error(`enableGraphCapture must be a boolean value: ${a.enableGraphCapture}`);let u=Re("enableGraphCapture",i),m=Re(a.enableGraphCapture.toString(),i);t._OrtAddSessionConfigEntry(r,u,m)!==0&&xe(`Can't set a session config entry: 'enableGraphCapture' - ${a.enableGraphCapture}.`)}if(a.freeDimensionOverrides)for(let[u,m]of Object.entries(a.freeDimensionOverrides)){if(typeof u!="string")throw new Error(`free dimension override name must be a string: ${u}`);if(typeof m!="number"||!Number.isInteger(m)||m<0)throw new Error(`free dimension override value must be a non-negative integer: ${m}`);let $=Re(u,i);t._OrtAddFreeDimensionOverride(r,$,m)!==0&&xe(`Can't set a free dimension override: ${u} - ${m}.`)}return a.extra!==void 0&&Vr(a.extra,"",new WeakSet,(u,m)=>{let $=Re(u,i),f=Re(m,i);t._OrtAddSessionConfigEntry(r,$,f)!==0&&xe(`Can't set a session config entry: ${u} - ${m}.`)}),[r,i]}catch(n){throw r!==0&&t._OrtReleaseSessionOptions(r),i.forEach(s=>t._free(s)),n}}}),nr,Bt,Vt,Fa,jr,Ua,Na,ga,ee=F(()=>{"use strict";nr=e=>{switch(e){case"int8":return 3;case"uint8":return 2;case"bool":return 9;case"int16":return 5;case"uint16":return 4;case"int32":return 6;case"uint32":return 12;case"float16":return 10;case"float32":return 1;case"float64":return 11;case"string":return 8;case"int64":return 7;case"uint64":return 13;case"int4":return 22;case"uint4":return 21;default:throw new Error(`unsupported data type: ${e}`)}},Bt=e=>{switch(e){case 3:return"int8";case 2:return"uint8";case 9:return"bool";case 5:return"int16";case 4:return"uint16";case 6:return"int32";case 12:return"uint32";case 10:return"float16";case 1:return"float32";case 11:return"float64";case 8:return"string";case 7:return"int64";case 13:return"uint64";case 22:return"int4";case 21:return"uint4";default:throw new Error(`unsupported data type: ${e}`)}},Vt=(e,t)=>{let r=[-1,4,1,1,2,2,4,8,-1,1,2,8,4,8,-1,-1,-1,-1,-1,-1,-1,.5,.5][e],i=typeof t=="number"?t:t.reduce((a,n)=>a*n,1);return r>0?Math.ceil(i*r):void 0},Fa=e=>{switch(e){case"float16":return typeof Float16Array<"u"&&Float16Array.from?Float16Array:Uint16Array;case"float32":return Float32Array;case"uint8":return Uint8Array;case"int8":return Int8Array;case"uint16":return Uint16Array;case"int16":return Int16Array;case"int32":return Int32Array;case"bool":return Uint8Array;case"float64":return Float64Array;case"uint32":return Uint32Array;case"int64":return BigInt64Array;case"uint64":return BigUint64Array;default:throw new Error(`unsupported type: ${e}`)}},jr=e=>{switch(e){case"verbose":return 0;case"info":return 1;case"warning":return 2;case"error":return 3;case"fatal":return 4;default:throw new Error(`unsupported logging level: ${e}`)}},Ua=e=>e==="float32"||e==="float16"||e==="int32"||e==="int64"||e==="uint32"||e==="uint8"||e==="bool"||e==="uint4"||e==="int4",Na=e=>e==="float32"||e==="float16"||e==="int32"||e==="int64"||e==="uint32"||e==="uint64"||e==="int8"||e==="uint8"||e==="bool",ga=e=>{switch(e){case"none":return 0;case"cpu":return 1;case"cpu-pinned":return 2;case"texture":return 3;case"gpu-buffer":return 4;case"ml-tensor":return 5;default:throw new Error(`unsupported data location: ${e}`)}}}),Wa,Ed=F(()=>{"use strict";Ma(),Wa=async e=>{if(typeof e=="string")if(0)try{}catch(t){}else{let t=await fetch(e);if(!t.ok)throw new Error(`failed to load external data file: ${e}`);let r=t.headers.get("Content-Length"),i=r?parseInt(r,10):0;if(i<1073741824)return new Uint8Array(await t.arrayBuffer());{if(!t.body)throw new Error(`failed to load external data file: ${e}, no response body.`);let a=t.body.getReader(),n;try{n=new ArrayBuffer(i)}catch(d){if(d instanceof RangeError){let l=Math.ceil(i/65536);n=new WebAssembly.Memory({initial:l,maximum:l}).buffer}else throw d}let s=0;for(;;){let{done:d,value:l}=await a.read();if(d)break;let p=l.byteLength;new Uint8Array(n,s,p).set(l),s+=p}return new Uint8Array(n,0,i)}}else return e instanceof Blob?new Uint8Array(await e.arrayBuffer()):e instanceof Uint8Array?e:new Uint8Array(e)}}),js,Gs,Hs,Ks,La,Ys,ye,ut=F(()=>{"use strict";ee(),js=["V","I","W","E","F"],Gs=(e,t)=>{console.log(`[${js[e]},${new Date().toISOString()}]${t}`)},La=(e,t)=>{Hs=e,Ks=t},Ys=(e,t)=>{let r=jr(e),i=jr(Hs);r>=i&&Gs(r,typeof t=="function"?t():t)},ye=(...e)=>{Ks&&Ys(...e)}}),qa,Cd=F(()=>{"use strict";ee(),qa=(e,t)=>new(Fa(t))(e)}),Va=F(()=>{"use strict"}),Pi,Ar,zr,Zs,Qs,Di,ya,Xs,Id,km=F(()=>{"use strict";ut(),Va(),Pi=new Map([[64,250],[128,200],[256,200],[512,200],[2048,230],[4096,200],[8192,50],[16384,50],[32768,50],[65536,50],[131072,50],[262144,50],[524288,50],[1048576,50],[2097152,30],[4194304,20],[8388608,10],[12582912,10],[16777216,10],[26214400,15],[33554432,22],[44236800,2],[58982400,6],[67108864,6],[134217728,6],[167772160,6]]),Ar=[],zr=e=>Math.ceil(e/16)*16,Zs=e=>{for(let t=0;t<Ar.length;t++){let r=Ar[t];if(e<=r)return r}return Math.ceil(e/16)*16},Qs=1,Di=()=>Qs++,ya=async(e,t,r,i)=>{let a=zr(r),n=e.device.createBuffer({size:a,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});try{let s=e.getCommandEncoder();e.endComputePass(),s.copyBufferToBuffer(t,0,n,0,a),e.flush(),await n.mapAsync(GPUMapMode.READ);let d=n.getMappedRange();if(i){let l=i();return l.set(new Uint8Array(d,0,r)),l}else return new Uint8Array(d.slice(0,r))}finally{n.destroy()}},Xs=class{constructor(e){this.backend=e,this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.buffersForUploadingPending=[],this.buffersPending=[],this.capturedPendingBuffers=new Map;for(let[t]of Pi)Ar.push(t),this.freeBuffers.set(t,[]),this.freeUniformBuffers.set(t,[])}upload(e,t){let r=t.buffer,i=t.byteOffset,a=t.byteLength,n=zr(a),s=this.storageCache.get(e);if(!s)throw new Error("gpu data for uploading does not exist");if(s.originalSize!==a)throw new Error(`inconsistent data size. gpu data size=${s.originalSize}, data size=${a}`);let d=this.backend.device.createBuffer({mappedAtCreation:!0,size:n,usage:GPUBufferUsage.MAP_WRITE|GPUBufferUsage.COPY_SRC}),l=d.getMappedRange();new Uint8Array(l).set(new Uint8Array(r,i,a)),d.unmap();let p=this.backend.getCommandEncoder();this.backend.endComputePass(),p.copyBufferToBuffer(d,0,s.gpuData.buffer,0,n),ye("verbose",()=>`[WebGPU] GpuDataManager.upload(id=${e})`),this.buffersForUploadingPending.push(d)}memcpy(e,t){let r=this.storageCache.get(e);if(!r)throw new Error("source gpu data for memcpy does not exist");let i=this.storageCache.get(t);if(!i)throw new Error("destination gpu data for memcpy does not exist");if(r.originalSize!==i.originalSize)throw new Error("inconsistent source and destination gpu data size");let a=zr(r.originalSize),n=this.backend.getCommandEncoder();this.backend.endComputePass(),n.copyBufferToBuffer(r.gpuData.buffer,0,i.gpuData.buffer,0,a)}registerExternalBuffer(e,t,r){let i;if(r){if(i=r[0],e===r[1])return ye("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${i}, buffer is the same, skip.`),i;if(this.backend.capturedCommandList.has(this.backend.currentSessionId))throw new Error(`Registering a different external buffer under graph capture mode is not supported yet.
             Please use the previous external buffer!`)}else i=Di();return this.storageCache.set(i,{gpuData:{id:i,type:0,buffer:e},originalSize:t}),ye("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${i}, registered.`),i}unregisterExternalBuffer(e){e!==void 0&&(this.storageCache.delete(e),ye("verbose",()=>`[WebGPU] GpuDataManager.unregisterExternalBuffer() => id=${e}`))}create(e,t=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST){let r=Zs(e),i,a=(t&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE,n=(t&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM;if(a||n){let d=(a?this.freeBuffers:this.freeUniformBuffers).get(r);d?d.length>0?i=d.pop():i=this.backend.device.createBuffer({size:r,usage:t}):i=this.backend.device.createBuffer({size:r,usage:t})}else i=this.backend.device.createBuffer({size:r,usage:t});let s={id:Di(),type:0,buffer:i};return this.storageCache.set(s.id,{gpuData:s,originalSize:e}),ye("verbose",()=>`[WebGPU] GpuDataManager.create(size=${e}) => id=${s.id}`),s}get(e){return this.storageCache.get(e)?.gpuData}release(e){let t=this.storageCache.get(e);if(!t)throw new Error("releasing data does not exist");return ye("verbose",()=>`[WebGPU] GpuDataManager.release(id=${e}), gpuDataId=${t.gpuData.id}`),this.storageCache.delete(e),this.buffersPending.push(t.gpuData.buffer),t.originalSize}async download(e,t){let r=this.storageCache.get(e);if(!r)throw new Error("data does not exist");await ya(this.backend,r.gpuData.buffer,r.originalSize,t)}refreshPendingBuffers(){for(let e of this.buffersForUploadingPending)e.destroy();if(this.buffersForUploadingPending=[],this.buffersPending.length!==0)if(this.backend.sessionStatus==="default"){for(let e of this.buffersPending){let t=Pi.get(e.size);if((e.usage&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE){let r=this.freeBuffers.get(e.size)||[];t===void 0||r.length>=t?e.destroy():r.push(e)}else if((e.usage&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM){let r=this.freeUniformBuffers.get(e.size)||[];t===void 0||r.length>=t?e.destroy():r.push(e)}else e.destroy()}this.buffersPending=[]}else{let e=this.capturedPendingBuffers.get(this.backend.currentSessionId);e||(e=[],this.capturedPendingBuffers.set(this.backend.currentSessionId,e));for(let t of this.buffersPending)e.push(t);this.buffersPending=[]}}dispose(){this.freeBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.freeUniformBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.storageCache.forEach(e=>{e.gpuData.buffer.destroy()}),this.capturedPendingBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.capturedPendingBuffers=new Map}onReleaseSession(e){let t=this.capturedPendingBuffers.get(e);t&&(t.forEach(r=>{r.destroy()}),this.capturedPendingBuffers.delete(e))}},Id=(...e)=>new Xs(...e)}),Js,we,Te=F(()=>{"use strict";Js=class{constructor(e){Object.assign(this,e)}get cacheKey(){return this.key||(this.key=Object.getOwnPropertyNames(this).sort().map(e=>`${this[e]}`).join(";")),this.key}},we=e=>new Js(e)}),eo,Gt,R,Gr,Ad,zd,Rd,ae=F(()=>{"use strict";eo=class{static calcMatMulShape(e,t){return e[1]!==t[0]?void 0:[e[0],t[1]]}},Gt=class{static calcShape(e,t,r=!1){let i=e.length,a=t.length;if(i===0)return t;if(a===0)return e;let n=Math.max(e.length,t.length),s=new Array(n);if(r){if(i<2||a<2)return;let d=eo.calcMatMulShape([e[i-2],e[i-1]],[t[a-2],t[a-1]]);if(d===void 0)return;[s[n-2],s[n-1]]=d}for(let d=r?3:1;d<=n;d++){let l=i-d<0?1:e[i-d],p=a-d<0?1:t[a-d];if(l!==p&&l>1&&p>1)return;let h=Math.max(l,p);if(l&&p)s[n-d]=Math.max(l,p);else{if(h>1)return;s[n-d]=0}}return s}static isValidBroadcast(e,t){let r=e.length,i=t.length;if(r>i)return!1;for(let a=1;a<=r;a++)if(e[r-a]!==1&&e[r-a]!==t[i-a])return!1;return!0}},R=class Nr{static size(t){return Nr.getSizeFromDimensionRange(t,0,t.length)}static convertShape(t,r=4){let i=t.length;if(i===0)return[];let a=new Array(i),n=i-1;for(;n>=0;){if(t[n]%r===0){a[n]=t[n]/r;break}if(r%t[n]!==0)throw new Error("cannot convert shape");a[n]=1,r/=t[n],n--}for(n--;n>=0;n--)a[n]=t[n];return a}static sizeFromDimension(t,r){if(r<0||r>t.length)throw new Error(`invalid dimension of ${r} for sizeFromDimension as Tensor has ${t.length} dimensions.`);return Nr.getSizeFromDimensionRange(t,r,t.length)}static sizeToDimension(t,r){if(r<0||r>t.length)throw new Error(`invalid dimension of ${r} for sizeToDimension as Tensor has ${t.length} dimensions.`);return Nr.getSizeFromDimensionRange(t,0,r)}static getSizeFromDimensionRange(t,r,i){let a=1;for(let n=r;n<i;n++){if(t[n]<0)throw new Error("cannot get valid size from specified dimension range. Most likely the range contains negative values in them.");a*=t[n]}return a}static computeStrides(t){let r=t.length;if(r===0)return[];if(r===1)return[1];let i=new Array(r);i[r-1]=1,i[r-2]=t[r-1];for(let a=r-3;a>=0;--a)i[a]=i[a+1]*t[a+1];return i}static normalizeAxis(t,r){if(t<-r&&t>=r)throw new Error("unsupported axis for this operation.");return t<0?t+r:t}static normalizeAxes(t,r){return t.map(i=>this.normalizeAxis(i,r??t.length))}static sortBasedOnPerm(t,r){return r?r.map(i=>t[i]):t.slice().reverse()}static padShape(t,r){let i=t.length;return t.map((a,n)=>a+r[n]+r[n+i])}static areEqual(t,r){return t.length!==r.length?!1:t.every((i,a)=>i===r[a])}},Gr=class sr{static adjustPoolAttributes(t,r,i,a,n,s){if(!t&&i.length!==r.length-2)throw new Error("length of specified kernel shapes should be 2 less than length of input dimensions");if(t)for(let d=0;d<r.length-2;d++)d>=i.length?i.push(r[d+2]):i[d]=r[d+2];for(let d=0;d<i.length;d++)if(d<a.length){if(a[d]<0)throw new Error("strides should be greater than or equal to 1")}else a.push(1);for(let d=0;d<i.length;d++)if(d<n.length){if(n[d]<0)throw new Error("dilations should be greater than or equal to 1")}else n.push(1);for(let d=0;d<i.length*2;d++)if(d<s.length){if(s[d]<0)throw new Error("pad should be greater than or equal to 1")}else s.push(0);for(let d=0;d<i.length;d++){if(i[d]<=0)throw new Error("kernel shapes need to be greater than 0");if(s[d]>=i[d]||s[d+i.length]>=i[d])throw new Error("pads should be smaller than kernel")}}static adjustPadsBasedOnAutoPad(t,r,i,a,n,s,d){if(d){if(n.length!==2*(t.length-2))throw new Error("length of pads should be twice the length of data dimensions");if(r.length!==t.length-2)throw new Error("length of strides should be the length of data dimensions");if(a.length!==t.length-2)throw new Error("length of kernel shapes should be the length of data dimensions");for(let l=0;l<t.length-2;l++)sr.adjustPadAndReturnShape(t[l+(s?1:2)],r[l],i[l],a[l],n,l,l+t.length-2,d)}}static computePoolOutputShape(t,r,i,a,n,s,d){if(r.length<=0)throw new Error("input shape must be of size greater than 0");let l=[r[0],r[1]];return sr.computeShapeHelper(t,r,l,i,a,n,s,d),l}static computeConvOutputShape(t,r,i,a,n,s,d){if(t.length<=0||r.length<=0)throw new Error("invalid input tensor dims or invalid filter tensor dims");let l=[t[0],r[0]];return sr.computeShapeHelper(!1,t,l,i,a,n,s,d),l}static computeShapeHelper(t,r,i,a,n,s,d,l){if(t)for(let p=0;p<r.length-2;p++)i.push(1);else for(let p=0;p<r.length-2;p++)i.push(sr.adjustPadAndReturnShape(r[p+2],a[p],n[p],s[p],d,p,p+r.length-2,l))}static adjustPadAndReturnShape(t,r,i,a,n,s,d,l){let p=i*(a-1)+1;if(l&&l!=="NOTSET")switch(l){case"VALID":return n[s]=0,n[d]=0,Math.floor((t-p)/r+1);case"SAME_LOWER":case"SAME_UPPER":if(i!==1)throw new Error("Dilation not supported for SAME_UPPER or SAME_LOWER");{let h=((t+r-1)/r-1)*r+a-t;return n[s]=Math.floor(l==="SAME_LOWER"?(h+1)/2:h/2),n[d]=h-n[s],Math.floor((t+h-a)/r+1)}default:throw new Error("Unsupported AutoPad type")}else return Math.floor((t+n[s]+n[d]-p)/r+1)}},Ad=class{static getShapeOfGemmResult(e,t,r,i,a){if(e.length!==2||r.length!==2)throw new Error("shape need to be of size 2");let n,s,d;t?(n=e[1],s=e[0]):(n=e[0],s=e[1]);let l=-1;if(i?(d=r[0],l=1):(d=r[1],l=0),r[l]!==s)throw new Error("dimension mismatch");if(n<=0||d<=0||s<=0)throw new Error("invalid shape specified");if(a&&!Gt.isValidBroadcast(a,[n,d]))throw new Error("gemm: invalid bias shape for broadcast");return[n,d,s]}},zd=-34028234663852886e22,Rd=34028234663852886e22}),Ht,Rr,Ee,Be,G,Se,wa,jt,_t,H,Or,P,Y,ja,to,Od,lr,ne=F(()=>{"use strict";ee(),ae(),Ht=64,Rr=(e,t)=>{if(t===3)throw new Error("vec3 has same alignment as vec4, use vec4 instead");switch(e){case 10:return t>1?`vec${t}<f16>`:"f16";case 1:return t>1?`vec${t}<f32>`:"f32";case 6:return t>1?`vec${t}<i32>`:"i32";case 12:return t>1?`vec${t}<u32>`:"u32";case 7:if(t>1)throw new Error("currently not supported vecX of uint64 yet");return["vec2<u32>","i32"];case 13:if(t>1)throw new Error("currently not supported vecX of uint64 yet");return["vec2<u32>","u32"];case 9:if(t!==4)throw new Error("bool must be vec4");return["u32","vec4<bool>"];case 22:return"i32";case 21:return"u32";default:throw new Error(`Unknown data type: ${e}`)}},Ee=(e,t=1)=>{let r=Rr(e,t);return typeof r=="string"?r:r[0]},Be=(e,t=1)=>{let r=Rr(e,t);return typeof r=="string"?r:r[1]},G=(...e)=>{let t=[];return e.forEach(r=>{r.length!==0&&t.push({type:12,data:r},{type:12,data:R.computeStrides(r)})}),t},Se=e=>e%4===0?4:e%2===0?2:1,wa=(e="f32",t,r="0")=>!t||t===1?`${e}(${r})`:`vec${t}<${e}>(${r})`,jt=(e,t,r)=>e==="f32"?r:t===1?`f32(${r})`:`vec${t}<f32>(${r})`,_t=(e,t)=>t===4?`(${e}.x + ${e}.y + ${e}.z + ${e}.w)`:t===2?`(${e}.x + ${e}.y)`:t===3?`(${e}.x + ${e}.y + ${e}.z)`:e,H=(e,t,r,i)=>e.startsWith("uniforms.")&&r>4?typeof t=="string"?i==="f16"?`${e}[(${t}) / 8][(${t}) % 8 / 4][(${t}) % 8 % 4]`:`${e}[(${t}) / 4][(${t}) % 4]`:i==="f16"?`${e}[${Math.floor(t/8)}][${Math.floor(t%8/4)}][${t%8%4}]`:`${e}[${Math.floor(t/4)}][${t%4}]`:r>1?`${e}[${t}]`:e,Or=(e,t,r,i,a)=>{let n=typeof r=="number",s=n?r:r.length,d=[...new Array(s).keys()],l=s<2?"u32":s<=4?`vec${s}<u32>`:`array<u32, ${s}>`,p=Rr(t,a),h=typeof p=="string"?p:p[1],u=typeof p=="string"?p:p[0],m={indices:l,value:h,storage:u,tensor:t},$=O=>typeof O=="string"?O:`${O}u`,f={offsetToIndices:!1,indicesToOffset:!1,broadcastedIndicesToOffset:!1,set:!1,setByIndices:!1,get:!1,getByIndices:!1},y=n?"uniforms.":"",v=`${y}${e}_shape`,x=`${y}${e}_strides`,_="";for(let O=0;O<s-1;O++)_+=`
    let dim${O} = current / ${H(x,O,s)};
    let rest${O} = current % ${H(x,O,s)};
    indices[${O}] = dim${O};
    current = rest${O};
    `;_+=`indices[${s-1}] = current;`;let S=s<2?"":`
  fn o2i_${e}(offset: u32) -> ${m.indices} {
    var indices: ${m.indices};
    var current = offset;
    ${_}
    return indices;
  }`,k=O=>(f.offsetToIndices=!0,s<2?O:`o2i_${e}(${O})`),T=[];if(s>=2)for(let O=s-1;O>=0;O--)T.push(`${H(x,O,s)} * (indices[${O}])`);let I=s<2?"":`
  fn i2o_${e}(indices: ${m.indices}) -> u32 {
    return ${T.join("+")};
  }`,C=O=>(f.indicesToOffset=!0,s<2?O:`i2o_${e}(${O})`),M=(...O)=>s===0?"0u":`${m.indices}(${O.map($).join(",")})`,N=(O,U)=>s<2?`${O}`:`${H(O,U,s)}`,W=(O,U,te)=>s<2?`${O}=${te};`:`${H(O,U,s)}=${te};`,J={},K=(O,U)=>{f.broadcastedIndicesToOffset=!0;let te=`${U.name}broadcastedIndicesTo${e}Offset`;if(te in J)return`${te}(${O})`;let fe=[];for(let be=s-1;be>=0;be--){let ke=U.indicesGet("outputIndices",be+U.rank-s);fe.push(`${N(x,be)} * (${ke} % ${N(v,be)})`)}return J[te]=`fn ${te}(outputIndices: ${U.type.indices}) -> u32 {
             return ${fe.length>0?fe.join("+"):"0u"};
           }`,`${te}(${O})`},X=(O,U)=>(()=>{if(m.storage===m.value)return`${e}[${O}]=${U};`;if(m.storage==="vec2<u32>"&&m.value==="i32")return`${e}[${O}]=vec2<u32>(u32(${U}), select(0u, 0xFFFFFFFFu, ${U} < 0));`;if(m.storage==="vec2<u32>"&&m.value==="u32")return`${e}[${O}]=vec2<u32>(u32(${U}), 0u);`;if(m.storage==="u32"&&m.value==="vec4<bool>")return`${e}[${O}]=dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(${U}));`;throw new Error(`not supported combination of storage type ${m.storage} and value type ${m.value} yet`)})(),ie=O=>(()=>{if(m.storage===m.value)return`${e}[${O}]`;if(m.storage==="vec2<u32>"&&m.value==="i32")return`i32(${e}[${O}].x)`;if(m.storage==="vec2<u32>"&&m.value==="u32")return`u32(${e}[${O}].x)`;if(m.storage==="u32"&&m.value==="vec4<bool>")return`vec4<bool>(bool(${e}[${O}] & 0xFFu), bool(${e}[${O}] & 0xFF00u), bool(${e}[${O}] & 0xFF0000u), bool(${e}[${O}] & 0xFF000000u))`;throw new Error(`not supported combination of storage type ${m.storage} and value type ${m.value} yet`)})(),ue=s<2?"":`
  fn get_${e}ByIndices(indices: ${m.indices}) -> ${h} {
    return ${ie(`i2o_${e}(indices)`)};
  }`,q=s<2?"":(()=>{let O=d.map(te=>`d${te}: u32`).join(", "),U=d.map(te=>`d${te}`).join(", ");return`
  fn get_${e}(${O}) -> ${h} {
    return get_${e}ByIndices(${M(U)});
  }`})(),de=(...O)=>{if(O.length!==s)throw new Error(`indices length must be ${s}`);let U=O.map($).join(",");return s===0?ie("0u"):s===1?ie(U[0]):(f.get=!0,f.getByIndices=!0,f.indicesToOffset=!0,`get_${e}(${U})`)},se=O=>s<2?ie(O):(f.getByIndices=!0,f.indicesToOffset=!0,`get_${e}ByIndices(${O})`),j=s<2?"":`
  fn set_${e}ByIndices(indices: ${m.indices}, value: ${h}) {
    ${X(`i2o_${e}(indices)`,"value")}
  }`,re=s<2?"":(()=>{let O=d.map(te=>`d${te}: u32`).join(", "),U=d.map(te=>`d${te}`).join(", ");return`
  fn set_${e}(${O}, value: ${h}) {
    set_${e}ByIndices(${M(U)}, value);
  }`})();return{impl:()=>{let O=[],U=!1;return f.offsetToIndices&&(O.push(S),U=!0),f.indicesToOffset&&(O.push(I),U=!0),f.broadcastedIndicesToOffset&&(Object.values(J).forEach(te=>O.push(te)),U=!0),f.set&&(O.push(re),U=!0),f.setByIndices&&(O.push(j),U=!0),f.get&&(O.push(q),U=!0),f.getByIndices&&(O.push(ue),U=!0),!n&&U&&O.unshift(`const ${v} = ${m.indices}(${r.join(",")});`,`const ${x} = ${m.indices}(${R.computeStrides(r).join(",")});`),O.join(`
`)},type:m,offsetToIndices:k,indicesToOffset:C,broadcastedIndicesToOffset:K,indices:M,indicesGet:N,indicesSet:W,set:(...O)=>{if(O.length!==s+1)throw new Error(`indices length must be ${s}`);let U=O[s];if(typeof U!="string")throw new Error("value must be string");let te=O.slice(0,s).map($).join(",");return s===0?X("0u",U):s===1?X(te[0],U):(f.set=!0,f.setByIndices=!0,f.indicesToOffset=!0,`set_${e}(${te}, ${U})`)},setByOffset:X,setByIndices:(O,U)=>s<2?X(O,U):(f.setByIndices=!0,f.indicesToOffset=!0,`set_${e}ByIndices(${O}, ${U});`),get:de,getByOffset:ie,getByIndices:se,usage:i,name:e,strides:x,shape:v,rank:s}},P=(e,t,r,i=1)=>Or(e,t,r,"input",i),Y=(e,t,r,i=1)=>Or(e,t,r,"output",i),ja=(e,t,r,i=1)=>Or(e,t,r,"internal",i),to=class{constructor(e,t){this.normalizedDispatchGroup=e,this.limits=t,this.internalVariables=[],this.variables=[],this.uniforms=[],this.variableIndex=0}guardAgainstOutOfBoundsWorkgroupSizes(e){return`if (global_idx >= ${typeof e=="number"?`${e}u`:e}) { return; }`}mainStart(e=Ht){let t=typeof e=="number"?e:e[0],r=typeof e=="number"?1:e[1],i=typeof e=="number"?1:e[2];if(t>this.limits.maxComputeWorkgroupSizeX||r>this.limits.maxComputeWorkgroupSizeY||i>this.limits.maxComputeWorkgroupSizeZ)throw new Error(`workgroup size [${t}, ${r}, ${i}] exceeds the maximum workgroup size [${this.limits.maxComputeWorkgroupSizeX}, ${this.limits.maxComputeWorkgroupSizeY}, ${this.limits.maxComputeWorkgroupSizeZ}].`);if(t*r*i>this.limits.maxComputeInvocationsPerWorkgroup)throw new Error(`workgroup size [${t}, ${r}, ${i}] exceeds the maximum workgroup invocations ${this.limits.maxComputeInvocationsPerWorkgroup}.`);let a=this.normalizedDispatchGroup[1]===1&&this.normalizedDispatchGroup[2]===1,n=a?`@builtin(global_invocation_id) global_id : vec3<u32>,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(local_invocation_id) local_id : vec3<u32>`:`@builtin(global_invocation_id) global_id : vec3<u32>,
                                             @builtin(local_invocation_id) local_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(num_workgroups) num_workgroups : vec3<u32>`,s=a?`let global_idx = global_id.x;
         let workgroup_index = workgroup_id.x;`:`let workgroup_index = workgroup_id.z * num_workgroups[0] * num_workgroups[1] +
             workgroup_id.y * num_workgroups[0] + workgroup_id.x;
         let global_idx = workgroup_index * ${t*r*i}u + local_idx;`;return`@compute @workgroup_size(${t}, ${r}, ${i})
  fn main(${n}) {
    ${s}
  `}appendVariableUniforms(e){e.rank!==0&&(e.shape.startsWith("uniforms.")&&this.uniforms.push({name:e.shape.replace("uniforms.",""),type:"u32",length:e.rank}),e.strides.startsWith("uniforms.")&&this.uniforms.push({name:e.strides.replace("uniforms.",""),type:"u32",length:e.rank}))}declareVariable(e,t){if(e.usage==="internal")throw new Error("cannot use internal variable with declareVariable(). use registerInternalVariables() instead.");this.variables.push(e),this.appendVariableUniforms(e);let r=e.usage==="input"?"read":"read_write",i=e.type.storage;return`@group(0) @binding(${t}) var<storage, ${r}> ${e.name}: array<${i}>;`}declareVariables(...e){return e.map(t=>this.declareVariable(t,this.variableIndex++)).join(`
`)}registerInternalVariable(e){if(e.usage!=="internal")throw new Error("cannot use input or output variable with registerInternalVariable(). use declareVariables() instead.");this.internalVariables.push(e),this.appendVariableUniforms(e)}registerInternalVariables(...e){return e.forEach(t=>this.registerInternalVariable(t)),this}registerUniform(e,t,r=1){return this.uniforms.push({name:e,type:t,length:r}),this}registerUniforms(e){return this.uniforms=this.uniforms.concat(e),this}uniformDeclaration(){if(this.uniforms.length===0)return"";let e=[];for(let{name:t,type:r,length:i}of this.uniforms)if(i&&i>4)r==="f16"?e.push(`@align(16) ${t}:array<mat2x4<${r}>, ${Math.ceil(i/8)}>`):e.push(`${t}:array<vec4<${r}>, ${Math.ceil(i/4)}>`);else{let a=i==null||i===1?r:`vec${i}<${r}>`;e.push(`${t}:${a}`)}return`
      struct Uniforms { ${e.join(", ")} };
      @group(0) @binding(${this.variableIndex}) var<uniform> uniforms: Uniforms;`}get additionalImplementations(){return this.uniformDeclaration()+this.variables.map(e=>e.impl()).join(`
`)+this.internalVariables.map(e=>e.impl()).join(`
`)}get variablesInfo(){if(this.uniforms.length===0)return;let e=t=>[12,10,1,6][["u32","f16","f32","i32"].indexOf(t)];return this.uniforms.map(t=>[e(t.type),t.length??1])}},Od=(e,t)=>new to(e,t),lr=(e,t)=>{let r=e.length,i=[];for(let a=0;a<r;a++){let n=r-1-a,s=e[n]||1;(t[t.length-1-a]||1)>1&&s===1&&i.unshift(n)}return i}}),ro,Fi,io,ao,no,Le,Bd,Md,St=F(()=>{"use strict";ee(),ae(),Te(),ne(),ro=e=>{if(!e||e.length!==1)throw new Error("Transpose requires 1 input.")},Fi=(e,t)=>t&&t.length!==e?[...new Array(e).keys()].reverse():t,io=(e,t)=>R.sortBasedOnPerm(e,Fi(e.length,t)),ao=(e,t,r,i)=>{let a=`fn perm(i: ${i.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`;for(let n=0;n<t;++n)a+=r.indicesSet("a",e[n],`i[${n}]`);return a+="return a;}"},no=(e,t)=>{let r=[],i=[];for(let a=0;a<e.length;++a)e[a]!==1&&r.push(e[a]),e[t[a]]!==1&&i.push(t[a]);return{newShape:r,newPerm:i}},Le=(e,t)=>{let r=e.dataType,i=e.dims.length,a=Fi(i,t),n=io(e.dims,a),{newShape:s,newPerm:d}=no(e.dims,a),l=R.areEqual(d,[2,3,1]),p=R.areEqual(d,[3,1,2]),h=s.length===2&&d[0]>d[1]||l||p,u=h?s:e.dims,m=n;h&&(u=l?[s[0],s[1]*s[2]]:p?[s[0]*s[1],s[2]]:s,m=[u[1],u[0]]);let $=P("a",r,u.length),f=Y("output",r,m.length),y=16,v;return h?v=x=>`
  ${x.registerUniform("output_size","u32").declareVariables($,f)}
  var<workgroup> tile : array<array<${f.type.value}, ${y+1}>, ${y}>;
  ${x.mainStart([y,y,1])}
    let stride = (uniforms.output_shape[1] - 1) / ${y} + 1;
    let workgroup_id_x = workgroup_index % stride;
    let workgroup_id_y = workgroup_index / stride;
    let input_col = workgroup_id_y * ${y}u + local_id.x;
    let input_row = workgroup_id_x * ${y}u + local_id.y;
    if (input_row < uniforms.a_shape[0] && input_col < uniforms.a_shape[1]) {
      tile[local_id.y][local_id.x] = ${$.getByIndices(`${$.type.indices}(input_row, input_col)`)};
    }
    workgroupBarrier();

    let output_col = workgroup_id_x * ${y}u + local_id.x;
    let output_row = workgroup_id_y * ${y}u + local_id.y;
    if (output_row < uniforms.output_shape[0] && output_col < uniforms.output_shape[1]) {
      ${f.setByIndices(`${f.type.indices}(output_row, output_col)`,"tile[local_id.x][local_id.y]")}
    }
  }`:v=x=>`
  ${x.registerUniform("output_size","u32").declareVariables($,f)}

  ${ao(a,i,$,f)}

  ${x.mainStart()}
    ${x.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${f.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${f.setByOffset("global_idx",$.getByIndices("aIndices"))}
  }`,{name:h?"TransposeShared":"Transpose",shaderCache:{hint:`${t}`,inputDependencies:["rank"]},getRunData:()=>{let x=R.size(n);return{outputs:[{dims:n,dataType:e.dataType}],dispatchGroup:h?{x:Math.ceil(m[1]/y),y:Math.ceil(m[0]/y)}:{x:Math.ceil(x/64)},programUniforms:[{type:12,data:x},...G(u,m)]}},getShaderSource:v}},Bd=(e,t)=>{ro(e.inputs),e.compute(Le(e.inputs[0],t.perm))},Md=e=>we({perm:e.perm})}),so,oo,uo,lo,po,co,ho,fo,mo,go,Ye,Pd,Dd,Fd,Ud,Nd,Wd,Ld,qd,Vd,jd,Tm=F(()=>{"use strict";ee(),ae(),ne(),Ga(),St(),so={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate * candidate",logSumExp:"bestValue + exp(candidate)",l1:"bestValue + abs(candidate)",l2:"bestValue + candidate * candidate",logSum:"bestValue + candidate"},oo={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate",logSumExp:"bestValue + candidate",l1:"bestValue + candidate",l2:"bestValue + candidate",logSum:"bestValue + candidate"},uo={max:"_A[offset]",min:"_A[offset]",mean:"0",sum:"0",prod:"1",sumSquare:"0",logSumExp:"0",l1:"0",l2:"0",logSum:"0"},lo={max:"bestValue",min:"bestValue",sum:"bestValue",prod:"bestValue",sumSquare:"bestValue",logSumExp:"log(bestValue)",l1:"bestValue",l2:"sqrt(bestValue)",logSum:"log(bestValue)"},po=(e,t)=>{let r=[];for(let i=t-e;i<t;++i)r.push(i);return r},co=(e,t)=>{let r=[],i=e.length;for(let n=0;n<i;n++)t.indexOf(n)===-1&&r.push(e[n]);let a=t.map(n=>e[n]);return[r,a]},ho=(e,t)=>{let r=e.length+t.length,i=[],a=0;for(let n=0;n<r;n++)t.indexOf(n)===-1?i.push(e[a++]):i.push(1);return i},fo=(e,t)=>{for(let r=0;r<e.length;++r)if(e[e.length-r-1]!==t-1-r)return!1;return!0},mo=(e,t)=>{let r=[];if(!fo(e,t)){for(let i=0;i<t;++i)e.indexOf(i)===-1&&r.push(i);e.forEach(i=>r.push(i))}return r},go=(e,t,r,i,a,n,s)=>{let d=r[0].dims,l=R.size(n),p=R.size(s),h=P("_A",r[0].dataType,d),u=Y("output",a,n),m=32,$=`
          var<workgroup> aBestValues : array<f32, ${m}>;
       `;return{name:e,shaderCache:t,getShaderSource:f=>`
        ${f.registerUniform("reduceSize","u32").declareVariables(h,u)}
        ${$}
        fn DIV_CEIL(a : u32, b : u32) -> u32 {
          return ((a - 1u) / b + 1u);
         }
         ${f.mainStart(m)}

          let outputIndex = global_idx / ${m};
          let offset = outputIndex * uniforms.reduceSize;

          var bestValue = f32(${uo[i]});
          let Length = uniforms.reduceSize;
          for (var k = local_idx; k < Length; k = k + ${m}) {
           let candidate = f32(${h.getByOffset("offset + k")});
           bestValue = ${so[i]};
          }
          aBestValues[local_idx] = bestValue;
          workgroupBarrier();

         var reduceSize = min(Length, ${m}u);
         for (var currentSize = reduceSize / 2u; reduceSize > 1u;
             currentSize = reduceSize / 2u) {
           let interval = DIV_CEIL(reduceSize, 2u);
           if (local_idx < currentSize) {
            let candidate = aBestValues[local_idx + interval];
            bestValue = ${oo[i]};
            aBestValues[local_idx] = bestValue;
           }
           reduceSize = interval;
           workgroupBarrier();
         }

         if (local_idx == 0u) {
          ${u.setByOffset("outputIndex",`${i==="mean"?`${u.type.storage}(bestValue / f32(uniforms.reduceSize))`:`${u.type.storage}(${lo[i]})`}`)};
         }
        }`,getRunData:()=>({outputs:[{dims:n,dataType:a}],dispatchGroup:{x:l},programUniforms:[{type:12,data:p}]})}},Ye=(e,t,r,i)=>{let a=e.inputs.length===1?r:$a(e.inputs,r),n=a.axes;n.length===0&&!a.noopWithEmptyAxes&&(n=e.inputs[0].dims.map(($,f)=>f));let s=R.normalizeAxes(n,e.inputs[0].dims.length),d=s,l=e.inputs[0],p=mo(d,e.inputs[0].dims.length);p.length>0&&(l=e.compute(Le(e.inputs[0],p),{inputs:[0],outputs:[-1]})[0],d=po(d.length,l.dims.length));let[h,u]=co(l.dims,d),m=h;a.keepDims&&(m=ho(h,s)),e.compute(go(t,{hint:a.cacheKey,inputDependencies:["type"]},[l],i,e.inputs[0].dataType,m,u),{inputs:[l]})},Pd=(e,t)=>{Ye(e,"ReduceMeanShared",t,"mean")},Dd=(e,t)=>{Ye(e,"ReduceL1Shared",t,"l1")},Fd=(e,t)=>{Ye(e,"ReduceL2Shared",t,"l2")},Ud=(e,t)=>{Ye(e,"ReduceLogSumExpShared",t,"logSumExp")},Nd=(e,t)=>{Ye(e,"ReduceMaxShared",t,"max")},Wd=(e,t)=>{Ye(e,"ReduceMinShared",t,"min")},Ld=(e,t)=>{Ye(e,"ReduceProdShared",t,"prod")},qd=(e,t)=>{Ye(e,"ReduceSumShared",t,"sum")},Vd=(e,t)=>{Ye(e,"ReduceSumSquareShared",t,"sumSquare")},jd=(e,t)=>{Ye(e,"ReduceLogSumShared",t,"logSum")}}),Ze,yo,Hr,$a,Qe,wo,$o,_o,bo,vo,xo,So,ko,To,Eo,Xe,Gd,Hd,Kd,Yd,Zd,Qd,Xd,Jd,ep,tp,Ga=F(()=>{"use strict";ee(),ae(),Te(),ne(),Tm(),Ze=e=>{if(!e||e.length===0||e.length>2)throw new Error("Reduce op requires 1 or 2 inputs.");if(e.length===2&&e[1].dims.length!==1)throw new Error("Invalid axes input dims.")},yo=e=>["","",`var value = ${e.getByIndices("input_indices")};`,""],Hr=(e,t,r,i,a,n,s=!1,d=!1)=>{let l=[],p=r[0].dims,h=p.length,u=R.normalizeAxes(a,h),m=!d&&u.length===0;p.forEach((y,v)=>{m||u.indexOf(v)>=0?s&&l.push(1):l.push(y)});let $=l.length,f=R.size(l);return{name:e,shaderCache:t,getShaderSource:y=>{let v=[],x=P("_A",r[0].dataType,h),_=Y("output",n,$),S=i(x,_,u),k=S[2];for(let T=0,I=0;T<h;T++)m||u.indexOf(T)>=0?(s&&I++,k=`for(var j${T}: u32 = 0; j${T} < ${p[T]}; j${T}++) {
                  ${S[2].includes("last_index")?`let last_index = j${T};`:""}
                  ${x.indicesSet("input_indices",T,`j${T}`)}
                  ${k}
                }`):(v.push(`${x.indicesSet("input_indices",T,_.indicesGet("output_indices",I))};`),I++);return`

        ${y.registerUniform("output_size","u32").declareVariables(x,_)}

        ${y.mainStart()}
          ${y.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          var input_indices: ${x.type.indices};
          let output_indices = ${_.offsetToIndices("global_idx")};

          ${v.join(`
`)}
          ${S[0]}       // init ops for reduce max/min
          ${S[1]}
          ${k}
          ${S[3]}
          ${S.length===4?_.setByOffset("global_idx","value"):S.slice(4).join(`
`)}
        }`},getRunData:()=>({outputs:[{dims:l,dataType:n}],dispatchGroup:{x:Math.ceil(f/64)},programUniforms:[{type:12,data:f},...G(p,l)]})}},$a=(e,t)=>{let r=[];return e[1].dims[0]>0&&e[1].getBigInt64Array().forEach(i=>r.push(Number(i))),we({axes:r,keepDims:t.keepDims,noopWithEmptyAxes:t.noopWithEmptyAxes})},Qe=(e,t,r,i)=>{let a=e.inputs,n=a.length===1?r:$a(a,r);e.compute(Hr(t,{hint:n.cacheKey,inputDependencies:["rank"]},[a[0]],n.noopWithEmptyAxes&&n.axes.length===0?yo:i,n.axes,a[0].dataType,n.keepDims,n.noopWithEmptyAxes),{inputs:[0]})},wo=(e,t)=>{Ze(e.inputs),Qe(e,"ReduceLogSum",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += ${r.getByIndices("input_indices")};`,"value = log(value);"])},$o=(e,t)=>{Ze(e.inputs),Qe(e,"ReduceL1",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += abs(${r.getByIndices("input_indices")});`,""])},_o=(e,t)=>{Ze(e.inputs),Qe(e,"ReduceL2",t,(r,i)=>[`var t = ${i.type.value}(0); var value = ${i.type.value}(0);`,"",`t = ${r.getByIndices("input_indices")}; value += (t * t);`,"value = sqrt(value);"])},bo=(e,t)=>{Ze(e.inputs),Qe(e,"ReduceLogSumExp",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += exp(${r.getByIndices("input_indices")});`,"value = log(value);"])},vo=(e,t)=>{Ze(e.inputs),Qe(e,"ReduceMax",t,(r,i,a)=>{let n=[];for(let s=0;s<r.rank;s++)(a.indexOf(s)>=0||a.length===0)&&n.push(r.indicesSet("input_indices",s,0));return[`${n.join(`
`)}`,`var value = ${r.getByIndices("input_indices")};`,`value = max(value, ${r.getByIndices("input_indices")});`,""]})},xo=(e,t)=>{Ze(e.inputs),Qe(e,"ReduceMean",t,(r,i,a)=>{let n=1;for(let s=0;s<r.rank;s++)(a.indexOf(s)>=0||a.length===0)&&(n*=e.inputs[0].dims[s]);return["var sum = f32(0);","",`sum += f32(${r.getByIndices("input_indices")});`,`let value = ${i.type.value}(sum / ${n});`]})},So=(e,t)=>{Ze(e.inputs),Qe(e,"ReduceMin",t,(r,i,a)=>{let n=[];for(let s=0;s<r.rank;s++)(a.indexOf(s)>=0||a.length===0)&&n.push(`input_indices[${s}] = 0;`);return[`${n.join(`
`)}`,`var value = ${r.getByIndices("input_indices")};`,`value = min(value, ${r.getByIndices("input_indices")});`,""]})},ko=(e,t)=>{Ze(e.inputs),Qe(e,"ReduceProd",t,(r,i)=>[`var value = ${i.type.storage}(1);`,"",`value *= ${r.getByIndices("input_indices")};`,""])},To=(e,t)=>{Ze(e.inputs),Qe(e,"ReduceSum",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += ${r.getByIndices("input_indices")};`,""])},Eo=(e,t)=>{Ze(e.inputs),Qe(e,"ReduceSumSquare",t,(r,i)=>[`var t = ${i.type.value}(0); var value = ${i.type.value}(0);`,"",`t = ${r.getByIndices("input_indices")}; value += t * t;`,""])},Xe=(e,t,r)=>{if(t.length===0)return r;let i=1,a=1;for(let n=0;n<t.length;n++)t.indexOf(n)===-1?i*=e[n]:a*=e[n];return a<32&&i>1024},Gd=(e,t)=>{Xe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?xo(e,t):Pd(e,t)},Hd=(e,t)=>{Xe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?$o(e,t):Dd(e,t)},Kd=(e,t)=>{Xe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?_o(e,t):Fd(e,t)},Yd=(e,t)=>{Xe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?bo(e,t):Ud(e,t)},Zd=(e,t)=>{Xe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?vo(e,t):Nd(e,t)},Qd=(e,t)=>{Xe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?So(e,t):Wd(e,t)},Xd=(e,t)=>{Xe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?ko(e,t):Ld(e,t)},Jd=(e,t)=>{Xe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?To(e,t):qd(e,t)},ep=(e,t)=>{Xe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Eo(e,t):Vd(e,t)},tp=(e,t)=>{Xe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?wo(e,t):jd(e,t)}}),Ui,rp,ip,_a,Em=F(()=>{"use strict";ee(),Te(),Ga(),Ui=e=>{if(!e||e.length===0||e.length>2)throw new Error("ArgMinMaxOp op requires 1 or 2 inputs.");if(e[0].dataType!==1)throw new Error("Invalid input type.")},rp=(e,t)=>{Ui(e.inputs);let r=(i,a,n)=>{let s=[];for(let d=0;d<i.rank;d++)(n.indexOf(d)>=0||n.length===0)&&s.push(`input_indices[${d}] = 0;`);return[`${s.join(`
`)}`,`var value = ${i.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${i.getByIndices("input_indices")} ${t.selectLastIndex>0?"<=":"<"} value) {
         value = ${i.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",a.setByOffset("global_idx","best_index")]};e.compute(Hr("ArgMin",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],r,[t.axis],7,t.keepDims),{inputs:[0]})},ip=(e,t)=>{Ui(e.inputs);let r=(i,a,n)=>{let s=[];for(let d=0;d<i.rank;d++)(n.indexOf(d)>=0||n.length===0)&&s.push(`input_indices[${d}] = 0;`);return[`${s.join(`
`)}`,`var value = ${i.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${i.getByIndices("input_indices")} ${t.selectLastIndex>0?">=":">"} value) {
         value = ${i.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",a.setByOffset("global_idx","best_index")]};e.compute(Hr("argMax",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],r,[t.axis],7,t.keepDims),{inputs:[0]})},_a=e=>we(e)}),Co,Io,Ao,zo,dr,Ro,ap,Ha=F(()=>{"use strict";ee(),ae(),Va(),ne(),Co=(e,t)=>{let r=e[0],i=e[1],a=e[2],n=e[3],s=e[4],d=e[5];if(s&&d)throw new Error("Attention cannot have both past and attention_bias");if(r.dims.length!==3)throw new Error('Input "input" must have 3 dimensions');let l=r.dims[0],p=r.dims[1],h=r.dims[2];if(a.dims.length!==1)throw new Error('Input "bias" is expected to have 1 dimensions');if(i.dims.length!==2)throw new Error('Input "weights" is expected to have 2 dimensions');if(i.dims[0]!==h)throw new Error("Input 1 dimension 0 should have same length as dimension 2 of input 0");if(a.dims[0]!==i.dims[1])throw new Error('Input "bias" dimension 0 should have same length as dimension 1 of input "weights"');let u=a.dims[0]/3,m=u,$=m;if(t.qkvHiddenSizes.length>0){if(t.qkvHiddenSizes.length!==3)throw new Error("qkv_hidden_sizes attribute should have 3 elements");for(let S of t.qkvHiddenSizes)if(S%t.numHeads!==0)throw new Error("qkv_hidden_sizes should be divisible by num_heads");u=t.qkvHiddenSizes[0],m=t.qkvHiddenSizes[1],$=t.qkvHiddenSizes[2]}let f=p;if(u!==m)throw new Error("qkv_hidden_sizes first element should be same as the second");if(a.dims[0]!==u+m+$)throw new Error('Input "bias" dimension 0 should have same length as sum of Q/K/V hidden sizes');let y=0;if(s){if(m!==$)throw new Error('Input "past" expect k_hidden_size == v_hidden_size');if(s.dims.length!==5)throw new Error('Input "past" must have 5 dimensions');if(s.dims[0]!==2)throw new Error('Input "past" first dimension must be 2');if(s.dims[1]!==l)throw new Error('Input "past" second dimension must be batch_size');if(s.dims[2]!==t.numHeads)throw new Error('Input "past" third dimension must be num_heads');if(s.dims[4]!==m/t.numHeads)throw new Error('Input "past" fifth dimension must be k_hidden_size / num_heads');t.pastPresentShareBuffer||(y=s.dims[3])}let v=f+y,x=-1,_=0;if(n)throw new Error("Mask not supported");if(s)throw new Error("past is not supported");if(d){if(d.dims.length!==4)throw new Error('Input "attention_bias" must have 4 dimensions');if(d.dims[0]!==l||d.dims[1]!==t.numHeads||d.dims[2]!==p||d.dims[3]!==v)throw new Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:l,sequenceLength:p,pastSequenceLength:y,kvSequenceLength:f,totalSequenceLength:v,maxSequenceLength:x,inputHiddenSize:h,hiddenSize:u,vHiddenSize:$,headSize:Math.floor(u/t.numHeads),vHeadSize:Math.floor($/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:_,scale:t.scale,broadcastResPosBias:!1,passPastInKv:!1,qkvFormat:1}},Io=(e,t,r)=>{let i=Se(r),a=64,n=r/i;n<a&&(a=32);let s=Math.ceil(r/i/a),d=[{type:1,data:1/r},{type:12,data:n},{type:12,data:s}],l=Ee(e.dataType,i),p=Be(1,i),h=["type"],u=m=>{let $=Y("x",e.dataType,e.dims,i),f=Be(e.dataType),y=[{name:"d_inv",type:"f32"},{name:"d_comp",type:"u32"},{name:"elements_per_thread",type:"u32"}];return`
  var<workgroup> thread_max: array<f32, ${a}>;
  var<workgroup> thread_sum: array<f32, ${a}>;
  ${m.registerUniforms(y).declareVariables($)}
  ${m.mainStart([a,1,1])}
    let local_offset = local_idx * uniforms.elements_per_thread;
    let offset = (global_idx / ${a}) * uniforms.d_comp + local_offset;

    var thread_max_vector = ${p}(-3.402823e+38f);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < uniforms.d_comp; i++) {
      thread_max_vector = max(${p}(x[offset + i]), thread_max_vector);
    }
    thread_max[local_idx] = ${(()=>{switch(i){case 1:return"thread_max_vector";case 2:return"max(thread_max_vector.x, thread_max_vector.y)";case 4:return"max(max(thread_max_vector.x, thread_max_vector.y), max(thread_max_vector.z, thread_max_vector.w))";default:throw new Error(`Unsupported components: ${i}`)}})()};
    workgroupBarrier();

    var max_value =  f32(-3.402823e+38f);
    for (var i = 0u; i < ${a}; i++) {
      max_value = max(thread_max[i], max_value);
    }

    var sum_vector = ${p}(0);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < uniforms.d_comp; i++) {
      sum_vector += exp(${p}(x[offset + i]) - max_value);
    }
    thread_sum[local_idx] = ${(()=>{switch(i){case 1:return"sum_vector";case 2:return"sum_vector.x + sum_vector.y";case 4:return"sum_vector.x + sum_vector.y + sum_vector.z + sum_vector.w";default:throw new Error(`Unsupported components: ${i}`)}})()};
    workgroupBarrier();

    var sum: f32 = 0;
    for (var i = 0u; i < ${a}; i++) {
      sum += thread_sum[i];
    }

    if (sum == 0) {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < uniforms.d_comp; i++) {
        x[offset + i] = ${$.type.value}(${f}(uniforms.d_inv));
      }
    } else {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < uniforms.d_comp; i++) {
        var f32input = ${p}(x[offset + i]);
        x[offset + i] = ${$.type.value}(exp(f32input - max_value) / sum);
      }
    }
  }`};return{name:"AttentionProbsSoftmax",shaderCache:{hint:`${a};${l};${i}`,inputDependencies:h},getShaderSource:u,getRunData:()=>({outputs:[],dispatchGroup:{x:t},programUniforms:d})}},Ao=(e,t,r,i,a,n,s,d)=>{let l=d+n.kvSequenceLength,p=[n.batchSize,n.numHeads,n.sequenceLength,l],h=n.kvNumHeads===void 0&&e>1&&i,u=h?[n.batchSize,n.numHeads,l,n.headSize]:void 0,m=s.scale===0?1/Math.sqrt(n.headSize):s.scale,$=Se(n.headSize),f=n.headSize/$,y=12,v={x:Math.ceil(l/y),y:Math.ceil(n.sequenceLength/y),z:n.batchSize*n.numHeads},x=[{type:12,data:n.sequenceLength},{type:12,data:f},{type:12,data:l},{type:12,data:n.numHeads},{type:1,data:m},{type:12,data:d},{type:12,data:n.kvSequenceLength}],_=h&&i&&R.size(i.dims)>0,S=["type","type"];_&&S.push("type"),a&&S.push("type");let k=[{dims:p,dataType:t.dataType,gpuDataType:0}];h&&k.push({dims:u,dataType:t.dataType,gpuDataType:0});let T=I=>{let C=P("q",t.dataType,t.dims,$),M=P("key",r.dataType,r.dims,$),N=[C,M];if(_){let ie=P("past_key",i.dataType,i.dims,$);N.push(ie)}a&&N.push(P("attention_bias",a.dataType,a.dims));let W=Y("output",t.dataType,p),J=[W];h&&J.push(Y("present_key",t.dataType,u,$));let K=Be(1,$),X=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"alpha",type:"f32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"}];return`
  const TILE_SIZE = ${y}u;

  var<workgroup> tileQ: array<${C.type.storage}, ${y*y}>;
  var<workgroup> tileK: array<${C.type.storage}, ${y*y}>;
  ${I.registerUniforms(X).declareVariables(...N,...J)}
  ${I.mainStart([y,y,1])}
    // x holds the N and y holds the M
    let headIdx = workgroup_id.z;
    let m = workgroup_id.y * TILE_SIZE;
    let n = workgroup_id.x * TILE_SIZE;
    let qOffset = uniforms.M * uniforms.K * headIdx + m * uniforms.K;
    ${_&&h?`
    let kOffset = uniforms.kv_sequence_length * uniforms.K * headIdx;
    let pastKeyOffset = uniforms.past_sequence_length * uniforms.K * headIdx;`:`
    let kOffset = uniforms.N * uniforms.K * headIdx + n * uniforms.K;`}
    ${h?"let presentKeyOffset = headIdx * uniforms.N * uniforms.K;":""}
    var value = ${K}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (global_id.y < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = q[qOffset + local_id.y * uniforms.K + w + local_id.x];
      }
      if (n + local_id.y < uniforms.N && w + local_id.x < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
      ${_&&h?`
              if (n + local_id.y < uniforms.past_sequence_length) {
                tileK[idx] = past_key[pastKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
              } else {
                tileK[idx] =
                         key[kOffset + (n + local_id.y - uniforms.past_sequence_length) * uniforms.K + w + local_id.x];
              }`:"tileK[idx] = key[kOffset + local_id.y * uniforms.K + w + local_id.x];"}
      ${h?"present_key[presentKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x] = tileK[idx];":""}
      }
      workgroupBarrier();

      for (var k: u32 = 0u; k < TILE_SIZE && w+k < uniforms.K; k++) {
        value += ${K}(tileQ[TILE_SIZE * local_id.y + k] * tileK[TILE_SIZE * local_id.x + k]);
      }

      workgroupBarrier();
    }

    let headOffset = headIdx * uniforms.M * uniforms.N;
    if (global_id.y < uniforms.M && global_id.x < uniforms.N) {
      let outputIdx = headOffset + global_id.y * uniforms.N + global_id.x;
      var sum: f32 = ${(()=>{switch($){case 1:return"value";case 2:return"value.x + value.y";case 4:return"value.x + value.y + value.z + value.w";default:throw new Error(`Unsupported components: ${$}`)}})()};
        output[outputIdx] = ${W.type.value} (sum * uniforms.alpha) + ${a?"attention_bias[outputIdx]":"0.0"};
    }
  }`};return{name:"AttentionProbs",shaderCache:{hint:`${$};${a!==void 0};${i!==void 0};${e}`,inputDependencies:S},getRunData:()=>({outputs:k,dispatchGroup:v,programUniforms:x}),getShaderSource:T}},zo=(e,t,r,i,a,n)=>{let s=n+a.kvSequenceLength,d=a.nReps?a.nReps:1,l=a.vHiddenSize*d,p=a.kvNumHeads==null&&e>1&&i,h=p?[a.batchSize,a.numHeads,s,a.headSize]:void 0,u=[a.batchSize,a.sequenceLength,l],m=12,$={x:Math.ceil(a.vHeadSize/m),y:Math.ceil(a.sequenceLength/m),z:a.batchSize*a.numHeads},f=[{type:12,data:a.sequenceLength},{type:12,data:s},{type:12,data:a.vHeadSize},{type:12,data:a.numHeads},{type:12,data:l},{type:12,data:n},{type:12,data:a.kvSequenceLength}],y=p&&i&&R.size(i.dims)>0,v=["type","type"];y&&v.push("type");let x=[{dims:u,dataType:t.dataType,gpuDataType:0}];p&&x.push({dims:h,dataType:t.dataType,gpuDataType:0});let _=S=>{let k=P("probs",t.dataType,t.dims),T=P("v",r.dataType,r.dims),I=[k,T];y&&I.push(P("past_value",i.dataType,i.dims));let C=[Y("output",t.dataType,u)];p&&C.push(Y("present_value",t.dataType,h));let M=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"v_hidden_size",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"}];return`
  const TILE_SIZE = ${m}u;
  var<workgroup> tileQ: array<${k.type.value}, ${m*m}>;
  var<workgroup> tileK: array<${k.type.value}, ${m*m}>;
  ${S.registerUniforms(M).declareVariables(...I,...C)}
  ${S.mainStart([m,m,1])}
   let headIdx = workgroup_id.z;
   let m = global_id.y;
   let n = global_id.x;

   let offsetA = headIdx * (uniforms.M * uniforms.K) + m * uniforms.K;
   ${y&&p?`
    let pastValueOffset = headIdx * uniforms.N * uniforms.past_sequence_length + n;
    let vOffset = headIdx * uniforms.N * uniforms.kv_sequence_length + n;
      `:`
   let offsetB = headIdx * uniforms.N * uniforms.K + n;
            `}
    ${p?"let presentValueOffset = headIdx * uniforms.N * uniforms.K + n;":""}
   var value = ${k.type.storage}(0);
   for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = probs[offsetA + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
        ${y&&p?`
        if (w + local_id.y < uniforms.past_sequence_length) {
          tileK[idx] = past_value[pastValueOffset + (w + local_id.y) * uniforms.N];
        } else {
          tileK[idx] = v[vOffset + (w + local_id.y - uniforms.past_sequence_length) * uniforms.N];
        }
      `:`
        tileK[idx] = v[offsetB + (w + local_id.y) * uniforms.N];
      `}
        ${p?"present_value[presentValueOffset + (w + local_id.y) * uniforms.N] = tileK[idx];":""}
      }
     workgroupBarrier();
     for (var k: u32 = 0u; k < TILE_SIZE && w+k < uniforms.K; k++) {
       value += tileQ[TILE_SIZE * local_id.y + k] * tileK[TILE_SIZE * k + local_id.x];
     }
     workgroupBarrier();
   }

   // we need to transpose output from BNSH_v to BSND_v
   let batchIdx = workgroup_id.z / uniforms.num_heads;
   let currentBatchHeadNumber = workgroup_id.z % uniforms.num_heads;
   if (m < uniforms.M && n < uniforms.N) {
     let outputIdx = batchIdx * uniforms.M * uniforms.v_hidden_size + m * uniforms.v_hidden_size
       + currentBatchHeadNumber * uniforms.N + n;
     output[outputIdx] = value;
   }
  }`};return{name:"AttentionScore",shaderCache:{hint:`${i!==void 0};${e}`,inputDependencies:v},getRunData:()=>({outputs:x,dispatchGroup:$,programUniforms:f}),getShaderSource:_}},dr=(e,t,r,i,a,n,s,d,l,p,h)=>{let u=Math.min(e.outputCount,1+(s?1:0)+(d?1:0)),m=p.kvNumHeads!==void 0||u>1?p.pastSequenceLength:0,$=m+p.kvSequenceLength,f=l&&R.size(l.dims)>0?l:void 0,y=[t,r];p.kvNumHeads===void 0&&u>1&&s&&R.size(s.dims)>0&&y.push(s),f&&y.push(f);let v=e.compute(Ao(u,t,r,s,f,p,h,m),{inputs:y,outputs:p.kvNumHeads===void 0&&u>1?[-1,1]:[-1]})[0];e.compute(Io(v,p.batchSize*p.numHeads*p.sequenceLength,$),{inputs:[v],outputs:[]});let x=[v,i];p.kvNumHeads===void 0&&u>1&&d&&R.size(d.dims)>0&&x.push(d),e.compute(zo(u,v,i,d,p,m),{inputs:x,outputs:p.kvNumHeads===void 0&&u>1?[0,2]:[0]})},Ro=(e,t)=>{let r=[t.batchSize,t.numHeads,t.sequenceLength,t.headSize],i=t.sequenceLength,a=t.inputHiddenSize,n=t.headSize,s=12,d={x:Math.ceil(t.headSize/s),y:Math.ceil(t.sequenceLength/s),z:t.batchSize*t.numHeads},l=[e.inputs[0],e.inputs[1],e.inputs[2]],p=[{type:12,data:i},{type:12,data:a},{type:12,data:n},{type:12,data:t.numHeads},{type:12,data:t.headSize},{type:12,data:t.hiddenSize},{type:12,data:t.hiddenSize+t.hiddenSize+t.vHiddenSize}],h=u=>{let m=Y("output_q",l[0].dataType,r),$=Y("output_k",l[0].dataType,r),f=Y("output_v",l[0].dataType,r),y=P("input",l[0].dataType,l[0].dims),v=P("weight",l[1].dataType,l[1].dims),x=P("bias",l[2].dataType,l[2].dims),_=y.type.storage,S=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"hidden_size",type:"u32"},{name:"ldb",type:"u32"}];return`
  const TILE_SIZE = ${s}u;
  var<workgroup> tileInput: array<${_}, ${s*s}>;
  var<workgroup> tileWeightQ: array<${_}, ${s*s}>;
  var<workgroup> tileWeightK: array<${_}, ${s*s}>;
  var<workgroup> tileWeightV: array<${_}, ${s*s}>;
  ${u.registerUniforms(S).declareVariables(y,v,x,m,$,f)}
  ${u.mainStart([s,s,1])}
    let batchIndex = workgroup_id.z / uniforms.num_heads;
    let headNumber = workgroup_id.z % uniforms.num_heads;
    let m = global_id.y;
    let n = global_id.x;

    let inputOffset = batchIndex * (uniforms.M * uniforms.K) + m * uniforms.K;
    let biasOffsetQ = headNumber * uniforms.head_size;
    let biasOffsetK = uniforms.hidden_size + biasOffsetQ;
    let biasOffsetV = uniforms.hidden_size + biasOffsetK;

    var valueQ = ${_}(0);
    var valueK = ${_}(0);
    var valueV = ${_}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileInput[TILE_SIZE * local_id.y + local_id.x] = input[inputOffset + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        let offset = n + (w + local_id.y) * uniforms.ldb;
        tileWeightQ[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetQ + offset];
        tileWeightK[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetK + offset];
        tileWeightV[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetV + offset];
      }
      workgroupBarrier();
      for (var k: u32 = 0u; k<TILE_SIZE && w+k < uniforms.K; k++) {
        let inputTileOffset = TILE_SIZE * local_id.y + k;
        let weightTileOffset = TILE_SIZE * k + local_id.x;
        valueQ += tileInput[inputTileOffset] * tileWeightQ[weightTileOffset];
        valueK += tileInput[inputTileOffset] * tileWeightK[weightTileOffset];
        valueV += tileInput[inputTileOffset] * tileWeightV[weightTileOffset];
      }

      workgroupBarrier();
    }

    let headOffset = (m * uniforms.N + n) % uniforms.head_size;
    valueQ += bias[headOffset + biasOffsetQ];
    valueK += bias[headOffset + biasOffsetK];
    valueV += bias[headOffset + biasOffsetV];

    let offset = workgroup_id.z * uniforms.M * uniforms.N;
    if (m < uniforms.M && n < uniforms.N) {
      let outputIdx = offset + m * uniforms.N + n;
      output_q[outputIdx] = valueQ;
      output_k[outputIdx] = valueK;
      output_v[outputIdx] = valueV;
    }
  }`};return e.compute({name:"AttentionPrepare",shaderCache:{inputDependencies:["type","type","type"]},getRunData:()=>({outputs:[{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0},{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0},{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0}],dispatchGroup:d,programUniforms:p}),getShaderSource:h},{inputs:l,outputs:[-1,-1,-1]})},ap=(e,t)=>{let r=Co(e.inputs,t),[i,a,n]=Ro(e,r);return dr(e,i,a,n,e.inputs[4],void 0,void 0,void 0,e.inputs[5],r,t)}}),Oo,Bo,Mo,np,Cm=F(()=>{"use strict";tt(),ee(),ae(),Te(),ne(),Oo=(e,t)=>{if(!e||e.length!==5)throw new Error("BatchNormalization requires 5 inputs");let r=(i,a,n)=>{let s=a.length;if(s!==i.length)throw new Error(`${n}: num dimensions != ${s}`);a.forEach((d,l)=>{if(d!==i[l])throw new Error(`${n}: dim[${l}] do not match`)})};if(e[0].dims.length>1){let i=t.format==="NHWC"?t.spatial?e[0].dims.slice(-1):e[0].dims.slice(-1).concat(e[0].dims.slice(1,e[0].dims.length-1)):e[0].dims.slice(1,t.spatial?2:void 0);r(e[1].dims,i,"Invalid input scale"),r(e[2].dims,i,"Invalid input B"),r(e[3].dims,i,"Invalid input mean"),r(e[4].dims,i,"Invalid input var")}else r(e[1].dims,[1],"Invalid input scale"),r(e[2].dims,[1],"Invalid input B"),r(e[3].dims,[1],"Invalid input mean"),r(e[4].dims,[1],"Invalid input var")},Bo=(e,t)=>{let{epsilon:r,spatial:i,format:a}=t,n=e[0].dims,s=i?Se(n[n.length-1]):1,d=a==="NHWC"&&n.length>1?s:1,l=R.size(n)/s,p=i,h=p?n.length:n,u=P("x",e[0].dataType,e[0].dims,s),m=P("scale",e[1].dataType,e[1].dims,d),$=P("bias",e[2].dataType,e[2].dims,d),f=P("inputMean",e[3].dataType,e[3].dims,d),y=P("inputVar",e[4].dataType,e[4].dims,d),v=Y("y",e[0].dataType,h,s),x=()=>{let S="";if(i)S=`let cOffset = ${n.length===1?"0u":a==="NHWC"?`outputIndices[${n.length-1}] / ${s}`:"outputIndices[1]"};`;else if(a==="NCHW")S=`
            ${v.indicesSet("outputIndices","0","0")}
            let cOffset = ${v.indicesToOffset("outputIndices")};`;else{S=`var cIndices = ${m.type.indices}(0);
                       cIndices[0] = outputIndices[${n.length-1}];`;for(let k=1;k<m.rank;k++)S+=`cIndices[${k}] = outputIndices[${k}];`;S+=`let cOffset = ${m.indicesToOffset("cIndices")};`}return S},_=S=>`
  const epsilon = ${r};
  ${S.registerUniform("outputSize","u32").declareVariables(u,m,$,f,y,v)}
  ${S.mainStart()}
  ${S.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
    var outputIndices = ${v.offsetToIndices(`global_idx * ${s}`)};
    ${x()}
    let scale = ${m.getByOffset("cOffset")};
    let bias = ${$.getByOffset("cOffset")};
    let inputMean = ${f.getByOffset("cOffset")};
    let inputVar = ${y.getByOffset("cOffset")};
    let x = ${u.getByOffset("global_idx")};
    let value = (x - inputMean) * inverseSqrt(inputVar + epsilon) * scale + bias;
    ${v.setByOffset("global_idx","value")}
  }`;return{name:"BatchNormalization",shaderCache:{hint:`${t.epsilon}_${t.format}_${i}_${s}`,inputDependencies:p?["rank","type","type","type","type"]:void 0},getShaderSource:_,getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:p?[{type:12,data:l},...G(n)]:[{type:12,data:l}]})}},Mo=e=>we(e),np=(e,t)=>{let{inputs:r,outputCount:i}=e,a=Mo({...t,outputCount:i});if(ge.webgpu.validateInputContent&&Oo(r,a),t.trainingMode)throw new Error("BatchNormalization trainingMode is not supported yet.");e.compute(Bo(r,a))}}),Po,Do,sp,Im=F(()=>{"use strict";ae(),ne(),Po=e=>{if(e[0].dims.length!==3)throw new Error("input should have 3 dimensions");if(![320,640,1280].includes(e[0].dims[2]))throw new Error("number of channels should be 320, 640 or 1280");if(e[1].dims.length!==1)throw new Error("bias is expected to have 1 dimensions");if(e[0].dims[2]!==e[1].dims[0])throw new Error("last dimension of input and bias are not the same")},Do=e=>{let t=e[0].dims,r=e[0].dims[2],i=R.size(t)/4,a=e[0].dataType,n=P("input",a,t,4),s=P("bias",a,[r],4),d=P("residual",a,t,4),l=Y("output",a,t,4);return{name:"BiasAdd",getRunData:()=>({outputs:[{dims:t,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(i/64)}}),getShaderSource:p=>`
  const channels = ${r}u / 4;
  ${p.declareVariables(n,s,d,l)}

  ${p.mainStart()}
    ${p.guardAgainstOutOfBoundsWorkgroupSizes(i)}
    let value = ${n.getByOffset("global_idx")}
      + ${s.getByOffset("global_idx % channels")} + ${d.getByOffset("global_idx")};
    ${l.setByOffset("global_idx","value")}
  }`}},sp=e=>{Po(e.inputs),e.compute(Do(e.inputs))}}),Fo,pe,op,up,lp,dp,pp,cp,hp,fp,mp,Uo,gp,yp,wp,$p,or,_p,Wr,bp,vp,xp,Sp,kp,Tp,Ep,Cp,Ip,Ap,zp,Rp,Op,Bp,Mp,Pp,Ni,Dp,ba,va,Fp,Up,Np,No,Wo,Wp,Ka=F(()=>{"use strict";ee(),ae(),Te(),ne(),Fo=(e,t,r,i,a,n,s)=>{let d=Math.ceil(t/4),l="";typeof a=="string"?l=`${a}(a)`:l=a("a");let p=P("inputData",r,[d],4),h=Y("outputData",i,[d],4),u=[{name:"vec_size",type:"u32"}];return s&&u.push(...s),`
      ${e.registerUniforms(u).declareVariables(p,h)}

  ${n??""}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}

    let a = ${p.getByOffset("global_idx")};
    ${h.setByOffset("global_idx",l)}
  }`},pe=(e,t,r,i,a,n=e.dataType,s,d)=>{let l=[{type:12,data:Math.ceil(R.size(e.dims)/4)}];return s&&l.push(...s),{name:t,shaderCache:{hint:a,inputDependencies:["type"]},getShaderSource:p=>Fo(p,R.size(e.dims),e.dataType,n,r,i,d),getRunData:p=>({outputs:[{dims:e.dims,dataType:n}],dispatchGroup:{x:Math.ceil(R.size(p[0].dims)/64/4)},programUniforms:l})}},op=e=>{e.compute(pe(e.inputs[0],"Abs","abs"))},up=e=>{e.compute(pe(e.inputs[0],"Acos","acos"))},lp=e=>{e.compute(pe(e.inputs[0],"Acosh","acosh"))},dp=e=>{e.compute(pe(e.inputs[0],"Asin","asin"))},pp=e=>{e.compute(pe(e.inputs[0],"Asinh","asinh"))},cp=e=>{e.compute(pe(e.inputs[0],"Atan","atan"))},hp=e=>{e.compute(pe(e.inputs[0],"Atanh","atanh"))},fp=e=>we(e),mp=(e,t)=>{let r;switch(t.to){case 10:r="vec4<f16>";break;case 1:r="vec4<f32>";break;case 12:r="vec4<u32>";break;case 6:r="vec4<i32>";break;case 9:r="vec4<bool>";break;default:throw new RangeError(`not supported type (specified in attribute 'to' from 'Cast' operator): ${t.to}`)}e.compute(pe(e.inputs[0],"Cast",r,void 0,t.cacheKey,t.to))},Uo=e=>{let t,r,i=e.length>=2&&e[1].data!==0,a=e.length>=3&&e[2].data!==0;switch(e[0].dataType){case 1:t=i?e[1].getFloat32Array()[0]:-34028234663852886e22,r=a?e[2].getFloat32Array()[0]:34028234663852886e22;break;case 10:t=i?e[1].getUint16Array()[0]:64511,r=a?e[2].getUint16Array()[0]:31743;break;default:throw new Error("Unsupport data type")}return we({min:t,max:r})},gp=(e,t)=>{let r=t||Uo(e.inputs),i=Be(e.inputs[0].dataType);e.compute(pe(e.inputs[0],"Clip",a=>`clamp(${a}, vec4<${i}>(uniforms.min), vec4<${i}>(uniforms.max))`,void 0,r.cacheKey,void 0,[{type:e.inputs[0].dataType,data:r.min},{type:e.inputs[0].dataType,data:r.max}],[{name:"min",type:i},{name:"max",type:i}]),{inputs:[0]})},yp=e=>{e.compute(pe(e.inputs[0],"Ceil","ceil"))},wp=e=>{e.compute(pe(e.inputs[0],"Cos","cos"))},$p=e=>{e.compute(pe(e.inputs[0],"Cosh","cosh"))},or=e=>we(e),_p=(e,t)=>{let r=Be(e.inputs[0].dataType);e.compute(pe(e.inputs[0],"Elu",i=>`elu_vf32(${i})`,`
  const elu_alpha_ = ${r}(${t.alpha});

  fn elu_f32(a: ${r}) -> ${r} {
  return select((exp(a) - 1.0) * elu_alpha_, a, a >= 0.0);
  }

  fn elu_vf32(v: vec4<${r}>) -> vec4<${r}> {
  return vec4(elu_f32(v.x), elu_f32(v.y), elu_f32(v.z), elu_f32(v.w));
  }`,t.cacheKey))},Wr=(e="f32")=>`
const r0: ${e} = 0.3275911;
const r1: ${e} = 0.254829592;
const r2: ${e} = -0.284496736;
const r3: ${e} = 1.421413741;
const r4: ${e} = -1.453152027;
const r5: ${e} = 1.061405429;

fn erf_vf32(v: vec4<${e}>) -> vec4<${e}> {
  let absv = abs(v);
  let x = 1.0 / (1.0 + r0 * absv);
  return sign(v) * (1.0 - ((((r5 * x + r4) * x + r3) * x + r2) * x + r1) * x * exp(-absv * absv));
}`,bp=e=>{let t=Be(e.inputs[0].dataType);e.compute(pe(e.inputs[0],"Erf",r=>`erf_vf32(${r})`,Wr(t)))},vp=e=>{e.compute(pe(e.inputs[0],"Exp","exp"))},xp=e=>{e.compute(pe(e.inputs[0],"Floor","floor"))},Sp=e=>{let t=Be(e.inputs[0].dataType);e.compute(pe(e.inputs[0],"Gelu",r=>`0.5 * ${r} * (1.0 + erf_vf32(${r} * 0.7071067811865475))`,Wr(t)))},kp=(e,t)=>{let r=Be(e.inputs[0].dataType);e.compute(pe(e.inputs[0],"LeakyRelu",i=>`select(leaky_relu_alpha_ * ${i}, ${i}, ${i} >= vec4<${r}>(0.0))`,`const leaky_relu_alpha_ = ${r}(${t.alpha});`,t.cacheKey))},Tp=e=>{e.compute(pe(e.inputs[0],"Not",t=>`!${t}`))},Ep=e=>{e.compute(pe(e.inputs[0],"Neg",t=>`-${t}`))},Cp=e=>{e.compute(pe(e.inputs[0],"Reciprocal",t=>`1.0/${t}`))},Ip=e=>{let t=Be(e.inputs[0].dataType);e.compute(pe(e.inputs[0],"Relu",r=>`select(vec4<${t}>(0.0), ${r}, ${r} > vec4<${t}>(0.0))`))},Ap=e=>{e.compute(pe(e.inputs[0],"Sigmoid",t=>`(1.0 / (1.0 + exp(-${t})))`))},zp=e=>we(e),Rp=(e,t)=>{let r=Be(e.inputs[0].dataType);e.compute(pe(e.inputs[0],"HardSigmoid",i=>`max(vec4<${r}>(0.0), min(vec4<${r}>(1.0), ${t.alpha} * ${i} + vec4<${r}>(${t.beta})))`,void 0,t.cacheKey))},Op=e=>{e.compute(pe(e.inputs[0],"Sin","sin"))},Bp=e=>{e.compute(pe(e.inputs[0],"Sinh","sinh"))},Mp=e=>{e.compute(pe(e.inputs[0],"Sqrt","sqrt"))},Pp=e=>{e.compute(pe(e.inputs[0],"Tan","tan"))},Ni=e=>`sign(${e}) * (1 - exp(-2 * abs(${e}))) / (1 + exp(-2 * abs(${e})))`,Dp=e=>{e.compute(pe(e.inputs[0],"Tanh",Ni))},ba=(e="f32")=>`
const fast_gelu_a: ${e} = 0.5;
const fast_gelu_b: ${e} = 0.7978845608028654;
const fast_gelu_c: ${e} = 0.035677408136300125;

fn tanh_v(v: vec4<${e}>) -> vec4<${e}> {
  return ${Ni("v")};
}
`,va=e=>`(fast_gelu_a + fast_gelu_a * tanh_v(${e} * (fast_gelu_c * ${e} * ${e} + fast_gelu_b))) * ${e}`,Fp=e=>{let t=Be(e.inputs[0].dataType);e.compute(pe(e.inputs[0],"FastGelu",va,ba(t),void 0,e.inputs[0].dataType))},Up=(e,t)=>{let r=Be(e.inputs[0].dataType);return e.compute(pe(e.inputs[0],"ThresholdedRelu",i=>`select(vec4<${r}>(0.0), ${i}, ${i} > thresholded_relu_alpha_)`,`const thresholded_relu_alpha_ = vec4<${r}>(${t.alpha});`,t.cacheKey)),0},Np=e=>{e.compute(pe(e.inputs[0],"Log","log"))},No=(e,t)=>`
const alpha = vec4<${e}>(${t});
const one = ${e}(1.0);
const zero = ${e}(0.0);

fn quick_gelu_impl(x: vec4<${e}>) -> vec4<${e}> {
  let v = x *alpha;
  var x1 : vec4<${e}>;
  for (var i = 0; i < 4; i = i + 1) {
    if (v[i] >= zero) {
      x1[i] = one / (one + exp(-v[i]));
    } else {
      x1[i] = one - one / (one + exp(v[i]));
    }
  }
  return x * x1;
}
`,Wo=e=>`quick_gelu_impl(${e})`,Wp=(e,t)=>{let r=Be(e.inputs[0].dataType);e.compute(pe(e.inputs[0],"QuickGelu",Wo,No(r,t.alpha),t.cacheKey,e.inputs[0].dataType))}}),Lo,qo,Lp,Am=F(()=>{"use strict";ae(),ne(),Ka(),Lo=e=>{if(e[0].dims.length!==3)throw new Error("input should have 3 dimensions");if(![2560,5120,10240].includes(e[0].dims[2]))throw new Error("hidden state should be 2560, 5120 or 10240");if(e[1].dims.length!==1)throw new Error("bias is expected to have 1 dimensions");if(e[0].dims[2]!==e[1].dims[0])throw new Error("last dimension of input and bias are not the same")},qo=e=>{let t=e[0].dims.slice();t[2]=t[2]/2;let r=P("input",e[0].dataType,e[0].dims,4),i=P("bias",e[0].dataType,[e[0].dims[2]],4),a=Y("output",e[0].dataType,t,4),n=R.size(t)/4,s=Ee(e[0].dataType);return{name:"BiasSplitGelu",getRunData:()=>({outputs:[{dims:t,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(n/64)}}),getShaderSource:d=>`
  const M_SQRT2 = sqrt(2.0);
  const halfChannels = ${e[0].dims[2]/4/2}u;

  ${d.declareVariables(r,i,a)}

  ${Wr(s)}

  ${d.mainStart()}
    ${d.guardAgainstOutOfBoundsWorkgroupSizes(n)}
    let biasIdx = global_idx % halfChannels;
    let batchIndex = global_idx / halfChannels;
    let inputOffset = biasIdx + batchIndex * halfChannels * 2;
    let valueLeft = input[inputOffset] + bias[biasIdx];
    let valueRight = input[inputOffset + halfChannels] + bias[biasIdx + halfChannels];
    let geluRight = valueRight * 0.5 * (erf_vf32(valueRight / M_SQRT2) + 1);

    ${a.setByOffset("global_idx","valueLeft * geluRight")}
  }`}},Lp=e=>{Lo(e.inputs),e.compute(qo(e.inputs))}}),Vo,jo,Je,qp,Vp,jp,Gp,Hp,Kp,Yp,Zp,Qp,Xp,zm=F(()=>{"use strict";ee(),ae(),ne(),Vo=(e,t,r,i,a,n,s,d,l,p,h,u)=>{let m,$;typeof d=="string"?m=$=(_,S)=>`${d}((${_}),(${S}))`:typeof d=="function"?m=$=d:(m=d.scalar,$=d.vector);let f=Y("outputData",h,i.length,4),y=P("aData",l,t.length,4),v=P("bData",p,r.length,4),x;if(a)if(n){let _=R.size(t)===1,S=R.size(r)===1,k=t.length>0&&t[t.length-1]%4===0,T=r.length>0&&r[r.length-1]%4===0;_||S?x=f.setByOffset("global_idx",$(_?`${y.type.value}(${y.getByOffset("0")}.x)`:y.getByOffset("global_idx"),S?`${v.type.value}(${v.getByOffset("0")}.x)`:v.getByOffset("global_idx"))):x=`
            let outputIndices = ${f.offsetToIndices("global_idx * 4u")};
            let offsetA = ${y.broadcastedIndicesToOffset("outputIndices",f)};
            let offsetB = ${v.broadcastedIndicesToOffset("outputIndices",f)};
            ${f.setByOffset("global_idx",$(s||k?y.getByOffset("offsetA / 4u"):`${y.type.value}(${y.getByOffset("offsetA / 4u")}[offsetA % 4u])`,s||T?v.getByOffset("offsetB / 4u"):`${v.type.value}(${v.getByOffset("offsetB / 4u")}[offsetB % 4u])`))}
          `}else x=f.setByOffset("global_idx",$(y.getByOffset("global_idx"),v.getByOffset("global_idx")));else{if(!n)throw new Error("no necessary to use scalar implementation for element-wise binary op implementation.");let _=(S,k,T="")=>{let I=`aData[indexA${k}][componentA${k}]`,C=`bData[indexB${k}][componentB${k}]`;return`
            let outputIndices${k} = ${f.offsetToIndices(`global_idx * 4u + ${k}u`)};
            let offsetA${k} = ${y.broadcastedIndicesToOffset(`outputIndices${k}`,f)};
            let offsetB${k} = ${v.broadcastedIndicesToOffset(`outputIndices${k}`,f)};
            let indexA${k} = offsetA${k} / 4u;
            let indexB${k} = offsetB${k} / 4u;
            let componentA${k} = offsetA${k} % 4u;
            let componentB${k} = offsetB${k} % 4u;
            ${S}[${k}] = ${T}(${m(I,C)});
          `};h===9?x=`
            var data = vec4<u32>(0);
            ${_("data",0,"u32")}
            ${_("data",1,"u32")}
            ${_("data",2,"u32")}
            ${_("data",3,"u32")}
            outputData[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:x=`
            ${_("outputData[global_idx]",0)}
            ${_("outputData[global_idx]",1)}
            ${_("outputData[global_idx]",2)}
            ${_("outputData[global_idx]",3)}
          `}return`
        ${e.registerUniform("vec_size","u32").declareVariables(y,v,f)}

        ${u??""}

        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${x}
      }`},jo=(e,t,r,i,a,n,s=r.dataType)=>{let d=!R.areEqual(r.dims,i.dims),l=r.dims,p=R.size(r.dims),h=!1,u=!1,m=[d];if(d){let $=Gt.calcShape(r.dims,i.dims,!1);if(!$)throw new Error("Can't perform binary op on the given tensors");l=$,p=R.size(l);let f=R.size(r.dims)===1,y=R.size(i.dims)===1,v=r.dims.length>0&&r.dims[r.dims.length-1]%4===0,x=i.dims.length>0&&i.dims[i.dims.length-1]%4===0;m.push(f),m.push(y),m.push(v),m.push(x);let _=1;for(let S=1;S<l.length;S++){let k=r.dims[r.dims.length-S]??1,T=i.dims[i.dims.length-S]??1;if(k===T)_*=k;else break}_%4===0?(u=!0,h=!0):(f||y||v||x)&&(h=!0)}else h=!0;return m.push(h),{name:e,shaderCache:{hint:t+m.map($=>$.toString()).join("_"),inputDependencies:["rank","rank"]},getShaderSource:$=>Vo($,r.dims,i.dims,l,h,d,u,a,r.dataType,i.dataType,s,n),getRunData:()=>({outputs:[{dims:l,dataType:s}],dispatchGroup:{x:Math.ceil(p/64/4)},programUniforms:[{type:12,data:Math.ceil(R.size(l)/4)},...G(r.dims,i.dims,l)]})}},Je=(e,t,r,i,a,n)=>{e.compute(jo(t,a??"",e.inputs[0],e.inputs[1],r,i,n))},qp=e=>{Je(e,"Add",(t,r)=>`${t}+${r}`)},Vp=e=>{Je(e,"Div",(t,r)=>`${t}/${r}`)},jp=e=>{Je(e,"Equal",{scalar:(t,r)=>`u32(${t}==${r})`,vector:(t,r)=>`vec4<u32>(${t}==${r})`},void 0,void 0,9)},Gp=e=>{Je(e,"Mul",(t,r)=>`${t}*${r}`)},Hp=e=>{let t=P("input",e.inputs[0].dataType,e.inputs[0].dims).type.value;Je(e,"Pow",{scalar:(r,i)=>`pow_custom(${r},${i})`,vector:(r,i)=>`pow_vector_custom(${r},${i})`},`
    fn pow_custom(a : ${t}, b : ${t}) -> ${t} {
      if (b == ${t}(0.0)) {
        return ${t}(1.0);
      } else if (a < ${t}(0.0) && f32(b) != floor(f32(b))) {
        return ${t}(pow(f32(a), f32(b))); // NaN
      }
      return select(sign(a), ${t}(1.0), round(f32(abs(b) % ${t}(2.0))) != 1.0) * ${t}(${t==="i32"?"round":""}(pow(f32(abs(a)), f32(b))));
    }
    fn pow_vector_custom(a : vec4<${t}>, b : vec4<${t}>) -> vec4<${t}> {
      // TODO: implement vectorized pow
      return vec4<${t}>(pow_custom(a.x, b.x), pow_custom(a.y, b.y), pow_custom(a.z, b.z), pow_custom(a.w, b.w));
    }
      `)},Kp=e=>{Je(e,"Sub",(t,r)=>`${t}-${r}`)},Yp=e=>{Je(e,"Greater",{scalar:(t,r)=>`u32(${t}>${r})`,vector:(t,r)=>`vec4<u32>(${t}>${r})`},void 0,void 0,9)},Zp=e=>{Je(e,"Less",{scalar:(t,r)=>`u32(${t}<${r})`,vector:(t,r)=>`vec4<u32>(${t}<${r})`},void 0,void 0,9)},Qp=e=>{Je(e,"GreaterOrEqual",{scalar:(t,r)=>`u32(${t}>=${r})`,vector:(t,r)=>`vec4<u32>(${t}>=${r})`},void 0,void 0,9)},Xp=e=>{Je(e,"LessOrEqual",{scalar:(t,r)=>`u32(${t}<=${r})`,vector:(t,r)=>`vec4<u32>(${t}<=${r})`},void 0,void 0,9)}}),Go,Ho,Ko,Yo,Jp,ec,Rm=F(()=>{"use strict";ee(),ae(),Te(),ne(),Go=(e,t)=>{if(!e||e.length<1)throw new Error("too few inputs");let r=0,i=e[r],a=i.dataType,n=i.dims.length;e.forEach((s,d)=>{if(d!==r){if(s.dataType!==a)throw new Error("input tensors should be one type");if(s.dims.length!==n)throw new Error("input tensors should have the same shape");s.dims.forEach((l,p)=>{if(p!==t&&l!==i.dims[p])throw new Error("non concat dimensions must match")})}})},Ho=(e,t)=>`
  fn calculateInputIndex(index: u32) -> u32 {
    let sizeInConcatAxis = array<u32, ${e}u>(${t});
    for (var i: u32 = 0u; i < ${e}; i += 1u ) {
      if (index < sizeInConcatAxis[i]) {
        return i;
      }
    }
    return ${e}u;
  }`,Ko=(e,t)=>{let r=e.length,i=[];for(let a=0;a<r;++a){let n=t.setByOffset("global_idx",e[a].getByIndices("indices"));r===1?i.push(n):a===0?i.push(`if (inputIndex == ${a}u) { ${n} }`):a===r-1?i.push(`else { ${n} }`):i.push(`else if (inputIndex == ${a}) { ${n} }`)}return i.join(`
`)},Yo=(e,t,r,i)=>{let a=R.size(r),n=new Array(e.length),s=new Array(e.length),d=0,l=[],p=[],h=[{type:12,data:a}];for(let y=0;y<e.length;++y)d+=e[y].dims[t],n[y]=d,p.push(e[y].dims.length),s[y]=P(`input${y}`,i,p[y]),l.push("rank"),h.push({type:12,data:n[y]});for(let y=0;y<e.length;++y)h.push(...G(e[y].dims));h.push(...G(r));let u=Y("output",i,r.length),m=u.indicesGet("indices",t),$=Array.from(Array(n.length).keys()).map(y=>`uniforms.sizeInConcatAxis${y}`).join(","),f=y=>`

  ${(()=>{y.registerUniform("outputSize","u32");for(let v=0;v<e.length;v++)y.registerUniform(`sizeInConcatAxis${v}`,"u32");return y.declareVariables(...s,u)})()}

  ${Ho(n.length,$)}

  ${y.mainStart()}
    ${y.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

    var indices = ${u.offsetToIndices("global_idx")};

    let inputIndex = calculateInputIndex(${m});
    if (inputIndex != 0u) {
      let sizeInConcatAxis = array<u32, ${n.length}u>(${$});
      ${m} -= sizeInConcatAxis[inputIndex - 1u];
    }

    ${Ko(s,u)}
  }`;return{name:"Concat",shaderCache:{hint:`${t}`,inputDependencies:l},getRunData:()=>({outputs:[{dims:r,dataType:i}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:h}),getShaderSource:f}},Jp=(e,t)=>{let r=e.inputs,i=r[0].dims,a=R.normalizeAxis(t.axis,i.length);Go(r,a);let n=i.slice();n[a]=r.reduce((d,l)=>d+(l.dims.length>a?l.dims[a]:0),0);let s=r.filter(d=>R.size(d.dims)>0);e.compute(Yo(s,a,n,r[0].dataType),{inputs:s})},ec=e=>we({axis:e.axis})}),bt,vt,xt,Ya,kt=F(()=>{"use strict";ee(),ae(),bt=(e,t,r="f32")=>{switch(e.activation){case"Relu":return`value = max(value, ${t}(0.0));`;case"Sigmoid":return`value = (${t}(1.0) / (${t}(1.0) + exp(-value)));`;case"Clip":return`value = clamp(value, ${t}(${r}(uniforms.clip_min)), ${t}(${r}(uniforms.clip_max)));`;case"HardSigmoid":return`value = max(${t}(0.0), min(${t}(1.0), ${r}(uniforms.alpha) * value + ${r}(uniforms.beta)));`;case"LeakyRelu":return`value = select(${r}(uniforms.alpha) * value, value, value >= ${t}(0.0));`;case"Tanh":return`let e2x = exp(-2.0 * abs(value));
              value = sign(value) * (1.0 - e2x) / (1.0 + e2x);
        `;case"":return"";default:throw new Error(`Unsupported activation ${e.activation}`)}},vt=(e,t)=>{e.activation==="Clip"?t.push({type:1,data:e.clipMax},{type:1,data:e.clipMin}):e.activation==="HardSigmoid"?t.push({type:1,data:e.alpha},{type:1,data:e.beta}):e.activation==="LeakyRelu"&&t.push({type:1,data:e.alpha})},xt=(e,t)=>{e.activation==="Clip"?t.push({name:"clip_max",type:"f32"},{name:"clip_min",type:"f32"}):e.activation==="HardSigmoid"?t.push({name:"alpha",type:"f32"},{name:"beta",type:"f32"}):e.activation==="LeakyRelu"&&t.push({name:"alpha",type:"f32"})},Ya=e=>{let t=e?.activation||"";if(t==="HardSigmoid"){let[r,i]=e?.activation_params||[.2,.5];return{activation:t,alpha:r,beta:i}}else if(t==="Clip"){let[r,i]=e?.activation_params||[zd,Rd];return{activation:t,clipMax:i,clipMin:r}}else if(t==="LeakyRelu"){let[r]=e?.activation_params||[.01];return{activation:t,alpha:r}}return{activation:t}}}),Me,Za,Jr=F(()=>{"use strict";Me=(e,t)=>{switch(e){case 1:return t;case 2:return`vec2<${t}>`;case 3:return`vec3<${t}>`;case 4:return`vec4<${t}>`;default:throw new Error(`${e}-component is not supported.`)}},Za=e=>`
      ${e?"value = value + getBiasByOutputCoords(coords);":""}
      `}),Qa,tc=F(()=>{"use strict";Qa=e=>`
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
      shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
    i32(${e}.x), i32(${e}.y), i32(${e}.z), 1));
}
`}),Zo,Qo,Kr,Wi,Xo,Yr,Jo,Xa,ei=F(()=>{"use strict";ee(),ae(),ne(),kt(),Jr(),Zo=(e,t)=>e?`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          kStart + inputRow,
          globalRowStart / innerElementSize + inputCol${t?", batchIndices":""});
        `:`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          globalRow + innerRow,
          kStart / innerElementSize + inputCol${t?", batchIndices":""});
        `,Qo=(e,t)=>e?`
        let ACached0 = mm_Asub[k * innerElementSize][localRow];
        let ACached1 = mm_Asub[k * innerElementSize + 1][localRow];
        let ACached2 = mm_Asub[k * innerElementSize + 2][localRow];
        ${t===3?"":"let ACached3 = mm_Asub[k * innerElementSize + 3][localRow];"}
        for (var i = 0; i < rowPerThread; i = i + 1) {
          acc[i] = BCached0 * ACached0[i] + acc[i];
          acc[i] = BCached1 * ACached1[i] + acc[i];
          acc[i] = BCached2 * ACached2[i] + acc[i];
          ${t===3?"":"acc[i] = BCached3 * ACached3[i] + acc[i];"}
        }`:`
        for (var i = 0; i < rowPerThread; i = i + 1) {
          let ACached = mm_Asub[tileRow + i][k];
          acc[i] = BCached0 * ACached.x + acc[i];
          acc[i] = BCached1 * ACached.y + acc[i];
          acc[i] = BCached2 * ACached.z + acc[i];
          ${t===3?"":"acc[i] = BCached3 * ACached.w + acc[i];"}
        }`,Kr=(e,t,r="f32",i,a=!1,n=32,s=!1,d=32)=>{let l=t[1]*e[1],p=t[0]*e[0],h=a?l:n,u=a?n:l,m=h/t[0],$=n/t[1];if(!((a&&m===4&&e[1]===4||!a&&(m===3||m===4))&&h%t[0]===0&&n%t[1]===0&&e[0]===4))throw new Error(`If transposeA ${a} is true, innerElementSize ${m} and workPerThread[1] ${e[1]} must be 4.
      Otherwise, innerElementSize ${m} must be 3 or 4.
  tileAWidth ${h} must be divisible by workgroupSize[0]${t[0]}. tileInner ${n} must be divisible by workgroupSize[1] ${t[1]}. colPerThread ${e[0]} must be 4.`);return`
var<workgroup> mm_Asub: array<array<vec${m}<${r}>, ${h/m}>, ${u}>;
var<workgroup> mm_Bsub: array<array<vec4<${r}>, ${p/e[0]}>, ${n}>;

const rowPerThread = ${e[1]};
const colPerThread = ${e[0]};
const innerElementSize = ${m};
const tileInner = ${n};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
  let localRow = i32(localId.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(localId.x);

  let globalRow =i32(globalId.y) * rowPerThread;
  let globalCol = i32(globalId.x);
  let batch = ${s?"0":"i32(globalId.z)"};
  ${i?`let batchIndices = ${i.offsetToIndices("u32(batch)")};`:""}
  let globalRowStart = i32(workgroupId.y) * ${l};

  let num_tiles = ${s?`${Math.ceil(d/n)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
  var kStart = ${s?`i32(globalId.z) * ${d}`:"0"};

  var acc: array<vec4<${r}>, rowPerThread>;

  // Loop over shared dimension.
  let tileRowB = localRow * ${$};
  for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let inputRow = tileRow + innerRow;
          let inputCol = tileCol;
          ${Zo(a,i)}
      }

      // Load one tile of B into local memory.
      for (var innerRow = 0; innerRow < ${$}; innerRow = innerRow + 1) {
          let inputRow = tileRowB + innerRow;
          let inputCol = tileCol;
          mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol${i?", batchIndices":""});
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
          let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
          let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
          let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
          ${m===3?"":"let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];"}

          ${Qo(a,m)}
      }

      workgroupBarrier();
  }

  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }
}`},Wi=(e,t)=>e?`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              kStart + inputRow,
              globalRowStart + inputCol${t?", batchIndices":""});
            `:`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              globalRowStart + inputRow,
              kStart + inputCol${t?", batchIndices":""});
            `,Xo=e=>e?"let ACached = mm_Asub[k][tileRow + innerRow];":"let ACached = mm_Asub[tileRow + innerRow][k];",Yr=(e,t,r="f32",i,a=!1,n=32,s=!1,d=32,l=!1)=>{let p=e[1]*t[1],h=e[0]*t[0],u=a?p:n,m=a?n:p;if(!(m%t[1]===0&&u%t[0]===0&&n%t[1]===0))throw new Error(`tileAHight ${m} must be divisible by workgroupSize[1]${t[1]}, tileAWidth ${u} must be divisible by workgroupSize[0]${t[0]}, tileInner ${n} must be divisible by workgroupSize[1]${t[1]}`);let $=m/t[1],f=u/t[0],y=n/t[1],v=l?`
    let localRow = i32(localId.y);
    let localCol = i32(localId.x);
    let globalRowStart = i32(workgroupId.y) * ${p};
    let globalColStart = i32(workgroupId.x) * ${h};

    // Loop over shared dimension.
    for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var inputRow = localRow; inputRow < ${m}; inputRow = inputRow + ${t[1]}) {
        for (var inputCol = localCol; inputCol < ${u}; inputCol = inputCol + ${t[0]}) {
          ${Wi(a,i)}
        }
      }
      // Load one tile of B into local memory.
      for (var inputRow = localRow; inputRow < ${n}; inputRow = inputRow + ${t[1]}) {
            for (var inputCol = localCol; inputCol < ${h}; inputCol = inputCol + ${t[0]}) {
          mm_Bsub[inputRow][inputCol] = mm_readB(batch,
            kStart + inputRow,
            globalColStart + inputCol${i?", batchIndices":""});
        }
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      var BCached : array<${r}, colPerThread>;
      for (var k = 0; k < tileInner; k = k + 1) {
        for (var inner = 0; inner < colPerThread; inner = inner + 1) {
          BCached[inner] = mm_Bsub[k][localCol + inner * ${t[0]}];
        }
        for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let ACached = ${a?`mm_Asub[k][localRow + innerRow * ${t[1]}];`:`mm_Asub[localRow + innerRow * ${t[1]}][k];`}
          for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
            acc[innerRow][innerCol] = acc[innerRow][innerCol] +
                ACached * BCached[innerCol];
          }
        }
      }
      workgroupBarrier();
    }
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let gRow = globalRowStart + localRow + innerRow * ${t[1]};
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        let gCol = globalColStart + localCol + innerCol * ${t[0]};
        mm_write(batch, gRow, gCol, acc[innerRow][innerCol]);
      }
    }
    `:`
let tileRow = i32(localId.y) * rowPerThread;
let tileCol = i32(localId.x) * colPerThread;

let globalRow = i32(globalId.y) * rowPerThread;
let globalCol = i32(globalId.x) * colPerThread;
let globalRowStart = i32(workgroupId.y) * ${p};

let tileRowA = i32(localId.y) * ${$};
let tileColA = i32(localId.x) * ${f};
let tileRowB = i32(localId.y) * ${y};
// Loop over shared dimension.
for (var t = 0; t < num_tiles; t = t + 1) {
  // Load one tile of A into local memory.
  for (var innerRow = 0; innerRow < ${$}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < ${f}; innerCol = innerCol + 1) {
      let inputRow = tileRowA + innerRow;
      let inputCol = tileColA + innerCol;
      ${Wi(a,i)}
    }
  }

  // Load one tile of B into local memory.
  for (var innerRow = 0; innerRow < ${y}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol + innerCol;
      mm_Bsub[inputRow][inputCol] = mm_readB(batch,
        kStart + inputRow,
        globalCol + innerCol${i?", batchIndices":""});
    }
  }
  kStart = kStart + tileInner;
  workgroupBarrier();

  // Compute acc values for a single thread.
  var BCached : array<${r}, colPerThread>;
  for (var k = 0; k < tileInner; k = k + 1) {
    for (var inner = 0; inner < colPerThread; inner = inner + 1) {
      BCached[inner] = mm_Bsub[k][tileCol + inner];
    }

    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      ${Xo(a)}
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        acc[innerRow][innerCol] = acc[innerRow][innerCol] + ACached * BCached[innerCol];
      }
    }
  }

  workgroupBarrier();
}

for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
  for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
    mm_write(batch, globalRow + innerRow, globalCol + innerCol,
        acc[innerRow][innerCol]);
  }
}
`;return`
  var<workgroup> mm_Asub : array<array<${r}, ${u}>, ${m}>;
  var<workgroup> mm_Bsub : array<array<${r}, ${h}>, ${n}>;
  const rowPerThread = ${e[1]};
  const colPerThread = ${e[0]};
  const tileInner = ${n};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
    let batch = ${s?"0":"i32(globalId.z)"};
    ${i?`let batchIndices = ${i.offsetToIndices("u32(batch)")};`:""}
    let num_tiles = ${s?`${Math.ceil(d/n)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
    var kStart = ${s?`i32(globalId.z) * ${d}`:"0"};

    var acc : array<array<${r}, colPerThread>, rowPerThread>;
    ${v}
  }
`},Jo=(e,t,r,i,a,n=!1)=>{let[s,d,l]=a,[p,h,u,m]=i,$=lr(s,l),f=lr(d,l),y=Ee(i[0].type.tensor),v=()=>{let _=h.rank,S=p.rank,k=`var aIndices: ${h.type.indices};`;for(let T=_-2-1,I=S-1;T>=0;T--,I--)k+=`
aIndices[${T}] = ${S>1?`batchIndices[${I}]`:"batchIndices"};`;return $.forEach(T=>{k+=`
aIndices[${T}] = 0;`}),k+=`
aIndices[${_-2}] = u32(row);
                   aIndices[${_-1}] = u32(colIn);`,k},x=()=>{let _=u.rank,S=p.rank,k=`var bIndices: ${u.type.indices};`;for(let T=_-2-1,I=S-1;T>=0;T--,I--)k+=`
bIndices[${T}] = ${S>1?`batchIndices[${I}]`:"batchIndices"};`;return f.forEach(T=>{k+=`
bIndices[${T}] = 0;`}),k+=`
bIndices[${_-2}] = u32(row);
                   bIndices[${_-1}] = u32(colIn);`,k};return`
    fn mm_readA(batch: i32, row: i32, colIn: i32, batchIndices: ${p.type.indices}) -> ${Me(e,y)} {
      var value = ${Me(e,y)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_a_outer && col < uniforms.dim_inner)
      {
        ${v()}
        value = ${h.getByIndices("aIndices")};
      }
      return value;
    }

    fn mm_readB(batch: i32, row: i32, colIn: i32, batchIndices: ${p.type.indices}) -> ${Me(e,y)} {
      var value = ${Me(e,y)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_inner && col < uniforms.dim_b_outer)
      {
        ${x()}
        value = ${u.getByIndices("bIndices")};
      }
      return value;
    }

    fn mm_write(batch: i32, row: i32, colIn: i32, valueIn: ${Me(e,y)}) {
      let col = colIn * ${e};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer) {
        var value = valueIn;
        let coords = vec3<i32>(batch, row, colIn);
        ${t?`value = value + ${n?"bias[colIn]":`${Me(e,y)}(bias[row])`};`:""}
        ${r}
        ${m.setByIndices("vec3<u32>(coords)","value")}
      }
    }
    `},Xa=(e,t,r,i,a=!1,n)=>{let s=e[0].dims,d=e[1].dims,l=s.slice(0,-2),p=d.slice(0,-2),h=i?i.slice(0,-2):r.slice(0,-2),u=R.size(h),m=s[s.length-2],$=s[s.length-1],f=d[d.length-1],y=$%4===0&&f%4===0,v=m<=8?[4,1,1]:[4,4,1],x=[8,8,1],_=[Math.ceil(f/x[0]/v[0]),Math.ceil(m/x[1]/v[1]),Math.ceil(u/x[2]/v[2])],S=y?4:1,k=[...l,m,$/S],T=k.length,I=[...p,$,f/S],C=I.length,M=[u,m,f/S],N=[{type:6,data:m},{type:6,data:f},{type:6,data:$}];vt(t,N),N.push(...G(h,k,I));let W=["rank","rank"],J=e.length>2;J&&(N.push(...G(e[2].dims)),W.push("rank")),N.push(...G(M));let K=X=>{let ie=h.length,ue=ja("batchDims",e[0].dataType,ie,1),q=Ee(e[0].dataType),de=P("a",e[0].dataType,T,S),se=P("b",e[1].dataType,C,S),j=Y("result",e[0].dataType,M.length,S),re=[de,se];if(J){let be=a?S:1;re.push(P("bias",e[2].dataType,e[2].dims.length,be))}let O=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"}];xt(t,O);let U=Ee(j.type.tensor),te=bt(t,j.type.value,U),fe=Jo(S,J,te,[ue,de,se,j],[l,p,h],a);return`
  ${X.registerUniforms(O).registerInternalVariables(ue).declareVariables(...re,j)}
  ${fe}
  ${y?Kr(v,x,q,ue):Yr(v,x,q,ue)}
                   `};return{name:"MatMul",shaderCache:{hint:`${v};${t.activation};${y};${a}`,inputDependencies:W},getRunData:()=>({outputs:[{dims:n?n(r):r,dataType:e[0].dataType}],dispatchGroup:{x:_[0],y:_[1],z:_[2]},programUniforms:N}),getShaderSource:K}}}),eu,rc,Om=F(()=>{"use strict";ee(),ut(),ne(),kt(),Jr(),tc(),ei(),eu=(e,t,r,i,a=!1,n,s=4,d=4,l=4,p="f32")=>{let h=N=>{switch(N){case 1:return"resData = x[xIndex];";case 3:return`resData = vec3<${p}>(x[xIndex], x[xIndex + 1], x[xIndex + 2]);`;case 4:return"resData = x[xIndex / 4];";default:throw new Error(`innerElementSize ${N} is not supported.`)}},u=N=>{switch(N){case 1:return"return w[row * i32(uniforms.w_shape[3]) + colIn];";case 4:return"return w[row * i32(uniforms.w_shape[3]) / 4 + colIn];";default:throw new Error(`innerElementSize ${N} is not supported.`)}},m=e?`
    let coord = vec4<i32>(batch, xRow, xCol, xCh);
    `:`
    let coord = vec4<i32>(batch, xCh, xRow, xCol);
    `,$=e?`
    let coords = vec4<i32>(
      batch,
      row / outWidth,
      row % outWidth,
      col);
    `:`
    let coords = vec4<i32>(
      batch,
      row,
      col / outWidth,
      col % outWidth);
    `,f=e?"i32(uniforms.x_shape[1])":"i32(uniforms.x_shape[2])",y=e?"i32(uniforms.x_shape[2])":"i32(uniforms.x_shape[3])",v=e?"row":"col",x=e?"col":"row",_=`
    let inChannels = i32(uniforms.w_shape[2]);
    let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
    let outRow = ${v} / outWidth;
    let outCol = ${v} % outWidth;

    let WRow = ${x} / (i32(uniforms.w_shape[1]) * inChannels);
    let WCol = ${x} / inChannels % i32(uniforms.w_shape[1]);
    let xRow = outRow * uniforms.stride[0] + uniforms.dilation[0] * WRow - uniforms.pad[0];
    let xCol = outCol * uniforms.stride[1] + uniforms.dilation[1] * WCol - uniforms.pad[1];
    let xCh = ${x} % inChannels;
    var resData = ${Me(s,p)}(0.0);
    // The bounds checking is always needed since we use it to pad zero for
    // the 'same' padding type.
    if (xRow >= 0 && xRow < ${f} && xCol >= 0 && xCol < ${y}) {
      ${m}
      let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
      ${h(s)}
    }
    return resData;`,S=e?t&&i?`
    let col = colIn * ${s};
    ${_}`:`
    let col = colIn * ${s};
    if (row < uniforms.dim_a_outer && col < uniforms.dim_inner) {
      ${_}
    }
    return ${Me(s,p)}(0.0);`:i&&r?`
    let col = colIn * ${s};
    ${_}`:`
    let col = colIn * ${s};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${_}
    }
    return ${Me(s,p)}(0.0);`,k=`${u(d)}`,T=Me(l,p),I=Me(e?s:d,p),C=Me(e?d:s,p),M=bt(n,T,p);return`
    fn mm_readA(batch: i32, row : i32, colIn : i32) -> ${I} {
      ${e?S:k}
    }

    fn mm_readB(batch: i32, row : i32, colIn : i32) -> ${C} {
      ${e?k:S}
    }

    fn mm_write(batch: i32, row : i32, colIn : i32, valueIn : ${T}) {
      let col = colIn * ${l};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer)
      {
      var value = valueIn;
      let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
      ${$}
      ${Za(a)}
      ${M}
      setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
      }
    }`},rc=(e,t,r,i,a,n,s,d,l)=>{let p=t.format==="NHWC",h=p?e[0].dims[3]:e[0].dims[1],u=r[0],m=p?r[2]:r[3],$=p?r[1]:r[2],f=p?r[3]:r[1],y=p&&(h%4===0||h%3===0)&&f%4===0,v=p?f:m*$,x=p?m*$:f,_=[8,8,1],S=i<=8?[4,1,1]:[4,4,1],k=[Math.ceil(v/_[0]/S[0]),Math.ceil(x/_[1]/S[1]),Math.ceil(u/_[2]/S[2])];ye("verbose",()=>`[conv2d_mm_webgpu] dispatch = ${k}`);let T=y?p&&h%4!==0?3:4:1,I=_[1]*S[1],C=_[0]*S[0],M=Math.max(_[0]*T,_[1]),N=i%I===0,W=a%C===0,J=n%M===0,K=y?[T,4,4]:[1,1,1],X=[{type:6,data:i},{type:6,data:a},{type:6,data:n},{type:6,data:[t.pads[0],t.pads[1]]},{type:6,data:t.strides},{type:6,data:t.dilations}];vt(t,X),X.push(...G(e[0].dims,e[1].dims));let ie=["rank","rank"];s&&(X.push(...G(e[2].dims)),ie.push("rank")),X.push(...G(r));let ue=q=>{let de=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"},{name:"pad",type:"i32",length:2},{name:"stride",type:"i32",length:2},{name:"dilation",type:"i32",length:2}];xt(t,de);let se=y?4:1,j=Ee(e[0].dataType),re=`
      fn setOutputAtIndex(flatIndex : i32, value : ${y?`vec4<${j}>`:j}) {
        result[flatIndex] = ${y?`vec4<${j}>`:j}(value);
      }
      fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : ${y?`vec4<${j}>`:j}) {
        let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
        setOutputAtIndex(flatIndex ${y?"/ 4":""}, value);
      }`,O=P("x",e[0].dataType,e[0].dims.length,T===3?1:T),U=P("w",e[1].dataType,e[1].dims.length,se),te=[O,U],fe=Y("result",e[0].dataType,r.length,se);if(s){let be=P("bias",e[2].dataType,e[2].dims.length,se);te.push(be),re+=`
        fn getBiasByOutputCoords(coords : vec4<i32>) -> ${y?`vec4<${j}>`:j} {
          return bias[coords.${p?"w":"y"}${y?"/ 4":""}];
        }`}return`
        ${Qa("uniforms.result_strides")}
        //struct Uniforms { xShape : vec4<i32>, wShape : vec4<i32>, outShape : vec4<i32>,
        //  outShapeStrides: vec3<i32>, filterDims : vec2<i32>, pad : vec2<i32>, stride : vec2<i32>,
        //  dilation : vec2<i32>, dimAOuter : i32, dimBOuter : i32, dimInner : i32 };
        ${q.registerUniforms(de).declareVariables(...te,fe)}
        ${re}
        ${eu(p,N,W,J,s,t,K[0],K[1],K[2],j)}
        ${y?Kr(S,_,j,void 0,!p,M):Yr(S,_,j,void 0,!p,M,!1,void 0,d)}`};return{name:"Conv2DMatMul",shaderCache:{hint:`${t.cacheKey};${T};${y};${N};${W};${J};${I};${C};${M}`,inputDependencies:ie},getRunData:()=>({outputs:[{dims:l?l(r):r,dataType:e[0].dataType}],dispatchGroup:{x:k[0],y:k[1],z:k[2]},programUniforms:X}),getShaderSource:ue}}}),tu,Li,Xt,ru,qi,iu,ic,ac,Bm=F(()=>{"use strict";ee(),ut(),ae(),ne(),kt(),Jr(),tu=e=>{let t=1;for(let r=0;r<e.length;r++)t*=e[r];return t},Li=e=>typeof e=="number"?[e,e,e]:e,Xt=(e,t)=>t<=1?e:e+(e-1)*(t-1),ru=(e,t,r,i=1)=>{let a=Xt(t,i);return Math.floor((e[0]*(r-1)-r+a)/2)},qi=(e,t,r,i,a)=>{a==null&&(a=ru(e,t[0],i[0]));let n=[0,0,0,r];for(let s=0;s<3;s++)e[s]+2*a>=t[s]&&(n[s]=Math.trunc((e[s]-t[s]+2*a)/i[s]+1));return n},iu=(e,t,r,i,a,n,s,d,l,p)=>{let h,u,m,$;if(e==="VALID"&&(e=0),typeof e=="number"){h={top:e,bottom:e,left:e,right:e,front:e,back:e};let f=qi([t,r,i,1],[d,l,p],1,[a,n,s],e);u=f[0],m=f[1],$=f[2]}else if(Array.isArray(e)){if(!e.every((y,v,x)=>y===x[0]))throw Error(`Unsupported padding parameter: ${e}`);h={top:e[0],bottom:e[1],left:e[2],right:e[3],front:e[4],back:e[5]};let f=qi([t,r,i,1],[d,l,p],1,[a,n,s],e[0]);u=f[0],m=f[1],$=f[2]}else if(e==="SAME_UPPER"){u=Math.ceil(t/a),m=Math.ceil(r/n),$=Math.ceil(i/s);let f=(u-1)*a+d-t,y=(m-1)*n+l-r,v=($-1)*s+p-i,x=Math.floor(f/2),_=f-x,S=Math.floor(y/2),k=y-S,T=Math.floor(v/2),I=v-T;h={top:S,bottom:k,left:T,right:I,front:x,back:_}}else throw Error(`Unknown padding parameter: ${e}`);return{padInfo:h,outDepth:u,outHeight:m,outWidth:$}},ic=(e,t,r,i,a,n=!1,s="channelsLast")=>{let d,l,p,h,u;if(s==="channelsLast")[d,l,p,h,u]=e;else if(s==="channelsFirst")[d,u,l,p,h]=e;else throw new Error(`Unknown dataFormat ${s}`);let[m,,$,f,y]=t,[v,x,_]=Li(r),[S,k,T]=Li(i),I=Xt($,S),C=Xt(f,k),M=Xt(y,T),{padInfo:N,outDepth:W,outHeight:J,outWidth:K}=iu(a,l,p,h,v,x,_,I,C,M),X=n?m*u:m,ie=[0,0,0,0,0];return s==="channelsFirst"?ie=[d,X,W,J,K]:s==="channelsLast"&&(ie=[d,W,J,K,X]),{batchSize:d,dataFormat:s,inDepth:l,inHeight:p,inWidth:h,inChannels:u,outDepth:W,outHeight:J,outWidth:K,outChannels:X,padInfo:N,strideDepth:v,strideHeight:x,strideWidth:_,filterDepth:$,filterHeight:f,filterWidth:y,effectiveFilterDepth:I,effectiveFilterHeight:C,effectiveFilterWidth:M,dilationDepth:S,dilationHeight:k,dilationWidth:T,inShape:e,outShape:ie,filterShape:t}},ac=(e,t,r,i,a,n)=>{let s=n==="channelsLast",d=s?e[0].dims[3]:e[0].dims[1],l=!1,p=[64,1,1],h={x:r.map((_,S)=>S)},u=[Math.ceil(tu(h.x.map(_=>r[_]))/p[0]),1,1];ye("verbose",()=>`[conv3d_naive_webgpu] dispatch = ${u}`);let m=l?s&&d%4!==0?3:4:1,$=R.size(r),f=[{type:12,data:$},{type:12,data:i},{type:12,data:a},{type:12,data:t.strides},{type:12,data:t.dilations}];vt(t,f),f.push(...G(e[0].dims,e[1].dims));let y=["rank","rank"],v=e.length===3;v&&(f.push(...G(e[2].dims)),y.push("rank")),f.push(...G(r));let x=_=>{let S=[{name:"output_size",type:"u32"},{name:"filter_dims",type:"u32",length:i.length},{name:"pads",type:"u32",length:a.length},{name:"strides",type:"u32",length:t.strides.length},{name:"dilations",type:"u32",length:t.dilations.length}];xt(t,S);let k=l?4:1,T=Ee(e[0].dataType),I=P("x",e[0].dataType,e[0].dims.length,m===3?1:m),C=P("W",e[1].dataType,e[1].dims.length,k),M=[I,C],N=Y("result",e[0].dataType,r.length,k),W="";if(v){let X=P("bias",e[2].dataType,e[2].dims.length,k);M.push(X),W+=`
        fn getBiasByOutputCoords(coords : array<u32, 5>) -> ${l?`vec4<${T}>`:T} {
          return bias[${s?H("coords",4,5):H("coords",1,5)}${l?"/ 4":""}];
        }`}let J=Me(m,T),K=bt(t,J,T);return`
            ${W}
            fn getX(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> f32 {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${I.getByIndices("aIndices")};
            }
            fn getW(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> f32 {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${C.getByIndices("aIndices")};
            }
          ${_.registerUniforms(S).declareVariables(...M,N)}
          ${_.mainStart()}
          ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
              let coords = ${N.offsetToIndices("global_idx")};
              let batch = ${H("coords",0,I.rank)};
              let d2 = ${s?H("coords",I.rank-1,I.rank):H("coords",1,I.rank)};
              let xFRCCorner = vec3<u32>(${s?H("coords",1,I.rank):H("coords",2,I.rank)},
              ${s?H("coords",2,I.rank):H("coords",3,I.rank)},
              ${s?H("coords",3,I.rank):H("coords",4,I.rank)}) * uniforms.strides - uniforms.pads;
              let xFCorner = xFRCCorner.x;
              let xRCorner = xFRCCorner.y;
              let xCCorner = xFRCCorner.z;
              let xShapeY = ${s?H("uniforms.x_shape",1,I.rank):H("uniforms.x_shape",2,I.rank)};
              let xShapeZ = ${s?H("uniforms.x_shape",2,I.rank):H("uniforms.x_shape",3,I.rank)};
              let xShapeW = ${s?H("uniforms.x_shape",3,I.rank):H("uniforms.x_shape",4,I.rank)};
              let xShapeU = ${s?H("uniforms.x_shape",4,I.rank):H("uniforms.x_shape",1,I.rank)};
              let inputDepthNearestVec4 = (xShapeU / 4) * 4;
              let inputDepthVec4Remainder = xShapeU % 4;

              var value = 0.0;
              for (var wF = 0u; wF < uniforms.filter_dims[0]; wF++) {
                let xF = xFCorner + wF * uniforms.dilations[0];
                if (xF < 0 || xF >= xShapeY) {
                  continue;
                }

                for (var wR = 0u; wR < uniforms.filter_dims[1]; wR++) {
                  let xR = xRCorner + wR * uniforms.dilations[1];
                  if (xR < 0 || xR >= xShapeZ) {
                    continue;
                  }

                  for (var wC = 0u; wC < uniforms.filter_dims[2]; wC++) {
                    let xC = xCCorner + wC * uniforms.dilations[2];
                    if (xC < 0 || xC >= xShapeW) {
                      continue;
                    }

                    for (var d1 = 0u; d1 < inputDepthNearestVec4; d1 += 4) {
                      ${s?`let xValues = vec4<f32>(
                               getX(batch, xF, xR, xC, d1),
                               getX(batch, xF, xR, xC, d1 + 1),
                               getX(batch, xF, xR, xC, d1 + 2),
                               getX(batch, xF, xR, xC, d1 + 3));
                            `:`let xValues = vec4<f32>(
                               getX(batch, d1, xF, xR, xC),
                               getX(batch, d1 + 1, xF, xR, xC),
                               getX(batch, d1 + 2, xF, xR, xC),
                               getX(batch, d1 + 3, xF, xR, xC));
                            `}
                            let wValues = vec4<f32>(
                              getW(d2, d1, wF, wR, wC),
                              getW(d2, d1 + 1, wF, wR, wC),
                              getW(d2, d1 + 2, wF, wR, wC),
                              getW(d2, d1 + 3, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                    if (inputDepthVec4Remainder == 1) {
                        ${s?`value += getX(batch, xF, xR, xC, inputDepthNearestVec4)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`:`value += getX(batch, inputDepthNearestVec4, xF, xR, xC)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`}
                    } else if (inputDepthVec4Remainder == 2) {
                      ${s?`let xValues = vec2<f32>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1));
                      `:`let xValues = vec2<f32>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC));
                    `}
                    let wValues = vec2<f32>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC));
                      value += dot(xValues, wValues);
                    } else if (inputDepthVec4Remainder == 3) {
                      ${s?`let xValues = vec3<f32>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 2));
                      `:`let xValues = vec3<f32>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 2, xF, xR, xC));
                    `}
                    let wValues = vec3<f32>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 2, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                  }
                }
              }
              ${v?"value = value + getBiasByOutputCoords(coords)":""};
              ${K}
              result[global_idx] = f32(value);
          }`};return{name:"Conv3DNaive",shaderCache:{hint:`${t.cacheKey};${s};${m};${v}`,inputDependencies:y},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:u[0],y:u[1],z:u[2]},programUniforms:f}),getShaderSource:x}}}),nc,sc,Mm=F(()=>{"use strict";ee(),ae(),ne(),kt(),nc=(e,t,r,i)=>{let a=e.length>2,n=a?"value += b[output_channel];":"",s=e[0].dims,d=e[1].dims,l=t.format==="NHWC",p=l?r[3]:r[1],h=p/t.group,u=l&&h>=4?Se(p):1,m=R.size(r)/u,$=[{type:12,data:m},{type:12,data:t.dilations},{type:12,data:[t.strides[0],t.strides[1]]},{type:12,data:[t.pads[0],t.pads[1]]},{type:12,data:h}];vt(t,$),$.push(...G(s,[d[0],d[1],d[2],d[3]/u]));let f=a?["rank","rank","rank"]:["rank","rank"];$.push(...G([r[0],r[1],r[2],r[3]/u]));let y=v=>{let x=Y("output",e[0].dataType,r.length,u),_=Ee(x.type.tensor),S=bt(t,x.type.value,_),k=P("x",e[0].dataType,s.length),T=P("w",e[1].dataType,d.length,u),I=[k,T];a&&I.push(P("b",e[2].dataType,e[2].dims,u));let C=[{name:"output_size",type:"u32"},{name:"dilations",type:"u32",length:t.dilations.length},{name:"strides",type:"u32",length:2},{name:"pads",type:"u32",length:2},{name:"output_channels_per_group",type:"u32"}];xt(t,C);let M=l?`
      for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[0]; wHeight++) {
        let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

        if (xHeight < 0u || xHeight >= uniforms.x_shape[1]) {
          continue;
        }

        for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[1]; wWidth++) {
          let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
          if (xWidth < 0u || xWidth >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[2]; wInChannel++) {
            let input_channel = in_channel_offset + wInChannel;
            let xVal = ${k.get("batch","xHeight","xWidth","input_channel")};
            let wVal = ${T.get("wHeight","wWidth","wInChannel","output_channel")};
            value += xVal * wVal;
          }
        }
      }
      `:`
      for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[1]; wInChannel++) {
        let input_channel = in_channel_offset + wInChannel;
        for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[2]; wHeight++) {
          let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

          if (xHeight < 0u || xHeight >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[3]; wWidth++) {
            let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
            if (xWidth < 0u || xWidth >= uniforms.x_shape[3]) {
              continue;
            }

            let xVal = ${k.get("batch","input_channel","xHeight","xWidth")};
            let wVal = ${T.get("output_channel","wInChannel","wHeight","wWidth")};
            value += xVal * wVal;
          }
        }
      }
      `;return`
  ${v.registerUniforms(C).declareVariables(...I,x)}

  ${v.mainStart()}
    ${v.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let outputIndices = ${x.offsetToIndices("global_idx")};
    let batch: u32 = outputIndices[0];
    let output_channel: u32 = outputIndices[${l?3:1}];
    let xRCCorner: vec2<u32> = vec2<u32>(outputIndices[${l?1:2}], outputIndices[${l?2:3}]) * uniforms.strides - uniforms.pads;
    let group_id: u32 = output_channel * ${u} / uniforms.output_channels_per_group;
    var in_channel_offset = group_id * uniforms.w_shape[${l?2:1}];

    var value: ${x.type.value} = ${x.type.value}(0);
    ${M}
    ${n}
    ${S}
    ${x.setByOffset("global_idx","value")}
  }`};return{name:"GroupedConv",shaderCache:{hint:`${t.cacheKey}_${u}`,inputDependencies:f},getRunData:()=>({outputs:[{dims:i?i(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(m/64)},programUniforms:$}),getShaderSource:y}},sc=(e,t,r,i)=>{let a=e.length>2,n=Se(r[3]),s=Se(r[2]),d=R.size(r)/n/s,l=[e[0].dims[0],e[0].dims[1],e[0].dims[2],e[0].dims[3]/n],p=[e[1].dims[0],e[1].dims[1],e[1].dims[2],e[1].dims[3]/n],h=[r[0],r[1],r[2],r[3]/n],u=[{type:12,data:d},{type:6,data:[t.strides[0],t.strides[1]]},{type:6,data:[t.pads[0],t.pads[1]]}];vt(t,u),u.push(...G(l,p,h));let m=(s-1)*t.strides[1]+p[1],$=f=>{let y=Y("output",e[0].dataType,h.length,n),v=Ee(y.type.tensor),x=bt(t,y.type.value,v),_=P("x",e[0].dataType,l.length,n),S=P("w",e[1].dataType,p.length,n),k=[_,S];a&&k.push(P("b",e[2].dataType,e[2].dims,n));let T=a?"value += b[output_channel];":"",I=[{name:"output_size",type:"u32"},{name:"strides",type:"i32",length:2},{name:"pads",type:"i32",length:2}];return xt(t,I),`
  ${f.registerUniforms(I).declareVariables(...k,y)}
  ${f.mainStart()}
    ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let width0 = uniforms.output_shape[3];
    let output_channel = global_idx % width0;
    var index1 = global_idx / width0;
    let width1 = uniforms.output_shape[2] / ${s}u;
    let col = (index1 % width1) * ${s}u;
    index1 = index1 / width1;
    let row = index1 % uniforms.output_shape[1];
    let batch = index1 / uniforms.output_shape[1];

    let x_corner = vec2<i32>(i32(row), i32(col)) * uniforms.strides - uniforms.pads;

    var x_vals: array<${_.type.value}, ${m}>;
    var values: array<${y.type.value}, ${s}>;
    let input_channel = output_channel;
    // Use constant instead of uniform can give better performance for w's height/width.
    for (var w_height: u32 = 0u; w_height < ${p[0]}; w_height++) {
      let x_height = x_corner.x + i32(w_height);
      if (x_height >= 0 && u32(x_height) < uniforms.x_shape[1]) {
        for (var i = 0; i < ${m}; i++) {
          let x_width = x_corner.y + i;
          if (x_width >= 0 && u32(x_width) < uniforms.x_shape[2]) {
            x_vals[i] = ${_.get("batch","u32(x_height)","u32(x_width)","input_channel")};
          } else {
            x_vals[i] = ${_.type.value}(0);
          }
        }
        for (var w_width: u32 = 0u; w_width < ${p[1]}; w_width++) {
          let w_val = ${S.get("w_height","w_width","0","output_channel")};
          for (var i = 0u; i < ${s}u; i++) {
            values[i] = fma(x_vals[i * u32(uniforms.strides[1]) + w_width], w_val, values[i]);
          }
        }
      }
    }

    for (var i = 0u; i < ${s}u; i++) {
      var value = values[i];
      ${T}
      ${x}
      ${y.set("batch","row","col + i","output_channel","value")};
    }
  }`};return{name:"GroupedConv-Vectorize",shaderCache:{hint:`${t.cacheKey};${n};${s};${m};${p[0]};${p[1]}`,inputDependencies:a?["rank","rank","type"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:i?i(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:u}),getShaderSource:$}}}),xa,au,oc,uc=F(()=>{"use strict";ee(),ae(),ei(),ne(),kt(),xa=(e,t,r,i,a=!1,n)=>{let s=e[0].dims,d=e[1].dims,l=s[s.length-2],p=d[d.length-1],h=s[s.length-1],u=Se(p),m=Se(h),$=Se(l),f=R.size(r)/u/$,y=e.length>2,v=i?i.slice(0,-2):r.slice(0,-2),x=[R.size(v),l,p],_=[{type:12,data:f},{type:12,data:l},{type:12,data:p},{type:12,data:h}];vt(t,_),_.push(...G(v,s,d)),y&&_.push(...G(e[2].dims)),_.push(...G(x));let S=k=>{let T=ja("batch_dims",e[0].dataType,v.length),I=P("a",e[0].dataType,s.length,m),C=P("b",e[1].dataType,d.length,u),M=Y("output",e[0].dataType,x.length,u),N=Ee(M.type.tensor),W=bt(t,M.type.value,N),J=[I,C],K="";if(y){let re=a?u:1;J.push(P("bias",e[2].dataType,e[2].dims.length,re)),K=`${a?`value += bias[col / ${re}];`:`value += ${M.type.value}(bias[row + i]);`}`}let X=s.slice(0,-2),ie=d.slice(0,-2),ue=lr(X,v),q=lr(ie,v),de=[{name:"output_size",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"}];xt(t,de);let se=(re,O)=>{let U=re.rank,te=re.name;if(U===2)return`var ${te}_indices = ${re.type.indices}(0u, 0u);`;let fe=T.rank,be=`var ${te}_indices: ${re.type.indices};`;for(let ke=U-2-1,De=fe-1;ke>=0;ke--,De--)be+=`
${te}_indices[${ke}] = ${fe>1?`batch_indices[${De}]`:"batch_indices"};`;return O.forEach(ke=>{be+=`
${te}_indices[${ke}] = 0;`}),be+=`${te}_indices[${U-2}] = 0u;
                     ${te}_indices[${U-1}] = 0u;`,be},j=()=>{let re=`var a_data: ${I.type.value};`;for(let O=0;O<m;O++)re+=`
              let b_data${O} = b[(b_offset + (k + ${O}) * uniforms.N + col) / ${u}];`;for(let O=0;O<$;O++){re+=`a_data = a[(a_offset + (row + ${O}) * uniforms.K + k) / ${m}];`;for(let U=0;U<m;U++)re+=`
            values[${O}] = fma(${C.type.value}(a_data${m===1?"":`[${U}]`}), b_data${U}, values[${O}]);
`}return re};return`
  ${k.registerUniforms(de).registerInternalVariables(T).declareVariables(...J,M)}
  ${k.mainStart()}
    ${k.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let col = (global_idx % (uniforms.N / ${u})) * ${u};
    var index1 = global_idx / (uniforms.N / ${u});
    let stride1 = uniforms.M / ${$};
    let row = (index1 % stride1) * ${$};
    let batch = index1 / stride1;

    ${r.length===2?"":`let batch_indices = ${T.offsetToIndices("batch")};`}
    ${se(I,ue)}
    let a_offset = ${I.indicesToOffset("a_indices")};
    ${se(C,q)}
    let b_offset = ${C.indicesToOffset("b_indices")};
    var values: array<${M.type.value}, ${$}>;
    for (var k: u32 = 0u; k < uniforms.K; k = k + ${m}) {
      ${j()}
    }
    for (var i = 0u; i < ${$}u; i++) {
      var value = values[i];
      ${K}
      ${W}
      let cur_indices = ${M.type.indices}(batch, row + i, col);
      let offset = ${M.indicesToOffset("cur_indices")};
      ${M.setByOffset(`offset / ${u}`,"value")};
    }
  }
  `};return{name:"MatMulNaive",shaderCache:{hint:`${t.activation};${u};${m};${$};${a}`,inputDependencies:y?["rank","rank","rank"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:n?n(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(f/64)},programUniforms:_}),getShaderSource:S}},au=e=>{if(!e||e.length!==2)throw new Error("MatMul requires 2 inputs.");if(e[0].dims[e[0].dims.length-1]!==e[1].dims[e[1].dims.length-2])throw new Error("shared dimension does not match.")},oc=e=>{au(e.inputs);let t=Gt.calcShape(e.inputs[0].dims,e.inputs[1].dims,!0);if(!t)throw new Error("Can't use matmul on the given tensors");let r=t[t.length-1],i=e.inputs[0].dims[e.inputs[0].dims.length-1];r<8&&i<8?e.compute(xa(e.inputs,{activation:""},t)):e.compute(Xa(e.inputs,{activation:""},t))}}),nu,Br,su,Mr,Sa,Vi,ou,uu,ka,Pm=F(()=>{"use strict";ae(),Om(),Bm(),ei(),Mm(),kt(),uc(),St(),nu=(e,t,r,i,a,n)=>{let s=e[0],d=e.slice(n?1:2,n?3:4),l=d.length,p=t[0],h=t.slice(2).map((m,$)=>m+(m-1)*(r[$]-1)),u=d.map((m,$)=>m+i[$]+i[$+l]).map((m,$)=>Math.floor((m-h[$]+a[$])/a[$]));return u.splice(0,0,s),u.splice(n?3:1,0,p),u},Br=[2,3,1,0],su=(e,t)=>{if(!e||e.length!==2&&e.length!==3)throw new Error("Conv requires 2 or 3 inputs");if(e[0].dims.length>5)throw new Error("greater than 5D is not supported");if(e[0].dims.length!==e[1].dims.length)throw new Error("filter does not have same dimension as input");let r=e[0].dims[t.format==="NHWC"?e[0].dims.length-1:1],i=e[1].dims[1]*t.group;if(r!==i)throw new Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");if(e.length===3&&(e[2].dims.length!==1||e[1].dims[0]!==e[2].dims[0]))throw new Error("invalid bias");let a=e[0].dims.length-2;if(t.dilations.length!==a)throw new Error(`dilations should be ${a}D`);if(t.strides.length!==a)throw new Error(`strides should be ${a}D`);if(t.pads.length!==a*2)throw new Error(`pads should be ${a*2}D`);if(t.kernelShape.length!==0&&t.kernelShape.length!==e[1].dims.length-2)throw new Error("invalid kernel shape")},Mr=(e,t)=>{let r=e.kernelShape.slice();r.length<t[1].dims.length-2&&r.push(...Array(t[1].dims.length-2-r.length).fill(0));for(let n=2;n<t[1].dims.length;++n)r[n-2]===0&&(r[n-2]=t[1].dims[n]);let i=e.pads.slice();Gr.adjustPadsBasedOnAutoPad(t[0].dims,e.strides,e.dilations,r,i,e.format==="NHWC",e.autoPad);let a=Object.assign({},e);return Object.assign(a,{kernelShape:r,pads:i}),a},Sa=e=>{let t=Ya(e),r=e.format,i=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],a=e.dilations,n=e.group,s=e.kernel_shape,d=e.pads,l=e.strides,p=e.w_is_const();return{autoPad:i,format:r,dilations:a,group:n,kernelShape:s,pads:d,strides:l,wIsConst:p,...t,cacheKey:`${e.format};${t.activation};`}},Vi=(e,t,r,i)=>{let a=r.format==="NHWC",n=nu(t[0].dims,t[1].dims,r.dilations,r.pads,r.strides,a);if(r.group!==1){let I=[t[0]];if(a){let C=e.kernelCustomData.wT??e.compute(Le(t[1],Br),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=C),I.push(C)}else I.push(t[1]);t.length===3&&I.push(t[2]),!e.adapterInfo.isArchitecture("ampere")&&a&&t[1].dims[0]===r.group&&t[1].dims[1]===1&&r.dilations[0]===1&&r.dilations[1]===1?e.compute(sc(I,r,n,i),{inputs:I}):e.compute(nc(I,r,n,i),{inputs:I});return}let s=t.length===3,d=t[0].dims[a?1:2],l=t[0].dims[a?2:3],p=t[0].dims[a?3:1],h=t[1].dims[2],u=t[1].dims[3],m=n[a?1:2],$=n[a?2:3],f=n[a?3:1],y=a&&h===d&&u===l&&r.pads[0]===0&&r.pads[1]===0;if(y||h===1&&u===1&&r.dilations[0]===1&&r.dilations[1]===1&&r.strides[0]===1&&r.strides[1]===1&&r.pads[0]===0&&r.pads[1]===0){let I=n[0],C,M,N,W=[];if(a){let X=e.kernelCustomData.wT??e.compute(Le(t[1],Br),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];if(r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=X),y){let ie=d*l*p;C=t[0].reshape([1,I,ie]),M=X.reshape([1,ie,f]),N=[1,I,f]}else C=t[0].reshape([I,d*l,p]),M=X.reshape([1,p,f]),N=[I,m*$,f];W.push(C),W.push(M)}else C=t[0].reshape([I,p,d*l]),M=t[1].reshape([1,f,p]),N=[I,f,m*$],W.push(M),W.push(C);s&&W.push(t[2]);let J=N[2],K=W[0].dims[W[0].dims.length-1];J<8&&K<8?e.compute(xa(W,r,n,N,a,i),{inputs:W}):e.compute(Xa(W,r,n,N,a,i),{inputs:W});return}let v=!0,x=e.kernelCustomData.wT??e.compute(Le(t[1],Br),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=x);let _=[t[0],x];s&&_.push(t[2]);let S=a?m*$:f,k=a?f:m*$,T=h*u*p;e.compute(rc(_,r,n,S,k,T,s,v,i),{inputs:_})},ou=(e,t)=>{let r=t.format==="NHWC",i=[e.inputs[0].reshape(r?[e.inputs[0].dims[0],1,e.inputs[0].dims[1],e.inputs[0].dims[2]]:[e.inputs[0].dims[0],e.inputs[0].dims[1],1,e.inputs[0].dims[2]]),e.inputs[1].reshape([e.inputs[1].dims[0],e.inputs[1].dims[1],1,e.inputs[1].dims[2]])];e.inputs.length===3&&i.push(e.inputs[2]);let a=[0,t.pads[0],0,t.pads[1]],n=[1].concat(t.strides),s=[1].concat(t.dilations),d=[1].concat(t.kernelShape),l=Mr({...t,pads:a,strides:n,dilations:s,kernelShape:d},i);Vi(e,i,l,p=>r?[p[0],p[2],p[3]]:[p[0],p[1],p[3]])},uu=(e,t,r)=>{let i=r.format==="NHWC"?"channelsLast":"channelsFirst",a=Mr(r,t),n=r.autoPad==="NOTSET"?r.pads:r.autoPad,s=ic(t[0].dims,t[1].dims,r.strides,r.dilations,n,!1,i);e.compute(ac(t,a,s.outShape,[s.filterDepth,s.filterHeight,s.filterWidth],[s.padInfo.front,s.padInfo.top,s.padInfo.left],i))},ka=(e,t)=>{if(su(e.inputs,t),e.inputs[0].dims.length===3)ou(e,t);else if(e.inputs[0].dims.length===5)uu(e,e.inputs,t);else{let r=Mr(t,e.inputs);Vi(e,e.inputs,r)}}}),lu,lc,Dm=F(()=>{"use strict";ee(),ut(),ne(),kt(),Jr(),tc(),ei(),lu=(e,t=!1,r,i,a=4)=>{let n=v=>{switch(v){case 1:return"return w[getIndexFromCoords4D(coord, vec4<i32>(uniforms.w_shape))];";case 4:return`
            let coord1 = vec4<i32>(coordX, coordY, col + 1, rowInner);
            let coord2 = vec4<i32>(coordX, coordY, col + 2, rowInner);
            let coord3 = vec4<i32>(coordX, coordY, col + 3, rowInner);
            let v0 = w[getIndexFromCoords4D(coord, vec4<i32>(uniforms.w_shape))];
            let v1 = w[getIndexFromCoords4D(coord1, vec4<i32>(uniforms.w_shape))];
            let v2 = w[getIndexFromCoords4D(coord2, vec4<i32>(uniforms.w_shape))];
            let v3 = w[getIndexFromCoords4D(coord3, vec4<i32>(uniforms.w_shape))];
            return ${i}(v0, v1, v2, v3);
            `;default:throw new Error(`innerElementSize ${v} is not supported.`)}},s=e?`
      let coord = vec4<i32>(batch, iXR, iXC, xCh);
      `:`
      let coord = vec4<i32>(batch, xCh, iXR, iXC);
      `,d=e?`
    let coords = vec4<i32>(
      batch,
      row / outWidth,
      row % outWidth,
      col);
    `:`
    let coords = vec4<i32>(
      batch,
      row,
      col / outWidth,
      col % outWidth);
    `,l=e?"i32(uniforms.x_shape[1])":"i32(uniforms.x_shape[2])",p=e?"i32(uniforms.x_shape[2])":"i32(uniforms.x_shape[3])",h=e?"row":"col",u=e?"col":"row",m=`
      let inChannels = ${e?"i32(uniforms.x_shape[3])":"i32(uniforms.x_shape[1])"};
      let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
      let outRow = ${h} / outWidth;
      let outCol = ${h} % outWidth;

      let WRow = ${u} / (uniforms.filter_dims[1] * inChannels);
      let WCol = ${u} / inChannels % uniforms.filter_dims[1];
      let xR = f32(outRow - uniforms.pads[0] + uniforms.dilations[0] * WRow) / f32(uniforms.strides[0]);
      let xC = f32(outCol - uniforms.pads[1] + uniforms.dilations[1] * WCol) / f32(uniforms.strides[1]);
      if (xR < 0.0 || xR >= f32(${l}) || fract(xR) > 0.0) {
        return ${i}(0.0);
      }
      if (xC < 0.0 || xC >= f32(${p}) || fract(xC) > 0.0) {
        return ${i}(0.0);
      }
      let iXR = i32(xR);
      let iXC = i32(xC);
      let xCh = ${u} % inChannels;
      ${s}
      return x[getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape))/${a}];`,$=e?`
      let col = colIn * ${a};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_inner) {
        ${m}
      }
      return ${i}(0.0);`:`
      let col = colIn * ${a};
      if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
        ${m}
      }
      return ${i}(0.0);`,f=`
      let col = colIn * ${a};
      let inChannels = ${e?"i32(uniforms.x_shape[3])":"i32(uniforms.x_shape[1])"};
      let coordX = uniforms.filter_dims[0] - 1 - row / (uniforms.filter_dims[1] * inChannels);
      let coordY = uniforms.filter_dims[1] - 1 - (row / inChannels) % uniforms.filter_dims[1];
      if (${e?"row < uniforms.dim_inner && col < uniforms.dim_b_outer":"row < uniforms.dim_inner && col < uniforms.dim_a_outer"}  && coordX >= 0 && coordY >= 0) {
        let rowInner = row % inChannels;
        let coord = vec4<i32>(coordX, coordY, col, rowInner);
        ${n(a)}
      }
      return ${i}(0.0);
      `,y=bt(r,i);return`
  fn mm_readA(batch: i32, row : i32, colIn : i32) -> ${i} {
    ${e?$:f}
  }

  fn mm_readB(batch: i32, row : i32, colIn : i32) -> ${i} {
    ${e?f:$}
  }

  fn mm_write(batch: i32, row : i32, colIn : i32, valueInput : ${i}) {
    let col = colIn * ${a};
    if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer) {
      var value = valueInput;
      let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
      ${d}
      ${Za(t)}
      ${y}
      result[getIndexFromCoords4D(coords, vec4<i32>(uniforms.result_shape))/${a}] = value;
    }
  }`},lc=(e,t,r,i,a,n,s,d)=>{let l=t.format==="NHWC",p=l?e[0].dims[3]:e[0].dims[1],h=r[0],u=l?r[2]:r[3],m=l?r[1]:r[2],$=l?r[3]:r[1],f=l&&p%4===0&&p%3&&$%4===0,y=l?$:u*m,v=l?u*m:$,x=[8,8,1],_=i<=8?[4,1,1]:[4,4,1],S=[Math.ceil(y/x[0]/_[0]),Math.ceil(v/x[1]/_[1]),Math.ceil(h/x[2]/_[2])];ye("verbose",()=>`[conv_backprop_mm_webgpu] dispatch = ${S}`);let k=f?4:1,T=Math.max(x[0]*k,x[1]),I=f?4:1,C=[t.kernelShape[l?1:2],t.kernelShape[l?2:3]],M=[C[0]+(t.dilations[0]<=1?0:(C[0]-1)*(t.dilations[0]-1)),C[1]+(t.dilations[1]<=1?0:(C[1]-1)*(t.dilations[1]-1))],N=[M[0]-1-Math.floor((t.pads[0]+t.pads[2])/2),M[1]-1-Math.floor((t.pads[1]+t.pads[3])/2)],W=[{type:6,data:i},{type:6,data:a},{type:6,data:n},{type:6,data:t.strides},{type:6,data:t.dilations},{type:6,data:C},{type:6,data:N}];vt(t,W),W.push(...G(e[0].dims,e[1].dims));let J=["rank","rank"];s&&(W.push(...G(e[2].dims)),J.push("rank")),W.push(...G(r));let K=X=>{let ie=P("x",e[0].dataType,e[0].dims.length,I),ue=P("w",e[1].dataType,e[1].dims.length,1),q=Y("result",e[0].dataType,r.length,I),de=[ie,ue],se="";if(s){let O=P("bias",e[2].dataType,e[2].dims.length,I);de.push(O),se+=`
          fn getBiasByOutputCoords(coords : vec4<i32>) -> ${O.type.value} {
            return bias[coords.${l?"w":"y"}${f?"/ 4":""}];
          }`}let j=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"},{name:"strides",type:"i32",length:2},{name:"dilations",type:"i32",length:2},{name:"filter_dims",type:"i32",length:C.length},{name:"pads",type:"i32",length:N.length}];xt(t,j);let re=Ee(e[0].dataType,1);if(re!=="f16"&&re!=="f32")throw new Error(`elemType ${re} is not supported.`);return`
        ${Qa("uniforms.result_strides")}
        ${X.registerUniforms(j).declareVariables(...de,q)};
        ${se}
        ${lu(l,s,t,ie.type.value,k)}
        ${f?Kr(_,x,re,void 0,!l,T):Yr(_,x,re,void 0,!l,T,!1,void 0,d)}`};return{name:"Conv2DTransposeMatMul",shaderCache:{hint:`${t.cacheKey};${_};${x};${f}`,inputDependencies:J},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:S[0],y:S[1],z:S[2]},programUniforms:W}),getShaderSource:K}}}),du,Ta,Fm=F(()=>{"use strict";ee(),ut(),ae(),ne(),du=(e,t,r,i,a,n=!1,s,d,l=!1)=>{let p=l?1:2,h=l?2:3,u=l?3:1,m=n?2:1,$=`
  fn setOutputAtIndex(flatIndex : u32, value : ${n?`vec4<${s}>`:s}) {
    result[flatIndex] = ${n?`vec4<${s}>`:s}(value);
  }`;i&&($+=`
    fn getBiasByOutputCoords(coords : vec4<u32>) -> ${n?`vec4<${s}>`:s} {
      return bias[coords.${l?"w":"y"}${n?"/ 4":""}];
    }`);let f=n?4:1,y=P("W",t[1].dataType,t[1].dims.length,f),v=P("Dy",t[0].dataType,t[0].dims.length,f),x=[v,y];i&&x.push(P("bias",t[2].dataType,[r[u]].length,f));let _=Y("result",t[0].dataType,r.length,f),S=`{
        let batch: u32 = ${a?"global_id.z":"workgroup_id.z"} / uniforms.result_shape[1];
        let r = ${a?"global_id.z":"workgroup_id.z"} % uniforms.result_shape[1];
        let c = ${a?"global_id.y":"workgroup_id.y"} * ${m};
        let d1: u32 = ${a?"global_id.x":"workgroup_id.x"} * 4;

        let dyCorner = vec2<i32>(i32(r), i32(c)) - vec2<i32>(uniforms.pads);

        // Convolve dy(?, ?, d2) with w(:, :, d1, d2) to compute dx(xR, xC, d1).
        // ? = to be determined. : = across all values in that axis.
        var dotProd: array<vec4<${s}>, ${m}>;
        for (var i = 0; i < ${m}; i++) {
          dotProd[i] = vec4<${s}>(0.0);
        }
        for (var wR: u32 = 0; wR < uniforms.filter_dims[0]; wR = wR + 1) {
          var dyR = (${s}(dyCorner.x) + ${s}(wR)) / ${s}(uniforms.strides.x);
          let wRPerm = uniforms.filter_dims[0] - 1 - wR;
          if (dyR < 0.0 || dyR >= ${s}(uniforms.Dy_shape[1]) ||
              fract(dyR) > 0.0 || wRPerm < 0) {
            continue;
          }
          let idyR: u32 = u32(dyR);

          for (var wC: u32 = 0; wC < uniforms.filter_dims[1]; wC = wC + 1) {
            let dyC = (${s}(dyCorner.y) + ${s}(wC)) / ${s}(uniforms.strides.y);
            let dyC2 = (${s}(dyCorner.y) + 1.0 + ${s}(wC)) / ${s}(uniforms.strides.y);
            let wCPerm = uniforms.filter_dims[1] - 1 - wC;
            if (wCPerm < 0) {
              continue;
            }
            var bDyCVal = true;
            var bDyCVal2 = true;
            if (dyC < 0.0 || dyC >= ${s}(uniforms.Dy_shape[2]) ||
                fract(dyC) > 0.0) {
              bDyCVal = false;
            }
            if (dyC2 < 0.0 || dyC2 >= ${s}(uniforms.Dy_shape[2]) ||
                fract(dyC2) > 0.0) {
              bDyCVal2 = false;
            }

            let idyC: u32 = u32(dyC);
            let idyC2: u32 = u32(dyC2);
            if (bDyCVal && bDyCVal2) {
              let d2Length = uniforms.Dy_shape[3];
              for (var d2 :u32 = 0; d2 < d2Length; d2 = d2 + 4) {
                let wValue0 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1","d2")};
                let wValue1 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1 + 1","d2")};
                let wValue2 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1 + 2","d2")};
                let wValue3 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1 + 3","d2")};

                var xValue = ${v.get("batch","idyR","idyC","d2")};
                let tmpval = vec4<${s}>(dot(xValue, wValue0),
                                      dot(xValue, wValue1),
                                      dot(xValue, wValue2),
                                      dot(xValue, wValue3));
                dotProd[0] = dotProd[0] + tmpval;

                xValue =  ${v.get("batch","idyR","idyC2","d2")};

                dotProd[1] = dotProd[1] + vec4<${s}>(dot(xValue, wValue0),
                                                    dot(xValue, wValue1),
                                                    dot(xValue, wValue2),
                                                    dot(xValue, wValue3));
              }
            } else if (bDyCVal) {
              let d2Length = uniforms.Dy_shape[${u}];
              for (var d2: u32 = 0; d2 < d2Length; d2 = d2 + 4) {
                let wValue0 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1","d2")};
                let wValue1 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1 + 1","d2")};
                let wValue2 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1 + 2","d2")};
                let wValue3 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1 + 3","d2")};

                var xValue = ${v.get("batch","idyR","idyC","d2")};
                let tmpval = vec4<${s}>(dot(xValue, wValue0),
                                      dot(xValue, wValue1),
                                      dot(xValue, wValue2),
                                      dot(xValue, wValue3));
                dotProd[0] = dotProd[0] + tmpval;
              }
            } else if (bDyCVal2) {
              let d2Length = uniforms.Dy_shape[3];
              for (var d2: u32 = 0; d2 < d2Length; d2 = d2 + 4) {
                let wValue0 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1","d2")};
                let wValue1 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1 + 1","d2")};
                let wValue2 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1 + 2","d2")};
                let wValue3 = ${y.get("u32(wRPerm)","u32(wCPerm)","d1 + 3","d2")};

                var xValue = ${v.get("batch","idyR","idyC2","d2")};
                let tmpval = vec4<${s}>(dot(xValue, wValue0),
                                      dot(xValue, wValue1),
                                      dot(xValue, wValue2),
                                      dot(xValue, wValue3));
                dotProd[1] = dotProd[1] + tmpval;
              }
            }
          }
        }

        for (var i: u32 = 0; i < ${m}; i = i + 1) {
          let value = dotProd[i] + ${i?"bias[c+i]":`vec4<${s}>(0.0)`};
          ${_.set("batch","r","c + i","d1","value")};
        }
      }`,k=`
          let outputIndices = ${_.offsetToIndices("global_idx")};
          let batch = ${_.indicesGet("outputIndices",0)};
          let d1 = ${_.indicesGet("outputIndices",u)};
          let r = ${_.indicesGet("outputIndices",p)};
          let c = ${_.indicesGet("outputIndices",h)};
          let dyCorner = vec2<i32>(i32(r), i32(c)) - uniforms.pads;
          let dyRCorner = dyCorner.x;
          let dyCCorner = dyCorner.y;
          let groupId = d1 / uniforms.output_channels_per_group;
          let wOutChannel = d1 - groupId * uniforms.output_channels_per_group;
          // Convolve dy(?, ?, d2) with w(:, :, d1, d2) to compute dx(xR, xC, d1).
          // ? = to be determined. : = across all values in that axis.
          var dotProd = ${s}(0.0);
          for (var wR: u32 = 0; wR < uniforms.effective_filter_dims.x; wR = wR + 1) {
            if (wR % uniforms.dilations.x != 0) {
              continue;
            }
            let dyR = (${s}(dyRCorner) + ${s}(wR)) / ${s}(uniforms.strides[0]);
            let wRPerm = uniforms.filter_dims.x - 1 - wR / uniforms.dilations.x;
            if (dyR < 0.0 || dyR >= ${s}(uniforms.Dy_shape[${p}]) || fract(dyR) > 0.0 ||
                wRPerm < 0) {
              continue;
            }
            let idyR: u32 = u32(dyR);

            for (var wC: u32 = 0; wC < uniforms.effective_filter_dims.y; wC = wC + 1) {
              if (wC % uniforms.dilations.y != 0) {
                continue;
              }
              let dyC = (${s}(dyCCorner) + ${s}(wC)) / ${s}(uniforms.strides.y);
              let wCPerm = uniforms.filter_dims.y - 1 - wC / uniforms.dilations.y;
              if (dyC < 0.0 || dyC >= ${s}(uniforms.Dy_shape[${h}]) ||
                  fract(dyC) > 0.0 || wCPerm < 0) {
                continue;
              }
              let idyC: u32 = u32(dyC);
              var inputChannel = groupId * uniforms.input_channels_per_group;
              for (var d2: u32 = 0; d2 < uniforms.input_channels_per_group; d2 = d2 + 1) {
                let xValue = ${l?v.get("batch","idyR","idyC","inputChannel"):v.get("batch","inputChannel","idyR","idyC")};
                let wValue = ${y.get("inputChannel","wOutChannel","u32(wRPerm)","u32(wCPerm)")};
                dotProd = dotProd + xValue * wValue;
                inputChannel = inputChannel + 1;
              }
            }
          }
          let value = dotProd + ${i?"bias[d1]":`${s}(0.0)`};
          ${_.setByOffset("global_idx","value")};
        `;return`
  ${e.registerUniforms(d).declareVariables(...x,_)}
  ${$}

    ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")};
  ${n?S:k}}`},Ta=(e,t,r)=>{let i=e.length>2,a=t.outputShape,n=R.size(a),s=[Math.ceil(n/64),1,1];ye("verbose",()=>`[conv2d_backprop_webgpu] dispatch = ${s}`);let d=t.format==="NHWC",l=["rank","rank"],p=[t.strides[0],t.strides[1]],h=[t.kernelShape[d?1:2],t.kernelShape[d?2:3]],u=[t.dilations[0],t.dilations[1]],m=[h[0]+(t.dilations[0]<=1?0:(t.kernelShape[d?1:2]-1)*(t.dilations[0]-1)),h[1]+(t.dilations[1]<=1?0:(t.kernelShape[d?2:3]-1)*(t.dilations[1]-1))],$=[m[0]-1-Math.floor((t.pads[0]+t.pads[2])/2),m[1]-1-Math.floor(t.pads[1]+t.pads[3])/2],f=!1,y=t.group,v=e[1].dims,x=v[0]/y,_=v[1],S=[{type:12,data:n},{type:12,data:p},{type:12,data:h},{type:12,data:u},{type:12,data:m},{type:6,data:$},{type:12,data:x},{type:12,data:_},...G(e[0].dims,e[1].dims)];i&&(S.push(...G(e[2].dims)),l.push("rank")),S.push(...G(a));let k=s[1]===1&&s[2]===1,T=I=>{let C=[{name:"output_size",type:"u32"},{name:"strides",type:"u32",length:p.length},{name:"filter_dims",type:"u32",length:h.length},{name:"dilations",type:"u32",length:h.length},{name:"effective_filter_dims",type:"u32",length:m.length},{name:"pads",type:"i32",length:$.length},{name:"input_channels_per_group",type:"u32"},{name:"output_channels_per_group",type:"u32"}],M=Ee(e[0].dataType);return`${du(I,e,a,i,k,f,M,C,d)}`};return{name:"ConvTranspose2D",shaderCache:{hint:`${t.cacheKey};`,inputDependencies:l},getRunData:()=>({dispatchGroup:{x:s[0],y:s[1],z:s[2]},outputs:[{dims:r?r(a):a,dataType:e[0].dataType}],programUniforms:S}),getShaderSource:T}}}),pu,cu,hu,ji,dc,fu,mu,gu,yu,pc,Um=F(()=>{"use strict";Dm(),Fm(),kt(),St(),pu=(e,t,r,i,a,n)=>(e-1)*t+r+(i-1)*a+1-n,cu=(e,t,r,i,a)=>{let n=Math.floor(e/2);t==="SAME_UPPER"?(r[i]=n,r[a]=e-n):t==="SAME_LOWER"&&(r[i]=e-n,r[a]=n)},hu=(e,t,r,i,a,n,s,d,l,p)=>{let h=e.length-2,u=p.length===0;l.length<h&&l.push(...Array(h-l.length).fill(0));let m=e[0],$=t[d?3:1]*a;for(let f=0,y=e.length-h-(d?1:0);f<h;++f,++y){let v=e[y],x=u?v*s[f]:p[f],_=pu(v,s[f],n[f],t[y],r[f],x);cu(_,i,n,f,f+h),u&&p.push(s[f]*(v-1)+l[f]+(t[y]-1)*r[f]+1-n[f]-n[f+h])}p.splice(0,0,m),p.splice(d?3:1,0,$)},ji=(e,t)=>{let r=e.kernelShape.slice();if(e.kernelShape.length===0||e.kernelShape.reduce((u,m)=>u*m,1)===0){r.length=0;for(let u=2;u<t[1].dims.length;++u)r.push(t[1].dims[u])}let i=e.format==="NHWC";r.splice(0,0,t[1].dims[0]),r.splice(i?3:1,0,t[1].dims[1]);let a=e.pads.slice(),n=e.outputShape.slice(),s=e.outputPadding.slice(),d=t[0].dims,l=e.dilations.slice();if(l.reduce((u,m)=>u+m,0)===0){let u=t[0].dims.length-2;l=new Array(u).fill(1)}let p=e.strides.slice();if(p.reduce((u,m)=>u+m,0)===0){let u=t[0].dims.length-2;p=new Array(u).fill(1)}hu(d,r,l,e.autoPad,e.group,a,p,i,s,n);let h=Object.assign({},e);return Object.assign(h,{kernelShape:r,pads:a,outputPadding:s,outputShape:n,dilations:l,strides:p}),h},dc=e=>{let t=Ya(e),r=e.format,i=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][typeof e.autoPad>"u"?0:e.autoPad],a=e.dilations,n=e.group,s=e.kernelShape,d=e.pads,l=e.strides,p=e.wIsConst(),h=e.outputPadding,u=e.outputShape;return{autoPad:i,format:r,dilations:a,group:n,kernelShape:s,outputPadding:h,outputShape:u,pads:d,strides:l,wIsConst:p,...t,cacheKey:`${e.format};${t.activation};`}},fu=(e,t)=>{if(!e||e.length!==2&&e.length!==3)throw new Error("Conv requires 2 or 3 inputs");if(e[0].dims.length!==4&&e[0].dims.length!==3)throw new Error("currently only support 2-dimensional conv");if(e[0].dims.length!==e[1].dims.length)throw new Error("filter does not have same dimension as input");let r=e[0].dims[t.format==="NHWC"?e[0].dims.length-1:1],i=e[1].dims[0];if(r!==i)throw new Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");let a=e[1].dims[1]*t.group;if(e.length===3&&(e[2].dims.length!==1||e[2].dims[0]!==a))throw new Error("invalid bias");let n=e[0].dims.length-2;if(t.dilations.reduce((s,d)=>s+d,0)>0&&t.dilations.length!==n)throw new Error(`dilations should be ${n}D`);if(t.strides.reduce((s,d)=>s+d,0)>0&&t.strides.length!==n)throw new Error(`strides should be ${n}D`);if(t.pads.reduce((s,d)=>s+d,0)>0&&t.pads.length!==n*2)throw new Error(`pads should be ${n*2}D`);if(t.outputPadding.length!==n&&t.outputPadding.length!==0)throw new Error(`output_padding should be ${n}D`);if(t.kernelShape.reduce((s,d)=>s+d,0)>0&&t.kernelShape.length!==0&&t.kernelShape.length!==e[1].dims.length-2)throw new Error("invalid kernel shape");if(t.outputShape.length!==0&&t.outputShape.length!==e[0].dims.length-2)throw new Error("invalid output shape")},mu=[2,3,1,0],gu=(e,t,r)=>{let i=ji(r,t),a=r.format==="NHWC",n=i.outputShape,s=n[a?3:1],d=t[0].dims[a?3:1];if(i.group!==1||s===1&&d===1){e.compute(Ta(t,i));return}let l=n[a?1:2],p=n[a?2:3],h=t[1].dims[2],u=t[1].dims[3],m=a?l*p:s,$=a?s:l*p,f=h*u*d,y=!0,v=e.kernelCustomData.wT??e.compute(Le(t[1],mu),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=v);let x=[t[0],v],_=t.length===3;_&&(!a&&t[2].dims.length===1?x.push(t[2].reshape([t[2].dims[0],1,1])):x.push(t[2])),e.compute(lc(x,i,n,m,$,f,_,y),{inputs:x})},yu=(e,t)=>{let r=t.format==="NHWC",i=[e.inputs[0].reshape(r?[e.inputs[0].dims[0],1,e.inputs[0].dims[1],e.inputs[0].dims[2]]:[e.inputs[0].dims[0],e.inputs[0].dims[1],1,e.inputs[0].dims[2]]),e.inputs[1].reshape([e.inputs[1].dims[0],e.inputs[1].dims[1],1,e.inputs[1].dims[2]])];e.inputs.length===3&&i.push(e.inputs[2]);let a=t.kernelShape;(a.length===0||a[0]===0)&&(a=[e.inputs[1].dims[2]]);let n=t.dilations;(n.length===0||n[0]===0)&&(n=[1]);let s=t.strides;(s.length===0||s[0]===0)&&(s=[1]);let d=t.pads;d.length===0&&(d=[0,0]),d=[0,d[0],0,d[1]],s=[1].concat(s),n=[1].concat(n),a=[1].concat(a);let l=ji({...t,pads:d,strides:s,dilations:n,kernelShape:a},i);e.compute(Ta(i,l,p=>r?[p[0],p[2],p[3]]:[p[0],p[1],p[3]]))},pc=(e,t)=>{fu(e.inputs,t),e.inputs[0].dims.length===3?yu(e,t):gu(e,e.inputs,t)}}),wu,cc,hc,Nm=F(()=>{"use strict";ee(),ae(),Te(),ne(),wu=(e,t,r,i)=>{let a=R.size(t),n=t.length,s=P("input",e,n),d=Y("output",e,n),l=r.dataType===6?r.getInt32Array()[0]:Number(r.getBigInt64Array()[0]),p=R.normalizeAxis(l,n),h=u=>{let m=` i32(${s.indicesGet("inputIndices","uniforms.axis")}) `,$=H("uniforms.input_shape","uniforms.axis",n),f=i.reverse?m+(i.exclusive?" + 1":""):"0",y=i.reverse?$:m+(i.exclusive?"":" + 1");return`
                ${u.registerUniform("outputSize","u32").registerUniform("axis","u32").declareVariables(s,d)}
                ${u.mainStart()}
                  ${u.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
                  var inputIndices = ${d.offsetToIndices("global_idx")};
                  var sum = ${d.type.value}(0);
                  let first : i32 = ${f};
                  let last : i32 = ${y};
                  for (var i : i32 = first; i < last; i++) {
                    ${s.indicesSet("inputIndices","uniforms.axis","u32(i)")};
                    sum = sum + ${s.getByIndices("inputIndices")};
                  }
                  ${d.setByOffset("global_idx","sum")};
                }`};return{name:"CumSum",shaderCache:{hint:i.cacheKey,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:t,dataType:e}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:[{type:12,data:a},{type:12,data:p},...G(t,t)]}),getShaderSource:h}},cc=(e,t)=>{let r=e.inputs[0].dims,i=e.inputs[0].dataType,a=e.inputs[1];e.compute(wu(i,r,a,t),{inputs:[0]})},hc=e=>{let t=e.exclusive===1,r=e.reverse===1;return we({exclusive:t,reverse:r})}}),$u,_u,bu,fc,mc,Wm=F(()=>{"use strict";ee(),ae(),Te(),ne(),$u=e=>{if(!e||e.length!==1)throw new Error("DepthToSpace requires 1 input.");if(e[0].dims.length!==4)throw new Error("DepthToSpace requires 4D input.")},_u=(e,t,r,i)=>{let a=[];a.push(`fn perm(i: ${i.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`);for(let n=0;n<t;++n)a.push(r.indicesSet("a",e[n],`i[${n}]`));return a.push("return a;}"),a.join(`
`)},bu=(e,t)=>{let r,i,a,n,s,d,l=t.format==="NHWC",p=t.blocksize,h=t.mode==="DCR";l?([r,i,a,n]=e.dims,s=h?[r,i,a,p,p,n/p**2]:[r,i,a,n/p**2,p,p],d=h?[0,1,3,2,4,5]:[0,1,4,2,5,3]):([r,i,a,n]=[e.dims[0],e.dims[2],e.dims[3],e.dims[1]],s=h?[r,p,p,n/p**2,i,a]:[r,n/p**2,p,p,i,a],d=h?[0,3,4,1,5,2]:[0,1,4,2,5,3]);let u=e.reshape(s),m=u.dims.length,$=e.dataType,f=P("a",$,m),y=Y("output",$,m),v=x=>`
  ${x.registerUniform("output_size","u32").declareVariables(f,y)}

  ${_u(d,m,f,y)}

  ${x.mainStart()}
    ${x.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${y.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${y.setByOffset("global_idx",f.getByIndices("aIndices"))}
  }`;return{name:"DepthToSpace",shaderCache:{hint:`${e.dims};${t.blocksize};${t.mode}`,inputDependencies:["rank"]},getRunData:x=>{let _=l?[r,i*p,a*p,n/p**2]:[r,n/p**2,i*p,a*p],S=R.size(_),k=u.dims,T=R.sortBasedOnPerm(k,d);return{outputs:[{dims:_,dataType:x[0].dataType}],dispatchGroup:{x:Math.ceil(S/64)},programUniforms:[{type:12,data:S},...G(k,T)]}},getShaderSource:v}},fc=(e,t)=>{$u(e.inputs),e.compute(bu(e.inputs[0],t))},mc=e=>we({blocksize:e.blocksize,mode:e.mode,format:e.format})}),Pr,Jt,Gi,vu,xu,Su,ku,Hi,Tu,gc,yc,Lm=F(()=>{"use strict";ee(),ae(),Te(),ne(),Pr="[a-zA-Z]|\\.\\.\\.",Jt="("+Pr+")+",Gi="^"+Jt+"$",vu="("+Jt+",)*"+Jt,xu="^"+vu+"$",Su=class{constructor(e=-1){this.symbolToIndices=new Map,this.inputIndex=e}addSymbol(e,t){let r=this.symbolToIndices.get(e);r===void 0?r=[t]:r.push(t),this.symbolToIndices.set(e,r)}},ku=class{constructor(e,t){this.equation=t,this.hasEllipsis=!1,this.symbolToInfo=new Map,this.lhs=new Array,this.outputDims=[];let[r,i]=t.includes("->")?t.split("->",2):[t,""];if(!r.match(RegExp(xu)))throw new Error("Invalid LHS term");if(r.split(",").forEach((a,n)=>{let s=e[n].dims.slice();if(!a.match(RegExp(Gi)))throw new Error("Invalid LHS term");let d=this.processTerm(a,!0,s,n);this.lhs.push(d)}),i==="")i+=[...this.symbolToInfo.entries()].filter(([a,n])=>n.count===1||a==="...").map(([a])=>a).join("");else if(!i.match(RegExp(Jt)))throw new Error("Invalid RHS");i.match(RegExp(Pr,"g"))?.forEach(a=>{if(a==="...")this.outputDims=this.outputDims.concat(this.ellipsisDims);else{let n=this.symbolToInfo.get(a);if(n===void 0)throw new Error("Invalid RHS symbol");this.outputDims.push(n.dimValue)}}),this.rhs=this.processTerm(i,!1,this.outputDims)}addSymbol(e,t,r){let i=this.symbolToInfo.get(e);if(i!==void 0){if(i.dimValue!==t&&i.count!==1)throw new Error("Dimension mismatch");i.count++,i.inputIndices.push(r)}else i={count:1,dimValue:t,inputIndices:[r]};this.symbolToInfo.set(e,i)}processTerm(e,t,r,i=-1){let a=r.length,n=!1,s=[],d=0;if(!e.match(RegExp(Gi))&&!t&&e!=="")throw new Error("Invalid LHS term");let l=e.match(RegExp(Pr,"g")),p=new Su(i);return l?.forEach((h,u)=>{if(h==="..."){if(n)throw new Error("Only one ellipsis is allowed per input term");n=!0;let m=a-l.length+1;if(m<0)throw new Error("Ellipsis out of bounds");if(s=r.slice(d,d+m),this.hasEllipsis){if(this.ellipsisDims.length!==s.length||this.ellipsisDims.toString()!==s.toString())throw new Error("Ellipsis dimensions mismatch")}else if(t)this.hasEllipsis=!0,this.ellipsisDims=s;else throw new Error("Ellipsis must be specified in the LHS");for(let $=0;$<s.length;$++){let f=String.fromCharCode(48+$);p.addSymbol(f,u+$),this.addSymbol(f,r[d++],i)}}else p.addSymbol(h,u+(this.hasEllipsis?this.ellipsisDims.length-1:0)),this.addSymbol(h,r[d++],i)}),p}},Hi=e=>e+"_max",Tu=(e,t,r,i)=>{let a=e.map(p=>p.length).map((p,h)=>P(`input${h}`,t,p)),n=R.size(i),s=Y("output",t,i.length),d=[...r.symbolToInfo.keys()].filter(p=>!r.rhs.symbolToIndices.has(p)),l=p=>{let h=[],u="var prod = 1.0;",m="var sum = 0.0;",$="sum += prod;",f=[],y=[],v=[],x=[],_=r.symbolToInfo.size===r.rhs.symbolToIndices.size;r.symbolToInfo.forEach((k,T)=>{if(r.rhs.symbolToIndices.has(T)){let I=r.rhs.symbolToIndices.get(T)?.[0];I!==void 0&&r.lhs.forEach((C,M)=>{if(k.inputIndices.includes(M)){let N=C.symbolToIndices.get(T);if(N===void 0)throw new Error("Invalid symbol error");N.forEach(W=>{h.push(`${a[M].indicesSet(`input${M}Indices`,W,s.indicesGet("outputIndices",I))}`)})}})}else r.lhs.forEach((I,C)=>{if(k.inputIndices.includes(C)){let M=I.symbolToIndices.get(T);if(M===void 0)throw new Error("Invalid symbol error");M.forEach(N=>{f.push(`${a[C].indicesSet(`input${C}Indices`,N,`${T}`)}`)}),x.push(`prod *= ${a[C].getByIndices(`input${C}Indices`)};`)}}),y.push(`for(var ${T}: u32 = 0; ${T} < uniforms.${Hi(T)}; ${T}++) {`),v.push("}")});let S=_?[...h,`let sum = ${a.map((k,T)=>k.getByIndices(`input${T}Indices`)).join(" * ")};`]:[...h,m,...y,...f,u,...x,$,...v];return`
            ${p.registerUniforms(d.map(k=>({name:`${Hi(k)}`,type:"u32"}))).registerUniform("outputSize","u32").declareVariables(...a,s)}

            ${p.mainStart()}
            ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
            var outputIndices = ${s.offsetToIndices("global_idx")};
            ${a.map((k,T)=>`var input${T}Indices: ${a[T].type.indices};`).join(`
`)}
            ${S.join(`
`)};
            ${s.setByOffset("global_idx","sum")};
          }`};return{name:"Einsum",shaderCache:{hint:r.equation,inputDependencies:e.map(()=>"rank")},getRunData:()=>{let p=d.filter(u=>r.symbolToInfo.has(u)).map(u=>({type:12,data:r.symbolToInfo.get(u)?.dimValue||0}));p.push({type:12,data:n});let h=e.map((u,m)=>[...G(u)]).reduce((u,m)=>u.concat(m),p);return h.push(...G(i)),{outputs:[{dims:i,dataType:t}],dispatchGroup:{x:Math.ceil(n/64)},programUniforms:h}},getShaderSource:l}},gc=(e,t)=>{let r=new ku(e.inputs,t.equation),i=r.outputDims,a=e.inputs.map((n,s)=>n.dims);e.compute(Tu(a,e.inputs[0].dataType,r,i))},yc=e=>{let t=e.equation.replace(/\s+/g,"");return we({equation:t})}}),Eu,Ki,Cu,Iu,wc,qm=F(()=>{"use strict";ee(),ae(),ne(),Eu=e=>{if(!e||e.length!==2)throw new Error("Expand requires 2 input.");let t=e[0].dims,r=Array.from(e[1].getBigInt64Array(),Number),i=r.length<t.length?0:r.length-t.length,a=t.length<r.length?0:t.length-r.length;for(;i<r.length&&a<t.length;++i,++a)if(r[i]!==t[a]&&r[i]!==1&&t[a]!==1)throw new Error("Expand requires shape to be broadcastable to input")},Ki=(e,t)=>{let r=e.length-t.length,i=[];for(let a=0;a<r;++a)i.push(e[a]);for(let a=0;a<t.length;++a)i.push(t[a]===1?e[a+r]:t[a]);return i},Cu=(e,t)=>e.length>t.length?Ki(e,t):Ki(t,e),Iu=e=>{let t=e[0].dims,r=Array.from(e[1].getBigInt64Array(),Number),i=Cu(t,r),a=e[0].dataType,n=a===9?4:1,s=Math.ceil(R.size(i)/n),d=p=>{let h=P("input",a,t.length,n),u=Y("output",a,i.length,n),m;if(a===9){let $=(f,y,v="")=>`
          let outputIndices${y} = ${u.offsetToIndices(`outputOffset + ${y}u`)};
          let offset${y} = ${h.broadcastedIndicesToOffset(`outputIndices${y}`,u)};
          let index${y} = offset${y} / 4u;
          let component${y} = offset${y} % 4u;
          ${f}[${y}] = ${v}(${h.getByOffset(`index${y}`)}[component${y}]);
        `;m=`
        let outputOffset = global_idx * ${n};
        var data = vec4<u32>(0);
        ${$("data",0,"u32")}
        ${$("data",1,"u32")}
        ${$("data",2,"u32")}
        ${$("data",3,"u32")}
        ${u.setByOffset("global_idx","data")}
      }`}else m=`
        let outputIndices = ${u.offsetToIndices("global_idx")};
        let inputOffset = ${h.broadcastedIndicesToOffset("outputIndices",u)};
        ${u.setByOffset("global_idx",h.getByOffset("inputOffset"))}
      }`;return`
    ${p.registerUniform("vec_size","u32").declareVariables(h,u)}
    ${p.mainStart()}
    ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
    ${m}`},l=[{type:12,data:s},...G(t,i)];return{name:"Expand",shaderCache:{hint:`${i.length}`,inputDependencies:["rank"]},getShaderSource:d,getRunData:()=>({outputs:[{dims:i,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:l})}},wc=e=>{Eu(e.inputs),e.compute(Iu(e.inputs),{inputs:[0]})}}),Au,$c,Vm=F(()=>{"use strict";ee(),ae(),ne(),Ka(),Au=e=>{let t=e[0].dataType,r=R.size(e[0].dims),i=R.size(e[1].dims),a=i%4===0,n=s=>{let d=P("x",t,[1],4),l=P("bias",t,[1],4),p=Y("y",t,[1],4),h=[{name:"output_vec_size",type:"u32"},{name:"bias_size",type:"u32"}],u=$=>`
      let bias${$}_offset: u32 = (global_idx * 4 + ${$}) % uniforms.bias_size;
      let bias${$} = ${l.getByOffset(`bias${$}_offset / 4`)}[bias${$}_offset % 4];`,m=a?`
      let bias = ${l.getByOffset("global_idx % (uniforms.bias_size / 4)")};`:`${u(0)}${u(1)}${u(2)}${u(3)}
      let bias = ${d.type.value}(bias0, bias1, bias2, bias3);`;return`${s.registerUniforms(h).declareVariables(d,l,p)}

    ${ba(Be(t))}

    ${s.mainStart(Ht)}
      ${s.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_vec_size")}

      let x = ${d.getByOffset("global_idx")};
      ${m}
      let x_in = x + bias;
      ${p.setByOffset("global_idx",va("x_in"))}
    }`};return{name:"FastGeluWithBias",shaderCache:{hint:`${a}`,inputDependencies:["type","type"]},getShaderSource:n,getRunData:s=>({outputs:[{dims:s[0].dims,dataType:s[0].dataType}],programUniforms:[{type:12,data:Math.ceil(r/4)},{type:12,data:i}],dispatchGroup:{x:Math.ceil(r/Ht/4)}})}},$c=e=>{e.inputs.length<2||R.size(e.inputs[1].dims)===0?Fp(e):e.compute(Au(e.inputs))}}),zu,Ru,_c,bc,jm=F(()=>{"use strict";ee(),ae(),Te(),ne(),zu=e=>{if(!e||e.length!==2)throw new Error("Gather requires 2 inputs.")},Ru=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r.length,n=R.normalizeAxis(t.axis,a),s=r.slice(0);s.splice(n,1,...i);let d=r[n],l=e[0].dataType===9?4:1,p=Math.ceil(R.size(s)/l),h=[{type:12,data:p},{type:6,data:d},{type:12,data:n},...G(e[0].dims,e[1].dims,s)],u=m=>{let $=P("data",e[0].dataType,e[0].dims.length,l),f=P("inputIndices",e[1].dataType,e[1].dims.length),y=Y("output",e[0].dataType,s.length,l),v=_=>{let S=i.length,k=`var indicesIndices${_}  = ${f.type.indices}(0);`;for(let T=0;T<S;T++)k+=`${S>1?`indicesIndices${_}[${T}]`:`indicesIndices${_}`} = ${s.length>1?`outputIndices${_}[uniforms.axis + ${T}]`:`outputIndices${_}`};`;k+=`
          var idx${_} = ${f.getByIndices(`indicesIndices${_}`)};
          if (idx${_} < 0) {
            idx${_} = idx${_} + uniforms.axisDimLimit;
          }
          var dataIndices${_} : ${$.type.indices};
        `;for(let T=0,I=0;T<a;T++)T===n?(k+=`${a>1?`dataIndices${_}[${T}]`:`dataIndices${_}`} = u32(idx${_});`,I+=S):(k+=`${a>1?`dataIndices${_}[${T}]`:`dataIndices${_}`} = ${s.length>1?`outputIndices${_}[${I}]`:`outputIndices${_}`};`,I++);return k},x;if(e[0].dataType===9){let _=(S,k,T="")=>`
          let outputIndices${k} = ${y.offsetToIndices(`outputOffset + ${k}u`)};
          ${v(k)};
          let offset${k} = ${$.indicesToOffset(`dataIndices${k}`)};
          let index${k} = offset${k} / 4u;
          let component${k} = offset${k} % 4u;
          ${S}[${k}] = ${T}(${$.getByOffset(`index${k}`)}[component${k}]);
        `;x=`
        let outputOffset = global_idx * ${l};
        var value = vec4<u32>(0);
        ${_("value",0,"u32")}
        ${_("value",1,"u32")}
        ${_("value",2,"u32")}
        ${_("value",3,"u32")}
        ${y.setByOffset("global_idx","value")}
      `}else x=`
      let outputIndices = ${y.offsetToIndices("global_idx")};
      ${v("")};
      let value = ${$.getByIndices("dataIndices")};
      ${y.setByOffset("global_idx","value")};
      `;return`
      ${m.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables($,f,y)}
      ${m.mainStart()}
        ${m.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        ${x}
      }`};return{name:"Gather",shaderCache:{hint:t.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:s,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:h}),getShaderSource:u}},_c=e=>we({axis:e.axis}),bc=(e,t)=>{let r=e.inputs;zu(r),e.compute(Ru(e.inputs,t))}}),Ou,Bu,vc,xc,Gm=F(()=>{"use strict";ee(),ae(),Te(),ne(),Ou=(e,t)=>{if(e.length<3||e.length>4)throw new Error("GatherBlockQuantized requires 3 or 4 inputs.");let r=R.normalizeAxis(t.quantizeAxis,e[0].dims.length),i=t.blockSize,a=e[0],n=e[2],s=e.length===4?e[3]:void 0;if(n.dims.length!==a.dims.length||!a.dims.map((d,l)=>l===r?Math.ceil(d/i)===n.dims[l]:d===n.dims[l]).reduce((d,l)=>d&&l,!0))throw new Error("Scales must have the same rank as the input tensor and the dims should match except on gatherAxis.");if(s){if(s.dataType!==a.dataType)throw new Error("Zero point must have the same data type as the input tensor.");if(s.dims.length!==n.dims.length||!s.dims.map((d,l)=>d===n.dims[l]).reduce((d,l)=>d&&l,!0))throw new Error("Zero point must have the same rank as the input tensor and the dims should match except on quantizeAxis.")}},Bu=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r.length,n=R.normalizeAxis(t.gatherAxis,a),s=R.normalizeAxis(t.quantizeAxis,a),d=r.slice(0);d.splice(n,1,...i);let l=R.size(d),p=e[2].dataType,h=e[0].dataType===22,u=[{type:12,data:l},{type:12,data:s},{type:12,data:n},{type:12,data:t.blockSize},...G(...e.map(($,f)=>$.dims),d)],m=$=>{let f=P("data",e[0].dataType,e[0].dims.length),y=P("inputIndices",e[1].dataType,e[1].dims.length),v=P("scales",e[2].dataType,e[2].dims.length),x=e.length>3?P("zeroPoint",e[3].dataType,e[3].dims.length):void 0,_=Y("output",p,d.length),S=[f,y,v];x&&S.push(x);let k=[{name:"output_size",type:"u32"},{name:"quantize_axis",type:"u32"},{name:"gather_axis",type:"u32"},{name:"block_size",type:"u32"}];return`
        ${$.registerUniforms(k).declareVariables(...S,_)}
        ${$.mainStart()}
        let output_indices = ${_.offsetToIndices("global_idx")};
        var indices_indices = ${y.type.indices}(0);
        ${i.length>1?`
          for (var i: u32 = 0; i < ${i.length}; i++) {
            let index = ${_.indicesGet("output_indices","uniforms.gather_axis + i")};
            ${y.indicesSet("indices_indices","i","index")};
          }`:`indices_indices = ${_.indicesGet("output_indices","uniforms.gather_axis")};`};
        var data_indices = ${f.type.indices}(0);
        for (var i: u32 = 0; i < uniforms.gather_axis; i++) {
          let index = ${_.indicesGet("output_indices","i")};
          ${f.indicesSet("data_indices","i","index")};
        }
        var index_from_indices = ${y.getByIndices("indices_indices")};
        if (index_from_indices < 0) {
          index_from_indices += ${r[n]};
        }
        ${f.indicesSet("data_indices","uniforms.gather_axis","u32(index_from_indices)")};
        for (var i = uniforms.gather_axis + 1; i < ${d.length}; i++) {
          let index = ${_.indicesGet("output_indices",`i + ${i.length} - 1`)};
          ${f.indicesSet("data_indices","i","index")};
        }
        let data_offset = ${f.indicesToOffset("data_indices")};
        let data_index = data_offset % 8;
        // Convert 4-bit packed data to 8-bit packed data.
        let packed_4bit_quantized_data = ${f.getByOffset("data_offset / 8")};
        let packed_8bit_quantized_data = (packed_4bit_quantized_data >> (4 * (data_index % 2))) & 0x0f0f0f0f;
        let quantized_data_vec = ${h?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_quantized_data));
        let quantized_data = quantized_data_vec[data_index / 2];
        var scale_indices = data_indices;
        let quantize_axis_index = ${v.indicesGet("data_indices","uniforms.quantize_axis")} / uniforms.block_size;
        ${v.indicesSet("scale_indices","uniforms.quantize_axis","quantize_axis_index")};
        var scale = ${v.getByIndices("scale_indices")};
        ${x?`
              let zero_point_indices = scale_indices;
              let zero_point_offset = ${x.indicesToOffset("zero_point_indices")};
              let zero_point_index = zero_point_offset % 8;
              let packed_4bit_zero_points = ${x.getByOffset("zero_point_offset / 8")};
              let packed_8bit_zero_points = (packed_4bit_zero_points >> (4 * (zero_point_index % 2))) & 0x0f0f0f0f;
              let zero_point_vec = ${h?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_zero_points));
              let zero_point = zero_point_vec[zero_point_index / 2];`:"var zero_point = 0"};
        let dequantized_data = ${Be(p)}(quantized_data - zero_point) * scale;
        ${_.setByOffset("global_idx","dequantized_data")};
    }`};return{name:"GatherBlockQuantized",shaderCache:{hint:`${t.cacheKey};${e.filter(($,f)=>f!==1).map($=>$.dims.join("_")).join(";")}`,inputDependencies:Array.from({length:e.length},($,f)=>"rank")},getRunData:()=>({outputs:[{dims:d,dataType:p}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:u}),getShaderSource:m}},vc=(e,t)=>{let r=e.inputs;Ou(r,t),e.compute(Bu(e.inputs,t))},xc=e=>we({blockSize:e.blockSize,gatherAxis:e.gatherAxis,quantizeAxis:e.quantizeAxis})}),Mu,Pu,Sc,kc,Hm=F(()=>{"use strict";ee(),ae(),Te(),ne(),Mu=e=>{if(!e||e.length!==2)throw new Error("GatherElements requires 2 inputs.");if(e[0].dims.length<1)throw new Error("GatherElements requires that the data input be rank >= 1.");if(e[0].dims.length!==e[1].dims.length)throw new Error(`GatherElements requires that the data input and
                     indices input tensors be of same rank.`)},Pu=(e,t)=>{let r=e[0].dims,i=e[0].dataType,a=r.length,n=e[1].dims,s=e[1].dataType,d=R.normalizeAxis(t.axis,a),l=r[d],p=n.slice(0),h=R.size(p),u=P("input",i,a),m=P("indicesInput",s,n.length),$=Y("output",i,p.length),f=[{type:12,data:h},{type:6,data:l},{type:12,data:d}];return f.push(...G(r,n,p)),{name:"GatherElements",shaderCache:{inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:p,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(h/64)},programUniforms:f}),getShaderSource:y=>`
      ${y.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(u,m,$)}
      ${y.mainStart()}
      ${y.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

      let outputIndices = ${$.offsetToIndices("global_idx")};

      var idx = ${m.getByOffset("global_idx")};
      if (idx < 0) {
        idx = idx + uniforms.axisDimLimit;
      }
      var inputIndices = ${u.type.indices}(outputIndices);
      ${u.indicesSet("inputIndices","uniforms.axis","u32(idx)")};
      let value = ${u.getByIndices("inputIndices")};

      ${$.setByOffset("global_idx","value")};
  }`}},Sc=e=>we({axis:e.axis}),kc=(e,t)=>{let r=e.inputs;Mu(r),e.compute(Pu(e.inputs,t))}}),Du,Fu,Tc,Ec,Km=F(()=>{"use strict";ee(),ae(),ne(),Du=e=>{if(!e)throw new Error("Input is missing");if(e.length<2||e.length>3)throw new Error("Invaid input number.");if(e.length===3&&e[2].dims.length>2)throw new Error("Invalid input shape of C");if(e[0].dataType!==e[1].dataType||e.length===3&&e[0].dataType!==e[2].dataType)throw new Error("Input types are mismatched")},Fu=(e,t)=>{let r=e[0].dims.slice(),i=e[1].dims.slice(),[a,n,s]=Ad.getShapeOfGemmResult(r,t.transA,i,t.transB,e.length===3?e[2].dims:void 0),d=[a,n];if(!d)throw new Error("Can't use gemm on the given tensors");let l=R.size(d),p=[{type:12,data:l},{type:12,data:a},{type:12,data:n},{type:12,data:s},{type:1,data:t.alpha},{type:1,data:t.beta}],h=["type","type"];e.length===3&&(p.push(...G(e[2].dims)),h.push("rank")),p.push(...G(d));let u=m=>{let $="";t.transA&&t.transB?$="value += a[k * uniforms.M + m] * b[n * uniforms.K + k];":t.transA&&!t.transB?$="value += a[k * uniforms.M + m] * b[k * uniforms.N + n];":!t.transA&&t.transB?$="value += a[m * uniforms.K + k] * b[n * uniforms.K + k];":!t.transA&&!t.transB&&($="value += a[m * uniforms.K + k] * b[k * uniforms.N + n];");let f=t.alpha===1?"":"value *= uniforms.alpha;",y=P("a",e[0].dataType,e[0].dims),v=P("b",e[1].dataType,e[1].dims),x=y.type.value,_=null,S=[y,v];e.length===3&&(_=P("c",e[2].dataType,e[2].dims.length),S.push(_));let k=Y("output",e[0].dataType,d.length);S.push(k);let T=[{name:"output_size",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"},{name:"alpha",type:"f32"},{name:"beta",type:"f32"}];return`
  ${m.registerUniforms(T).declareVariables(...S)}

  ${m.mainStart()}
    ${m.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let m = global_idx / uniforms.N;
    let n = global_idx % uniforms.N;

    var value = ${x}(0);
    for (var k: u32 = 0u; k < uniforms.K; k++) {
      ${$}
    }

    ${f}
    ${_!=null?`let cOffset = ${_.broadcastedIndicesToOffset("vec2(m, n)",k)}; value += ${x}(uniforms.beta) * ${_.getByOffset("cOffset")};`:""}
    output[global_idx] = value;
  }`};return{name:"Gemm",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:h},getRunData:()=>({outputs:[{dims:d,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:p}),getShaderSource:u}},Tc=e=>{let t=e.transA,r=e.transB,i=e.alpha,a=e.beta;return{transA:t,transB:r,alpha:i,beta:a,cacheKey:`${e.transA};${e.transB};${e.alpha===1}`}},Ec=(e,t)=>{Du(e.inputs),e.compute(Fu(e.inputs,t))}}),Ue,Uu,Cc,Yi,Nu,ur,Ic,Ac=F(()=>{"use strict";ee(),ae(),Te(),Va(),Ha(),ne(),St(),Ue=(e,t)=>e.length>t&&e[t].dims.length>0?e[t]:void 0,Uu=(e,t)=>{let r=e[0],i=Ue(e,1),a=Ue(e,2),n=Ue(e,3),s=Ue(e,4),d=Ue(e,5),l=Ue(e,6),p=Ue(e,7);if(r.dims.length!==3&&r.dims.length!==5)throw new Error("Input query is expected to have 3 or 5 dimensions");let h=r.dims[0],u=r.dims[1],m=r.dims.length===3?r.dims[2]:t.numHeads*r.dims[4],$=u,f=0,y=0,v=Math.floor(m/t.numHeads);if(l&&p&&R.size(l.dims)&&R.size(p.dims)){if(l.dims.length!==4)throw new Error('Input "past_key" is expected to have 4 dimensions');if(l.dims[0]!==h||l.dims[1]!==t.numHeads||l.dims[3]!==v)throw new Error('Input "past_key" shape (batch_size, num_heads, past_sequence_length, head_size)');if(p.dims[0]!==h||p.dims[1]!==t.numHeads||p.dims[3]!==v)throw new Error('Input "past_value" shape (batch_size, num_heads, past_sequence_length, head_size)');if(l.dims[2]!==p.dims[2])throw new Error('Input "past_key" and "past_value" shall have same dim 2 (past_sequence_length)');if(p.dims.length!==4)throw new Error('Input "past_value" is expected to have 4 dimensions');f=l.dims[2],y=l.dims[2]}else if(l&&R.size(l.dims)||p&&R.size(p.dims))throw new Error('Input "past_key" and "past_value" shall be both present or both absent');let x;if(i&&R.size(i.dims)>0){if(r.dims.length!==3)throw new Error('Input "query" is expected to have 3 dimensions when key is given');if(i.dims.length<3||i.dims.length>5)throw new Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(r.dims[0]!==i.dims[0])throw new Error('Input "query" and "key" shall have same dim 0 (batch size)');if(i.dims.length===3){if(i.dims[2]!==r.dims[2])throw new Error('Input "query" and "key" shall have same dim 2 (hidden_size)');x=2,$=i.dims[1]}else if(i.dims.length===5){if(i.dims[2]!==t.numHeads||i.dims[3]!==2||i.dims[4]!==v)throw new Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(a)throw new Error('Expect "value" be none when "key" has packed kv format.');x=5,$=i.dims[1]}else{if(i.dims[1]!==t.numHeads||i.dims[3]!==v)throw new Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');x=0,$=i.dims[2]}}else{if(r.dims.length!==5)throw new Error('Input "query" is expected to have 5 dimensions when key is empty');if(r.dims[2]!==t.numHeads||r.dims[3]!==3)throw new Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');x=3}if(n&&R.size(n.dims)>0){if(n.dims.length!==1)throw new Error('Input "bias" is expected to have 1 dimension');if(i&&i.dims.length===5&&i.dims[3]===2)throw new Error("bias is not allowed for packed kv.")}let _=f+$,S=0;if(s&&R.size(s.dims)>0){S=8;let C=s.dims;throw C.length===1?C[0]===h?S=1:C[0]===3*h+2&&(S=3):C.length===2&&C[0]===h&&C[1]===_&&(S=5),S===8?new Error('Input "key_padding_mask" shape shall be (batch_size) or (batch_size, total_sequence_length)'):new Error("Mask not supported")}let k=!1,T=m;if(a&&R.size(a.dims)>0){if(a.dims.length!==3&&a.dims.length!==4)throw new Error('Input "value" is expected to have 3 or 4 dimensions');if(r.dims[0]!==a.dims[0])throw new Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(a.dims.length===3){if($!==a.dims[1])throw new Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');T=a.dims[2]}else{if($!==a.dims[2])throw new Error('Input "key" and "value" shall have the same dim 2 (kv_sequence_length)');T=a.dims[1]*a.dims[3],k=!0}}let I=!1;if(s&&R.size(s.dims)>0)throw new Error("Key padding mask is not supported");if(d&&R.size(d.dims)>0){if(d.dims.length!==4)throw new Error('Input "attention_bias" is expected to have 4 dimensions');if(d.dims[0]!==h||d.dims[1]!==t.numHeads||d.dims[2]!==u||d.dims[3]!==_)throw new Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:h,sequenceLength:u,pastSequenceLength:f,kvSequenceLength:$,totalSequenceLength:_,maxSequenceLength:y,inputHiddenSize:0,hiddenSize:m,vHiddenSize:T,headSize:v,vHeadSize:Math.floor(T/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:S,scale:t.scale,broadcastResPosBias:I,passPastInKv:k,qkvFormat:x}},Cc=e=>we({...e}),Yi=we({perm:[0,2,1,3]}),Nu=(e,t,r,i,a,n,s)=>{let d=[i,a,n],l=R.size(d),p=[{type:12,data:l},{type:12,data:s},{type:12,data:n}],h=u=>{let m=Y("qkv_with_bias",t.dataType,d),$=P("qkv",t.dataType,d),f=P("bias",r.dataType,d),y=[{name:"output_size",type:"u32"},{name:"bias_offset",type:"u32"},{name:"hidden_size",type:"u32"}];return`
  ${u.registerUniforms(y).declareVariables($,f,m)}
  ${u.mainStart()}
    ${u.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let bias_offset_idx = (global_idx % uniforms.hidden_size) + uniforms.bias_offset;

    qkv_with_bias[global_idx] = qkv[global_idx] + bias[bias_offset_idx];
  }`};return e.compute({name:"MultiHeadAttentionAddBias",shaderCache:{inputDependencies:["type","type"]},getRunData:()=>({outputs:[{dims:d,dataType:t.dataType,gpuDataType:0}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:p}),getShaderSource:h},{inputs:[t,r],outputs:[-1]})[0]},ur=(e,t,r,i,a,n,s,d)=>{let l=n;if(s&&R.size(s.dims)>0){if(i===1)throw new Error("AddBiasReshape is not implemented. Please export your model with packed QKV or KV");return l=Nu(e,n,s,t,i,r*a,d),l=l.reshape([t,i,r,a]),r===1||i===1?l:e.compute(Le(l,Yi.perm),{inputs:[l],outputs:[-1]})[0]}else return n.dims.length===3&&(l=n.reshape([t,i,r,a])),r===1||i===1?l:e.compute(Le(l,Yi.perm),{inputs:[l],outputs:[-1]})[0]},Ic=(e,t)=>{let r=Uu(e.inputs,t),i=e.inputs[0],a=Ue(e.inputs,1),n=Ue(e.inputs,2),s=Ue(e.inputs,3),d=Ue(e.inputs,4),l=Ue(e.inputs,5),p=Ue(e.inputs,6),h=Ue(e.inputs,7);if(i.dims.length===5)throw new Error("Packed QKV is not implemented");if(a?.dims.length===5)throw new Error("Packed KV is not implemented");let u=a&&n&&a.dims.length===4&&n.dims.length===4,m=ur(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,i,s,0);if(u)return dr(e,m,a,n,d,void 0,p,h,l,r,t);if(!a||!n)throw new Error("key and value must be provided");let $=ur(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.headSize,a,s,r.hiddenSize),f=ur(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.vHeadSize,n,s,2*r.hiddenSize);dr(e,m,$,f,d,void 0,p,h,l,r,t)}}),Zi,Wu,Lu,Ea,zc,Rc=F(()=>{"use strict";ee(),ae(),ne(),Zi=e=>Array.from(e.getBigInt64Array(),Number),Wu=e=>{if(!e||e.length!==2)throw new Error("Tile requires 2 inputs.");if(e[0].dataType!==1&&e[0].dataType!==10&&e[0].dataType!==6&&e[0].dataType!==12)throw new Error("Tile only support float, float16, int32, and uint32 data types");if(e[1].dataType!==7)throw new Error("Tile `repeats` input should be of int64 data type");if(e[1].dims.length!==1)throw new Error("Tile `repeats` input should be 1-D");if(Zi(e[1]).length!==e[0].dims.length)throw new Error("Tile `repeats` input should have same number of elements as rank of input data tensor")},Lu=(e,t)=>{let r=[];for(let i=0;i<e.length;++i)r.push(e[i]*t[i]);return r},Ea=(e,t)=>{let r=e[0].dims,i=t??Zi(e[1]),a=Lu(r,i),n=R.size(a),s=e[0].dataType,d=P("input",s,r.length),l=Y("output",s,a.length),p=h=>`
      const inputShape = ${d.indices(...r)};
      ${h.registerUniform("output_size","u32").declareVariables(d,l)}
      ${h.mainStart()}
      ${h.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let output_indices = ${l.offsetToIndices("global_idx")};
      var input_indices: ${d.type.indices};
      for (var i = 0; i < ${r.length}; i++) {
        let input_dim_i = ${d.indicesGet("uniforms.input_shape","i")};
        let input_dim_value = ${l.indicesGet("output_indices","i")}  % input_dim_i;

        ${d.indicesSet("input_indices","i","input_dim_value")}
      }
      ${l.setByOffset("global_idx",d.getByIndices("input_indices"))}
    }`;return{name:"Tile",shaderCache:{hint:`${i}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:a,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(n/64)},programUniforms:[{type:12,data:n},...G(e[0].dims,a)]}),getShaderSource:p}},zc=e=>{Wu(e.inputs),e.compute(Ea(e.inputs),{inputs:[0]})}}),qu,Qi,Oc,Vu,Xi,Bc,Ym=F(()=>{"use strict";ee(),ae(),Te(),Ha(),ne(),Ac(),Rc(),St(),qu=(e,t)=>{let r=e[0],i=e[1],a=e[2],n=e[3],s=e[4];if(r.dims.length!==3&&r.dims.length!==5)throw new Error("Input query is expected to have 3 or 5 dimensions");let d=!1,l=r.dims[0],p=r.dims[1],h=r.dims.length===3?d?r.dims[2]/3:r.dims[2]:t.numHeads*r.dims[4],u=p,m=0,$=0,f=Math.floor(h/t.numHeads),y=n&&n.dims.length!==0,v=s&&s.dims.length!==0,x=!0;if(y&&v){if(n.dims.length!==4)throw new Error('Input "past_key" is expected to have 4 dimensions');if(s.dims.length!==4)throw new Error('Input "past_value" is expected to have 4 dimensions');x?(m=n.dims[1],$=n.dims[1]):(m=n.dims[2],$=n.dims[2])}else if(y||v)throw new Error('Input "past_key" and "past_value" shall be both present or both absent');let _;if(i){if(r.dims.length!==3)throw new Error('Input "query" is expected to have 3 dimensions when key is given');if(i.dims.length<3||i.dims.length>5)throw new Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(r.dims[0]!==i.dims[0])throw new Error('Input "query" and "key" shall have same dim 0 (batch size)');if(i.dims.length===3){if(r.dims[2]%i.dims[2]!==0)throw new Error('Dimension 2 of "query" should be a multiple of "key"');_=2,u=i.dims[1]}else if(i.dims.length===5){if(i.dims[2]!==t.numHeads||i.dims[3]!==2||i.dims[4]!==f)throw new Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(a)throw new Error('Expect "value" be none when "key" has packed kv format.');_=5,u=i.dims[1]}else{if(i.dims[1]!==t.numHeads||i.dims[3]!==f)throw new Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');_=0,u=i.dims[2]}}else{if(r.dims.length!==3&&r.dims.length!==5)throw new Error('Input "query" is expected to have 3 or 5 dimensions when key is empty');if(r.dims.length===5&&(r.dims[2]!==t.numHeads||r.dims[3]!==3))throw new Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');_=3}let S=0,k=!1,T=h;if(a){if(a.dims.length!==3&&a.dims.length!==4)throw new Error('Input "value" is expected to have 3 or 4 dimensions');if(r.dims[0]!==a.dims[0])throw new Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(a.dims.length===3){if(u!==a.dims[1])throw new Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');T=a.dims[2]}else{if(u!==a.dims[2])throw new Error('Input "past_key" and "past_value" shall have the same dim 2 (kv_sequence_length)');T=a.dims[1]*a.dims[3],k=!0}}let I=m+u;return{batchSize:l,sequenceLength:p,pastSequenceLength:m,kvSequenceLength:u,totalSequenceLength:I,maxSequenceLength:$,inputHiddenSize:0,hiddenSize:h,vHiddenSize:T,headSize:f,vHeadSize:Math.floor(T/t.kvNumHeads),numHeads:t.numHeads,kvNumHeads:t.kvNumHeads,nReps:t.numHeads/t.kvNumHeads,pastPresentShareBuffer:!1,maskType:S,scale:t.scale,broadcastResPosBias:!1,passPastInKv:k,qkvFormat:_,isPastkvBSNH:x}},Qi=(e,t,r,i)=>{let a=[i.batchSize,i.totalSequenceLength,i.kvNumHeads,i.headSize],n=4,s=R.size(a)/n,d=i.totalSequenceLength,l=Y("present_kv",r,a.length,n),p=P("new_kv",e.dataType,e.dims.length,n),h=t?P("past_kv",t.dataType,t.dims.length,n):void 0,u=Math.ceil(i.headSize/n),m={x:d,y:e.dims[0],z:1},$=t?["rank","rank"]:["rank"],f=[{type:12,data:s},{type:12,data:i.pastSequenceLength},{type:12,data:i.kvSequenceLength},{type:12,data:i.totalSequenceLength}],y=[p];h?(f.push(...G(e.dims),...G(t.dims),...G(a)),y.push(h)):f.push(...G(e.dims),...G(a));let v=[{name:"output_size",type:"u32"},{name:"past_seqlen",type:"u32"},{name:"new_seqlen",type:"u32"},{name:"present_seqlen",type:"u32"}],x=`      let past_batch_stride = uniforms.past_seqlen * num_heads * H;
        var past_head_stride = uniforms.past_seqlen * H;
        if (is_bsnh) {
          past_head_stride = H;
        }
        let in_offset = b * past_batch_stride + s * row_stride + n * past_head_stride + h;
        present_kv[out_offset] = past_kv[in_offset];`,_=`      let new_batch_stride = uniforms.new_seqlen * num_heads * H;
        let new_row_stride = num_heads * H;
        let new_head_stride = H;
        let in_offset = b * new_batch_stride + (s - past_seqlen) * new_row_stride + n * new_head_stride + h;
        present_kv[out_offset] = new_kv[in_offset];`,S=t?`if (s < past_seqlen) {
        ${x}
        } else if (s < past_seqlen + uniforms.new_seqlen) {
        ${_}
        }`:`if (s < past_seqlen + uniforms.new_seqlen) {
          ${_}
        }`,k=T=>`

  ${T.registerUniforms(v).declareVariables(...y,l)}
  ${T.mainStart([u,i.kvNumHeads,1])}
    ${T.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    var indices = ${l.offsetToIndices("global_idx")};
    let h = local_id.x;
    let n = local_id.y;
    let s = workgroup_id.x;
    let b = workgroup_id.y;
    let num_heads = ${i.kvNumHeads}u;
    let H = ${u}u;

    let present_seqlen = uniforms.present_seqlen;
    let present_batch_stride = present_seqlen * num_heads * H;
    var row_stride = H;
    let is_bsnh = ${i.isPastkvBSNH};

    if (is_bsnh) {
      row_stride = num_heads * H;
    }
    var present_head_stride = present_seqlen * H;
    if (is_bsnh) {
      present_head_stride = H;
    }

    let past_seqlen = uniforms.past_seqlen;

    let out_offset = b * present_batch_stride + s * row_stride + n * present_head_stride + h;
    ${S}
  }`;return{name:"ConcatPastNew",shaderCache:{hint:`${i.kvNumHeads}${u}${!!t}`,inputDependencies:$},getRunData:()=>({outputs:[{dims:a,dataType:r}],dispatchGroup:m,programUniforms:f}),getShaderSource:k}},Oc=e=>we({...e}),Vu=we({perm:[0,2,1,3]}),Xi=(e,t,r,i,a)=>{let n=t,s=i.kvNumHeads,d=i.nReps;return t.dims.length===3&&i.kvSequenceLength!==0&&(n=t.reshape([i.batchSize,i.kvSequenceLength,s,i.headSize])),r?n=e.compute(Qi(n,r,n.dataType,i),{inputs:[n,r],outputs:[i.isPastkvBSNH?a:-1]})[0]:n=e.compute(Qi(n,void 0,n.dataType,i),{inputs:[n],outputs:[i.isPastkvBSNH?a:-1]})[0],d!==1&&(n=e.compute(Ea([n],[1,1,1,d]),{inputs:[n],outputs:[-1]})[0],n=n.reshape([i.batchSize,i.totalSequenceLength,s*d,i.headSize])),e.compute(Le(n,Vu.perm),{inputs:[n],outputs:[-1]})[0]},Bc=(e,t)=>{let r=qu(e.inputs,t);if(e.inputs[0].dims.length===5)throw new Error("Packed QKV is not implemented");if(e.inputs[1]?.dims.length===5)throw new Error("Packed KV is not implemented");let i=ur(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,e.inputs[0],void 0,0),a=e.inputs[3]&&e.inputs[3].dims.length!==0?e.inputs[3]:void 0,n=e.inputs[4]&&e.inputs[4].dims.length!==0?e.inputs[4]:void 0,s=Xi(e,e.inputs[1],a,r,1),d=Xi(e,e.inputs[2],n,r,2);dr(e,i,s,d,void 0,void 0,void 0,void 0,void 0,r,t)}}),Ji,ju,Gu,Mc,Zm=F(()=>{"use strict";ee(),ae(),St(),ne(),Ji=(e,t,r,i,a,n,s,d)=>{let l=Se(n),p=l===1?"f32":`vec${l}f`,h=l===1?"vec2f":`mat2x${l}f`,u=a*s,m=[a,s,n/l],$=[a,s,2],f=["rank","type","type"],y=[];y.push(...G(m,$));let v=x=>{let _=P("x",t.dataType,3,l),S=P("scale",r.dataType,r.dims),k=P("bias",i.dataType,i.dims),T=Y("output",1,3,2),I=[_,S,k,T],C=64;return`
  var<workgroup> workgroup_shared : array<${h}, ${C}>;
  const workgroup_size = ${C}u;
  ${x.declareVariables(...I)}
  ${x.mainStart(C)}
    let batch = workgroup_index / uniforms.x_shape[1];
    let channel = workgroup_index % uniforms.x_shape[1];
    let hight = uniforms.x_shape[2];
    // initialize workgroup memory
    var sum = ${p}(0);
    var squared_sum = ${p}(0);
    for (var h = local_idx; h < hight; h += workgroup_size) {
      let value = ${p}(${_.get("batch","channel","h")});
      sum += value;
      squared_sum += value * value;
    }
    workgroup_shared[local_idx] = ${h}(sum, squared_sum);
    workgroupBarrier();

    for (var currSize = workgroup_size >> 1;  currSize > 0; currSize = currSize >> 1) {
      if (local_idx < currSize) {
        workgroup_shared[local_idx] = workgroup_shared[local_idx] + workgroup_shared[local_idx + currSize];
      }
      workgroupBarrier();
    }
    if (local_idx == 0) {
      let sum_final = ${_t("workgroup_shared[0][0]",l)} / f32(hight * ${l});
      let squared_sum_final = ${_t("workgroup_shared[0][1]",l)} / f32(hight * ${l});

      let inv_std_dev = inverseSqrt(squared_sum_final - sum_final * sum_final + f32(${d}));
      let channel_scale = inv_std_dev * f32(scale[channel]);
      let channel_shift = f32(bias[channel]) - sum_final * channel_scale;
      output[workgroup_index] = vec2f(channel_scale, channel_shift);
    }
  }`};return e.compute({name:"InstanceNormComputeChannelScaleShift",shaderCache:{hint:`${l};${d}`,inputDependencies:f},getRunData:()=>({outputs:[{dims:$,dataType:1}],dispatchGroup:{x:u},programUniforms:y}),getShaderSource:v},{inputs:[t,r,i],outputs:[-1]})[0]},ju=(e,t,r)=>{let i=t[0].dims,a=i,n=2,s=i[0],d=i[1],l=R.sizeFromDimension(i,n),p=Se(l),h=R.size(a)/p,u=Ji(e,t[0],t[1],t[2],s,l,d,r.epsilon),m=[s,d,l/p],$=[s,d],f=["type","none"],y=v=>{let x=P("x",t[0].dataType,m.length,p),_=P("scale_shift",1,$.length,2),S=Y("output",t[0].dataType,m.length,p),k=[x,_,S];return`
  ${v.registerUniform("output_size","u32").declareVariables(...k)}
  ${v.mainStart()}
  ${v.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let outputIndices = ${S.offsetToIndices("global_idx")};
      let batch = outputIndices[0];
      let channel = outputIndices[1];
      let scale_shift = ${_.getByIndices("vec2<u32>(batch, channel)")};
      let value = ${x.getByOffset("global_idx")} * ${S.type.value}(scale_shift.x) + ${S.type.value}(scale_shift.y);
      ${S.setByOffset("global_idx","value")};
  }`};e.compute({name:"InstanceNormalization",shaderCache:{hint:`${p}`,inputDependencies:f},getRunData:()=>({outputs:[{dims:a,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(h/64)},programUniforms:[{type:12,data:h},...G(m,$,m)]}),getShaderSource:y},{inputs:[t[0],u]})},Gu=(e,t,r)=>{let i=t[0].dims,a=i,n=i[0],s=i[i.length-1],d=R.sizeFromDimension(i,1)/s,l=Se(s),p=R.size(a)/l,h=[{type:12,data:d},{type:12,data:Math.floor(s/l)}],u=["type","type"],m=[0,i.length-1];for(let v=0;v<i.length-2;v++)m.push(v+1);let $=e.compute(Le(e.inputs[0],m),{inputs:[e.inputs[0]],outputs:[-1]})[0],f=Ji(e,$,t[1],t[2],n,d,s,r.epsilon),y=v=>{let x=Ee(t[0].dataType),_=l===1?"vec2f":`mat${l}x2f`,S=I=>{let C=I===0?"x":"y",M=l===1?"f32":`vec${l}f`;switch(l){case 1:return`${x}(${M}(scale.${C}))`;case 2:return`vec2<${x}>(${M}(scale[0].${C}, scale[1].${C}))`;case 4:return`vec4<${x}>(${M}(scale[0].${C}, scale[1].${C}, scale[2].${C}, scale[3].${C}))`;default:throw new Error(`Not supported compoents ${l}`)}},k=P("input",t[0].dataType,t[0].dims,l),T=Y("output",t[0].dataType,a,l);return`
  @group(0) @binding(0) var<storage, read> input : array<${k.type.storage}>;
  @group(0) @binding(1) var<storage, read> scale_input : array<${_}>;
  @group(0) @binding(2) var<storage, read_write> output : array<${T.type.storage}>;
  struct Uniforms {H: u32, C : u32};
  @group(0) @binding(3) var<uniform> uniforms: Uniforms;

  ${v.mainStart()}
    let current_image_number = global_idx / (uniforms.C * uniforms.H);
    let current_channel_number = global_idx % uniforms.C;

    let scale_offset = current_image_number * uniforms.C + current_channel_number;
    let scale = scale_input[scale_offset];
    output[global_idx] = fma(input[global_idx], ${S(0)}, ${S(1)});
  }`};e.compute({name:"InstanceNormalizationNHWC",shaderCache:{hint:`${l}`,inputDependencies:u},getRunData:()=>({outputs:[{dims:a,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:h}),getShaderSource:y},{inputs:[t[0],f]})},Mc=(e,t)=>{t.format==="NHWC"?Gu(e,e.inputs,t):ju(e,e.inputs,t)}}),Hu,Ku,Pc,Qm=F(()=>{"use strict";ee(),ae(),ne(),Hu=e=>{if(!e||e.length<2)throw new Error("layerNorm requires at least 2 inputs.")},Ku=(e,t,r)=>{let i=t.simplified,a=e[0].dims,n=e[1],s=!i&&e[2],d=a,l=R.normalizeAxis(t.axis,a.length),p=R.sizeToDimension(a,l),h=R.sizeFromDimension(a,l),u=R.size(n.dims),m=s?R.size(s.dims):0;if(u!==h||s&&m!==h)throw new Error(`Size of X.shape()[axis:] == ${h}.
       Size of scale and bias (if provided) must match this.
       Got scale size of ${u} and bias size of ${m}`);let $=[];for(let T=0;T<a.length;++T)T<l?$.push(a[T]):$.push(1);let f=Se(h),y=["type","type"],v=[{type:12,data:p},{type:1,data:h},{type:12,data:Math.floor(h/f)},{type:1,data:t.epsilon}];s&&y.push("type");let x=r>1,_=r>2,S=T=>{let I=Ee(e[0].dataType),C=[P("x",e[0].dataType,e[0].dims,f),P("scale",n.dataType,n.dims,f)];s&&C.push(P("bias",s.dataType,s.dims,f)),C.push(Y("output",e[0].dataType,d,f)),x&&C.push(Y("mean_data_output",1,$)),_&&C.push(Y("inv_std_output",1,$));let M=[{name:"norm_count",type:"u32"},{name:"norm_size",type:"f32"},{name:"norm_size_vectorized",type:"u32"},{name:"epsilon",type:"f32"}];return`
  ${T.registerUniforms(M).declareVariables(...C)}
  ${T.mainStart()}
    ${T.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.norm_count")}
    let offset = global_idx * uniforms.norm_size_vectorized;
    var mean_vector = ${wa("f32",f)};
    var mean_square_vector = ${wa("f32",f)};

    for (var h: u32 = 0u; h < uniforms.norm_size_vectorized; h++) {
      let value = ${jt(I,f,"x[h + offset]")};
      mean_vector += value;
      mean_square_vector += value * value;
    }
    let mean = ${_t("mean_vector",f)} / uniforms.norm_size;
    let inv_std_dev = inverseSqrt(${_t("mean_square_vector",f)} / uniforms.norm_size ${i?"":"- mean * mean"} + uniforms.epsilon);

    for (var j: u32 = 0; j < uniforms.norm_size_vectorized; j++) {
      let f32input = ${jt(I,f,"x[j + offset]")};
      let f32scale = ${jt(I,f,"scale[j]")};
      output[j + offset] = ${C[0].type.value}((f32input ${i?"":"- mean"}) * inv_std_dev * f32scale
        ${s?`+ ${jt(I,f,"bias[j]")}`:""}
      );
    }

    ${x?"mean_data_output[global_idx] = mean":""};
    ${_?"inv_std_output[global_idx] = inv_std_dev":""};
  }`},k=[{dims:d,dataType:e[0].dataType}];return x&&k.push({dims:$,dataType:1}),_&&k.push({dims:$,dataType:1}),{name:"LayerNormalization",shaderCache:{hint:`${f};${r};${i}`,inputDependencies:y},getRunData:()=>({outputs:k,dispatchGroup:{x:Math.ceil(p/64)},programUniforms:v}),getShaderSource:S}},Pc=(e,t)=>{Hu(e.inputs),e.compute(Ku(e.inputs,t,e.outputCount))}}),Yu,Zu,Qu,Dc,Fc,Xm=F(()=>{"use strict";ee(),ae(),Te(),ne(),Yu=(e,t)=>{if(e.length<3||e.length>4)throw new Error("MatMulNBits requires 3 or 4 inputs");let r=e[0],i=r.dims.length;if(r.dims[i-1]!==t.k)throw new Error("The last dim of input shape does not match the k value");let a=Math.floor((t.k+t.blockSize-1)/t.blockSize),n=t.blockSize/8*t.bits,s=e[1];if(!R.areEqual(s.dims,[t.n,a,n]))throw new Error("The second inputs must be 3D tensor with shape N X nBlocksPerCol X blobSize");let d=e[2].dims;if(R.size(d)!==t.n*a)throw new Error("scales input size error.");if(e.length===4){let l=e[3].dims,p=t.bits>4?t.n*a:t.n*Math.floor((a+1)/2);if(R.size(l)!==p)throw new Error("zeroPoints input size error.")}},Zu=(e,t)=>{let r=e[0].dims,i=r.length,a=r[i-2],n=t.k,s=t.n,d=r.slice(0,i-2),l=R.size(d),p=e[1].dims[2]/4,h=e[0].dataType,u=Se(t.k),m=Se(p),$=Se(s),f=d.concat([a,s]),y=a>1&&s/$%2===0?2:1,v=R.size(f)/$/y,x=64,_=[],S=[l,a,n/u],k=R.convertShape(e[1].dims).slice();k.splice(-1,1,p/m),_.push(...G(S)),_.push(...G(k)),_.push(...G(e[2].dims)),e.length===4&&_.push(...G(R.convertShape(e[3].dims)));let T=[l,a,s/$];_.push(...G(T));let I=C=>{let M=S.length,N=P("a",e[0].dataType,M,u),W=P("b",12,k.length,m),J=P("scales",e[2].dataType,e[2].dims.length),K=[N,W,J],X=e.length===4?P("zero_points",12,e[3].dims.length):void 0;X&&K.push(X);let ie=T.length,ue=Y("output",e[0].dataType,ie,$),q=Ee(e[0].dataType),de=(()=>{switch(u){case 1:return`array<${q}, 8>`;case 2:return`mat4x2<${q}>`;case 4:return`mat2x4<${q}>`;default:throw new Error(`${u}-component is not supported.`)}})(),se=()=>{let O=`
          // reuse a data
            var input_offset = ${N.indicesToOffset(`${N.type.indices}(batch, row, word_offset)`)};
            var a_data: ${de};
            for (var j: u32 = 0; j < ${8/u}; j++) {
              a_data[j] = ${N.getByOffset("input_offset")};
              input_offset++;
            }
          `;for(let U=0;U<$*y;U++)O+=`
            b_value = ${m===1?`b${U}_data`:`b${U}_data[i]`};
            b_value_lower = unpack4xU8(b_value & b_mask);
            b_value_upper = unpack4xU8((b_value >> 4) & b_mask);
            b_quantized_values = ${de}(${Array.from({length:4},(te,fe)=>`${q}(b_value_lower[${fe}]), ${q}(b_value_upper[${fe}])`).join(", ")});
            b_dequantized_values = ${u===1?`${de}(${Array.from({length:8},(te,fe)=>`(b_quantized_values[${fe}] - ${X?`zero_point${U}`:"zero_point"}) * scale${U}`).join(", ")});`:`(b_quantized_values - ${de}(${Array(8).fill(`${X?`zero_point${U}`:"zero_point"}`).join(",")})) * scale${U};`};
            workgroup_shared[local_id.x * ${y} + ${Math.floor(U/$)}]${$>1?`[${U%$}]`:""} += ${Array.from({length:8/u},(te,fe)=>`${u===1?`a_data[${fe}] * b_dequantized_values[${fe}]`:`dot(a_data[${fe}], b_dequantized_values[${fe}])`}`).join(" + ")};
          `;return O},j=()=>{let O=`
            var col_index = col * ${$};
            ${X?`
            let zero_point_bytes_per_col = (nBlocksPerCol + 1) / 2;
            var zero_point_byte_count: u32;
            var zero_point_word_index: u32;
            var zero_point_byte_offset: u32;
            let zero_point_nibble_offset: u32 = block & 0x1u;
            var zero_point_bits_offset: u32;
            var zero_point_word: u32;`:`
            // The default zero point is 8 for unsigned 4-bit quantization.
            let zero_point = ${q}(8);`}
            `;for(let U=0;U<$*y;U++)O+=`
            let scale${U} = ${J.getByOffset("col_index * nBlocksPerCol + block")};
            ${X?`
            zero_point_byte_count = col_index * zero_point_bytes_per_col + (block >> 0x1u);
            zero_point_word_index = zero_point_byte_count >> 0x2u;
            zero_point_byte_offset = zero_point_byte_count & 0x3u;
            zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_nibble_offset << 2);
            zero_point_word = ${X.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point${U} = ${q}((zero_point_word) & 0xFu);`:""}
            col_index += 1;`;return O},re=()=>{let O=`col_index = col * ${$};`;for(let U=0;U<$*y;U++)O+=`
            let b${U}_data = ${W.getByIndices(`${W.type.indices}(col_index, block, word)`)};
            col_index += 1;`;return O+=`
            var b_value: u32;
            let b_mask: u32 = 0x0F0F0F0Fu;
            var b_value_lower: vec4<u32>;
            var b_value_upper: vec4<u32>;
            var b_quantized_values: ${de};
            var b_dequantized_values: ${de};`,O};return`
        var<workgroup> workgroup_shared: array<${ue.type.value}, ${y*x}>;
        ${C.declareVariables(...K,ue)}
        ${C.mainStart([x,1,1])}
          let output_indices = ${ue.offsetToIndices(`(global_idx / ${x}) * ${y}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let nBlocksPerCol = uniforms.b_shape[1];

          for (var block = local_id.x; block < nBlocksPerCol; block += ${x}) {
            //process one block
            var word_offset: u32 = block * ${t.blockSize/u};
            ${j()}
            for (var word: u32 = 0; word < ${p}; word += ${m}) {
              ${re()}
              for (var i: u32 = 0; i < ${m}; i++) {
                ${se()}
                word_offset += ${8/u};
              }
            }
          }
          workgroupBarrier();

          if (local_id.x < ${y}) {
            var output_value: ${ue.type.value} = ${ue.type.value}(0);
            var workgroup_shared_offset: u32 = local_id.x;
            for (var b: u32 = 0u; b < ${x}u; b++) {
              output_value += workgroup_shared[workgroup_shared_offset];
              workgroup_shared_offset += ${y};
            }
            ${ue.setByIndices(`${ue.type.indices}(batch, row, col + local_id.x)`,"output_value")};
          }
        }`};return{name:"MatMulNBits",shaderCache:{hint:`${t.blockSize};${t.bits};${u};${m};${$};${y};${x}`,inputDependencies:Array(e.length).fill("rank")},getRunData:()=>({outputs:[{dims:f,dataType:h}],dispatchGroup:{x:v},programUniforms:_}),getShaderSource:I}},Qu=(e,t)=>{let r=e[0].dims,i=r.length,a=r[i-2],n=t.k,s=t.n,d=r.slice(0,i-2),l=R.size(d),p=e[1].dims[2]/4,h=e[0].dataType,u=Se(t.k),m=Se(p),$=d.concat([a,s]),f=128,y=s%8===0?8:s%4===0?4:1,v=f/y,x=v*m*8,_=x/u,S=x/t.blockSize,k=R.size($)/y,T=[],I=[l,a,n/u],C=R.convertShape(e[1].dims).slice();C.splice(-1,1,p/m),T.push(...G(I)),T.push(...G(C)),T.push(...G(e[2].dims)),e.length===4&&T.push(...G(R.convertShape(e[3].dims)));let M=[l,a,s];T.push(...G(M));let N=W=>{let J=I.length,K=P("a",e[0].dataType,J,u),X=P("b",12,C.length,m),ie=P("scales",e[2].dataType,e[2].dims.length),ue=[K,X,ie],q=e.length===4?P("zero_points",12,e[3].dims.length):void 0;q&&ue.push(q);let de=M.length,se=Y("output",e[0].dataType,de),j=Ee(e[0].dataType),re=()=>{switch(u){case 1:return`
          let a_data0 = vec4<${j}>(sub_a[word_offset], sub_a[word_offset + 1], sub_a[word_offset + 2], sub_a[word_offset + 3]);
          let a_data1 = vec4<${j}>(sub_a[word_offset + 4], sub_a[word_offset + 5], sub_a[word_offset + 6], sub_a[word_offset + 7]);`;case 2:return`
          let a_data0 = vec4<${j}>(sub_a[word_offset], sub_a[word_offset + 1]);
          let a_data1 = vec4<${j}>(sub_a[word_offset + 2], sub_a[word_offset + 3]);`;case 4:return`
          let a_data0 = sub_a[word_offset];
          let a_data1 = sub_a[word_offset + 1];`;default:throw new Error(`${u}-component is not supported.`)}};return`
        var<workgroup> sub_a: array<${K.type.value}, ${_}>;
        var<workgroup> inter_results: array<array<${se.type.value}, ${v}>, ${y}>;
        ${W.declareVariables(...ue,se)}
        ${W.mainStart([v,y,1])}
          let output_indices = ${se.offsetToIndices(`workgroup_index * ${y}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let n_blocks_per_col = uniforms.b_shape[1];
          let num_tiles =  (n_blocks_per_col - 1) / ${S} + 1;

          // Loop over shared dimension.
          for (var tile: u32 = 0; tile < num_tiles; tile += 1) {
            let a_col_start = tile * ${_};
            // load one tile A data into shared memory.
            for (var a_offset = local_idx; a_offset < ${_}; a_offset += ${f})
            {
              let a_col = a_col_start + a_offset;
              if (a_col < uniforms.a_shape[2])
              {
                sub_a[a_offset] = ${K.getByIndices(`${K.type.indices}(batch, row, a_col)`)};
              } else {
                sub_a[a_offset] = ${K.type.value}(0);
              }
            }
            workgroupBarrier();

            // each thread process one block
            let b_row = col + local_id.y;
            let block = tile * ${S} + local_id.x;
            ${q?`
            let zero_point_bytes_per_col = (n_blocks_per_col + 1) / 2;
            let zero_point_byte_count = b_row * zero_point_bytes_per_col + (block >> 0x1u);
            let zero_point_word_index = zero_point_byte_count >> 0x2u;
            let zero_point_byte_offset = zero_point_byte_count & 0x3u;
            let zero_point_nibble_offset: u32 = block & 0x1u;
            let zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_nibble_offset << 2);
            let zero_point_word = ${q.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point = ${j}((zero_point_word) & 0xFu);`:`
            // The default zero point is 8 for unsigned 4-bit quantization.
            let zero_point = ${j}(8);`}
            let scale = ${ie.getByOffset("b_row * n_blocks_per_col + block")};
            let b_data = ${X.getByIndices(`${X.type.indices}(b_row, block, 0)`)};
            var word_offset = local_id.x * ${t.blockSize/u};
            for (var i: u32 = 0; i < ${m}; i++) {
              ${re()}
              let b_value = ${m===1?"b_data":"b_data[i]"};
              let b_value_lower = unpack4xU8(b_value & 0x0F0F0F0Fu);
              let b_value_upper = unpack4xU8((b_value >> 4) & 0x0F0F0F0Fu);
              let b_quantized_values = mat2x4<${j}>(${Array.from({length:4},(O,U)=>`${j}(b_value_lower[${U}]), ${j}(b_value_upper[${U}])`).join(", ")});
              let b_dequantized_values = (b_quantized_values - mat2x4<${j}>(${Array(8).fill("zero_point").join(",")})) * scale;
              inter_results[local_id.y][local_id.x] += ${Array.from({length:2},(O,U)=>`${`dot(a_data${U}, b_dequantized_values[${U}])`}`).join(" + ")};
              word_offset += ${8/u};
            }
            workgroupBarrier();
          }

          if (local_idx < ${y}) {
            var output_value: ${se.type.value} = ${se.type.value}(0);
            for (var b = 0u; b < ${v}; b++) {
              output_value += inter_results[local_idx][b];
            }
            if (col + local_idx < uniforms.output_shape[2])
            {
              ${se.setByIndices(`${se.type.indices}(batch, row, col + local_idx)`,"output_value")}
            }
          }
        }`};return{name:"BlockwiseMatMulNBits32",shaderCache:{hint:`${t.blockSize};${u};${m};${v};${y}`,inputDependencies:Array(e.length).fill("rank")},getRunData:()=>({outputs:[{dims:$,dataType:h}],dispatchGroup:{x:k},programUniforms:T}),getShaderSource:N}},Dc=(e,t)=>{Yu(e.inputs,t),t.blockSize===32&&e.adapterInfo.isVendor("intel")&&e.adapterInfo.isArchitecture("gen-12lp")?e.compute(Qu(e.inputs,t)):e.compute(Zu(e.inputs,t))},Fc=e=>we(e)}),Xu,Ju,el,tl,rl,il,al,nl,Uc,Jm=F(()=>{"use strict";ee(),ae(),ne(),Xu=e=>{if(!e||e.length<1)throw new Error("Too few inputs");if(e[0].dataType!==1&&e[0].dataType!==10)throw new Error("Input type must be float or float16.");if(e.length>=2){let t=e[0].dims.length*2===e[1].dims[0];if(e.length===4&&(t=e[3].dims[0]*2===e[1].dims[0]),!t)throw new Error("The pads should be a 1D tensor of shape [2 * input_rank] or [2 * num_axes].")}},Ju=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
            k = i32(${e.indicesGet("indices",a)}) - ${H("uniforms.pads",a,r)};
            if (k < 0) {
              break;
            }
            if (k >= i32(${H("uniforms.x_shape",a,t)})) {
              break;
            }
            offset += k * i32(${H("uniforms.x_strides",a,t)});
        `;return`
          value = ${e.type.value}(uniforms.constant_value);
          for (var i = 0; i < 1; i++) {
            var offset = 0;
            var k = 0;
            ${i}
            value = x[offset];
          }
      `},el=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${H("uniforms.pads",a,r)};
                if (k < 0) {
                  k = -k;
                }
                {
                  let _2n_1 = 2 * (i32(${H("uniforms.x_shape",a,t)}) - 1);
                  k = k % _2n_1;
                  if(k >= i32(${H("uniforms.x_shape",a,t)})) {
                    k = _2n_1 - k;
                  }
                }
                offset += k * i32(${H("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},tl=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${H("uniforms.pads",a,r)};
                if (k < 0) {
                  k = 0;
                }
                if (k >= i32(${H("uniforms.x_shape",a,t)})) {
                  k = i32(${H("uniforms.x_shape",a,t)}) - 1;
                }
                offset += k * i32(${H("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},rl=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${H("uniforms.pads",a,r)};
                if (k < 0)  {
                  k += i32(${H("uniforms.x_shape",a,t)}]);
                }
                if (k >= i32(${H("uniforms.x_shape",a,t)})) {
                  k -= i32(${H("uniforms.x_shape",a,t)});
                }
                offset += k * i32(${H("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},il=(e,t,r)=>{switch(r.mode){case 0:return Ju(e,t,r.pads.length);case 1:return el(e,t,r.pads.length);case 2:return tl(e,t,r.pads.length);case 3:return rl(e,t,r.pads.length);default:throw new Error("Invalid mode")}},al=(e,t)=>{let r=R.padShape(e[0].dims.slice(),t.pads),i=e[0].dims,a=R.size(r),n=[{type:12,data:a},{type:6,data:t.pads}],s=e.length>=3&&e[2].data;t.mode===0&&n.push({type:s?e[2].dataType:1,data:t.value}),n.push(...G(e[0].dims,r));let d=["rank"],l=p=>{let h=Y("output",e[0].dataType,r.length),u=P("x",e[0].dataType,i.length),m=u.type.value,$=il(h,i.length,t),f=[{name:"output_size",type:"u32"},{name:"pads",type:"i32",length:t.pads.length}];return t.mode===0&&f.push({name:"constant_value",type:s?m:"f32"}),`
            ${p.registerUniforms(f).declareVariables(u,h)}
            ${p.mainStart()}
            ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

            let indices = ${h.offsetToIndices("global_idx")};

            var value = ${m}(0);
            ${$}
            output[global_idx] = value;
        }`};return{name:"Pad",shaderCache:{hint:`${t.mode}${s}`,inputDependencies:d},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(R.size(r)/64)},programUniforms:n}),getShaderSource:l}},nl=(e,t)=>{if(e.length>1){let r=e[1].getBigInt64Array(),i=e.length>=3&&e[2].data?e[2].dataType===10?e[2].getUint16Array()[0]:e[2].getFloat32Array()[0]:0,a=e[0].dims.length,n=new Int32Array(2*a).fill(0);if(e.length>=4){let d=e[3].getBigInt64Array();for(let l=0;l<d.length;l++)n[Number(d[l])]=Number(r[l]),n[Number(d[l])+a]=Number(r[l+d.length])}else r.forEach((d,l)=>n[Number(l)]=Number(d));let s=[];return n.forEach(d=>s.push(d)),{mode:t.mode,value:i,pads:s}}else return t},Uc=(e,t)=>{Xu(e.inputs);let r=nl(e.inputs,t);e.compute(al(e.inputs,r),{inputs:[0]})}}),er,ea,ta,ra,ia,sl,ol,aa,na,Nc,Wc,sa,Lc,qc,oa,Vc,jc,Gc,Hc,eg=F(()=>{"use strict";tt(),ee(),ae(),ne(),er=e=>{if(ge.webgpu.validateInputContent&&(!e||e.length!==1))throw new Error("Pool ops requires 1 input.")},ea=(e,t,r)=>{let i=t.format==="NHWC",a=e.dims.slice();i&&a.splice(1,0,a.pop());let n=Object.hasOwnProperty.call(t,"dilations"),s=t.kernelShape.slice(),d=t.strides.slice(),l=n?t.dilations.slice():[],p=t.pads.slice();Gr.adjustPoolAttributes(r,a,s,d,l,p);let h=Gr.computePoolOutputShape(r,a,d,l,s,p,t.autoPad),u=Object.assign({},t);n?Object.assign(u,{kernelShape:s,strides:d,pads:p,dilations:l,cacheKey:t.cacheKey}):Object.assign(u,{kernelShape:s,strides:d,pads:p,cacheKey:t.cacheKey});let m=h.slice();return m.push(m.splice(1,1)[0]),[u,i?m:h]},ta=(e,t)=>{let r=t.format==="NHWC",i=R.size(e),a=R.size(t.kernelShape),n=[{type:12,data:i},{type:12,data:a}],s=[{name:"outputSize",type:"u32"},{name:"kernelSize",type:"u32"}];if(t.kernelShape.length<=2){let d=t.kernelShape[t.kernelShape.length-1],l=t.strides[t.strides.length-1],p=t.pads[t.pads.length/2-1],h=t.pads[t.pads.length-1],u=!!(p+h);n.push({type:12,data:d},{type:12,data:l},{type:12,data:p},{type:12,data:h}),s.push({name:"kw",type:"u32"},{name:"sw",type:"u32"},{name:"pwStart",type:"u32"},{name:"pwEnd",type:"u32"});let m=!1;if(t.kernelShape.length===2){let $=t.kernelShape[t.kernelShape.length-2],f=t.strides[t.strides.length-2],y=t.pads[t.pads.length/2-2],v=t.pads[t.pads.length-2];m=!!(y+v),n.push({type:12,data:$},{type:12,data:f},{type:12,data:y},{type:12,data:v}),s.push({name:"kh",type:"u32"},{name:"sh",type:"u32"},{name:"phStart",type:"u32"},{name:"phEnd",type:"u32"})}return[n,s,!0,u,m]}else{if(r)throw new Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let d=R.computeStrides(t.kernelShape);n.push({type:12,data:d},{type:12,data:t.pads},{type:12,data:t.strides}),s.push({name:"kernelStrides",type:"u32",length:d.length},{name:"pads",type:"u32",length:t.pads.length},{name:"strides",type:"u32",length:t.strides.length});let l=t.pads.reduce((p,h)=>p+h);return[n,s,!!l,!1,!1]}},ra=(e,t,r,i,a,n,s,d,l,p,h,u)=>{let m=a.format==="NHWC",$=t.type.value,f=Y("output",t.type.tensor,i);if(a.kernelShape.length<=2){let y="",v="",x="",_=r-(m?2:1);if(h?y=`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${_}] = indices[${_}] * uniforms.sw - uniforms.pwStart + i;
                  if (xIndices[${_}] < 0 || xIndices[${_}]
                      >= uniforms.x_shape[${_}]) {
                    pad++;
                    continue;
                  }
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${n}
                }`:y=`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${_}] = indices[${_}] * uniforms.sw - uniforms.pwStart + i;
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${n}
                }`,a.kernelShape.length===2){let S=r-(m?3:2);u?v=`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${S}] = indices[${S}] * uniforms.sh - uniforms.phStart + j;
                  if (xIndices[${S}] < 0 || xIndices[${S}] >= uniforms.x_shape[${S}]) {
                    pad += i32(uniforms.kw);
                    continue;
                  }
              `:v=`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${S}] = indices[${S}] * uniforms.sh - uniforms.phStart + j;
                `,x=`
              }
            `}return`
            ${e.registerUniforms(l).declareVariables(t,f)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

              let indices = ${f.offsetToIndices("global_idx")};
              var xIndices = ${f.offsetToIndices("global_idx")};

              var value = ${$}(${d});
              var pad = 0;
              ${v}
              ${y}
              ${x}
              ${s}

              output[global_idx] = value;
            }`}else{if(m)throw new Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let y=a.kernelShape.length,v=a.pads.length,x="";return p?x=`
                if (xIndices[j] >= uniforms.x_shape[j]) {
                  pad++;
                  isPad = true;
                  break;
                }
              }
              if (!isPad) {
                let x_val = x[${t.indicesToOffset("xIndices")}];
                ${n}
              }`:x=`
              }
              let x_val = x[${t.indicesToOffset("xIndices")}];
              ${n}
            `,`
            ${e.registerUniforms(l).declareVariables(t,f)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
              let indices = ${f.offsetToIndices("global_idx")};
              var xIndices = ${f.offsetToIndices("global_idx")};

              var offsets: array<u32, ${y}>;

              var value = ${$}(${d});
              var pad = 0;
              var isPad = false;

              for (var i: u32 = 0u; i < uniforms.kernelSize; i++) {
                var offset = i;
                for (var j = 0u; j < ${y-1}u; j++) {
                  offsets[j] = offset / ${H("uniforms.kernelStrides","j",y)};
                  offset -= offsets[j] * ${H("uniforms.kernelStrides","j",y)};
                }
                offsets[${y-1}] = offset;

                isPad = false;
                for (var j = ${r-y}u; j < ${r}u; j++) {
                  xIndices[j] = indices[j] * ${H("uniforms.strides",`j - ${r-y}u`,y)}
                    + offsets[j - ${r-y}u] - ${H("uniforms.pads","j - 2u",v)};
                  ${x}
              }
              ${s}

              output[global_idx] = value;
            }`}},ia=e=>`${e.format};${e.ceilMode};${e.autoPad};${e.kernelShape.length}`,sl=e=>`${ia(e)};${e.countIncludePad}`,ol=e=>`${ia(e)};${e.storageOrder};${e.dilations}`,aa=e=>({format:e.format,autoPad:["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],ceilMode:e.ceil_mode,kernelShape:e.kernel_shape,strides:e.strides,pads:e.pads}),na=(e,t,r,i)=>{let[a,n]=ea(t,i,r),s=P("x",t.dataType,t.dims.length),d=s.type.value,l="value += x_val;",p="";a.countIncludePad?p+=`value /= ${d}(uniforms.kernelSize);`:p+=`value /= ${d}(i32(uniforms.kernelSize) - pad);`;let[h,u,m,$,f]=ta(n,a);h.push(...G(t.dims,n));let y=["rank"];return{name:e,shaderCache:{hint:`${i.cacheKey};${m};${$};${f}`,inputDependencies:y},getRunData:()=>({outputs:[{dims:n,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(R.size(n)/64)},programUniforms:h}),getShaderSource:v=>ra(v,s,t.dims.length,n.length,a,l,p,0,u,m,$,f)}},Nc=e=>{let t=e.count_include_pad!==0,r=aa(e);if(r.ceilMode!==0)throw new Error("using ceil() in shape computation is not yet supported for AveragePool");let i={countIncludePad:t,...r,cacheKey:""};return{...i,cacheKey:sl(i)}},Wc=(e,t)=>{er(e.inputs),e.compute(na("AveragePool",e.inputs[0],!1,t))},sa={autoPad:"",ceilMode:0,countIncludePad:!1,kernelShape:[],strides:[],pads:[],storageOrder:0,dilations:[]},Lc=e=>{let t=e.format;return{format:t,...sa,cacheKey:t}},qc=(e,t)=>{er(e.inputs),e.compute(na("GlobalAveragePool",e.inputs[0],!0,t))},oa=(e,t,r,i)=>{let[a,n]=ea(t,i,r),s=`
      value = max(x_val, value);
    `,d="",l=P("x",t.dataType,t.dims.length),p=["rank"],[h,u,m,$,f]=ta(n,a);return h.push(...G(t.dims,n)),{name:e,shaderCache:{hint:`${i.cacheKey};${m};${$};${f}`,inputDependencies:p},getRunData:()=>({outputs:[{dims:n,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(R.size(n)/64)},programUniforms:h}),getShaderSource:y=>ra(y,l,t.dims.length,n.length,a,s,d,t.dataType===10?-65504:-1e5,u,m,$,f)}},Vc=(e,t)=>{er(e.inputs),e.compute(oa("MaxPool",e.inputs[0],!1,t))},jc=e=>{let t=e.storage_order,r=e.dilations,i=aa(e);if(t!==0)throw new Error("column major storage order is not yet supported for MaxPool");if(i.ceilMode!==0)throw new Error("using ceil() in shape computation is not yet supported for MaxPool");let a={storageOrder:t,dilations:r,...i,cacheKey:""};return{...a,cacheKey:ol(a)}},Gc=e=>{let t=e.format;return{format:t,...sa,cacheKey:t}},Hc=(e,t)=>{er(e.inputs),e.compute(oa("GlobalMaxPool",e.inputs[0],!0,t))}}),ul,ll,Kc,Yc,tg=F(()=>{"use strict";ee(),ae(),Te(),ne(),ul=(e,t)=>{if(e.length<2||e.length>3)throw new Error("DequantizeLinear requires 2 or 3 inputs.");if(e.length===3&&e[1].dims===e[2].dims)throw new Error("x-scale and x-zero-point must have the same shape.");if(e.length===3&&e[0].dataType!==e[2].dataType)throw new Error("x and x-zero-point must have the same data type.");if(e[0].dataType===6&&e.length>2)throw new Error("In the case of dequantizing int32 there is no zero point.");if(e[1].dims.length!==0&&e[1].dims.length!==1&&e[1].dims.length!==e[0].dims.length)throw new Error("scale input must be a scalar, a 1D tensor, or have the same rank as the input tensor.");if(e.length>2){if(e[0].dataType!==e[2].dataType)throw new Error("x and x-zero-point must have the same data type.");if(e[1].dims.length!==e[2].dims.length)throw new Error("scale and zero-point inputs must have the same rank.");if(!e[1].dims.map((r,i)=>r===e[2].dims[i]).reduce((r,i)=>r&&i,!0))throw new Error("scale and zero-point inputs must have the same shape.")}if(t.blockSize>0){if(e[1].dims.length===0||e[1].dims.length===1&&e[1].dims[0]===1)throw new Error("blockSize must be set only for block quantization.");if(!e[1].dims.map((a,n)=>n===t.axis||a===e[0].dims[n]).reduce((a,n)=>a&&n,!0))throw new Error("For block qunatization, scale input shape to match the input shape except for the axis");if(e[1].dims.length!==e[0].dims.length)throw new Error("For block qunatization the scale input rank must be the same as the x rank.");let r=e[0].dims[t.axis],i=e[1].dims[t.axis];if(t.blockSize<Math.ceil(r/i)||t.blockSize>Math.ceil(r/(i-1)-1))throw new Error("blockSize must be with in the range [ceil(dI / Si), ceil(dI / (Si - 1) - 1)].")}},ll=(e,t)=>{let r=R.normalizeAxis(t.axis,e[0].dims.length),i=e[0].dataType,a=i===3,n=e[0].dims,s=e[1].dataType,d=R.size(n),l=i===3||i===2,p=l?[Math.ceil(R.size(e[0].dims)/4)]:e[0].dims,h=e[1].dims,u=e.length>2?e[2]:void 0,m=u?l?[Math.ceil(R.size(u.dims)/4)]:u.dims:void 0,$=h.length===0||h.length===1&&h[0]===1,f=$===!1&&h.length===1,y=Se(d),v=$&&(!l||y===4),x=v?y:1,_=v&&!l?y:1,S=P("input",l?12:i,p.length,_),k=P("scale",s,h.length),T=u?P("zero_point",l?12:i,m.length):void 0,I=Y("output",s,n.length,x),C=[S,k];T&&C.push(T);let M=[p,h];u&&M.push(m);let N=[{type:12,data:d/x},{type:12,data:r},{type:12,data:t.blockSize},...G(...M,n)],W=J=>{let K=[{name:"output_size",type:"u32"},{name:"axis",type:"u32"},{name:"block_size",type:"u32"}];return`
      ${J.registerUniforms(K).declareVariables(...C,I)}
      ${J.mainStart()}
          ${J.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let output_indices = ${I.offsetToIndices("global_idx")};

          // Set input x
          ${l?`
            let input = ${S.getByOffset("global_idx / 4")};
            let x_vec = ${a?"unpack4xI8(input)":"unpack4xU8(input)"};
            let x_value = ${x===1?"x_vec[global_idx % 4]":"x_vec"};`:`let x_value = ${S.getByOffset("global_idx")};`};

          // Set scale input
          ${$?`let scale_value= ${k.getByOffset("0")}`:f?`
            let scale_index = ${I.indicesGet("output_indices","uniforms.axis")};
            let scale_value= ${k.getByOffset("scale_index")};`:`
            var scale_indices: ${k.type.indices} = output_indices;
            let index = ${k.indicesGet("scale_indices","uniforms.axis")} / uniforms.block_size;
            ${k.indicesSet("scale_indices","uniforms.axis","index")};
            let scale_value= ${k.getByIndices("scale_indices")};`};

          // Set zero-point input
          ${T?$?l?`
                let zero_point_input = ${T.getByOffset("0")};
                let zero_point_vec =  ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value= zero_point_vec[0]`:`let zero_point_value = ${T.getByOffset("0")}`:f?l?`
                let zero_point_index = ${I.indicesGet("output_indices","uniforms.axis")};
                let zero_point_input = ${T.getByOffset("zero_point_index / 4")};
                let zero_point_vec =  ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_index % 4]`:`
                let zero_point_index = ${I.indicesGet("output_indices","uniforms.axis")};
                let zero_point_value = ${T.getByOffset("zero_point_index")};`:l?`
                let zero_point_offset = ${k.indicesToOffset("scale_indices")};
                let zero_point_input = ${T.getByOffset("zero_point_offset / 4")};
                let zero_point_vec = ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_offset % 4];`:`let zero_point_value = ${T.getByIndices("scale_indices")};`:`let zero_point_value = ${l?a?"i32":"u32":S.type.value}(0);`};
      // Compute and write output
      ${I.setByOffset("global_idx",`${I.type.value}(x_value - zero_point_value) * scale_value`)};
      }`};return{name:"DequantizeLinear",shaderCache:{hint:t.cacheKey,inputDependencies:T?["rank","rank","rank"]:["rank","rank"]},getShaderSource:W,getRunData:()=>({outputs:[{dims:n,dataType:s}],dispatchGroup:{x:Math.ceil(d/x/64),y:1,z:1},programUniforms:N})}},Kc=(e,t)=>{ul(e.inputs,t),e.compute(ll(e.inputs,t))},Yc=e=>we({axis:e.axis,blockSize:e.blockSize})}),dl,pl,Zc,rg=F(()=>{"use strict";tt(),ee(),ne(),dl=(e,t,r)=>{let i=e===t,a=e<t&&r<0,n=e>t&&r>0;if(i||a||n)throw new Error("Range these inputs' contents are invalid.")},pl=(e,t,r,i)=>{let a=Math.abs(Math.ceil((t-e)/r)),n=[a],s=a,d=[{type:12,data:s},{type:i,data:e},{type:i,data:r},...G(n)],l=p=>{let h=Y("output",i,n.length),u=h.type.value,m=[{name:"outputSize",type:"u32"},{name:"start",type:u},{name:"delta",type:u}];return`
        ${p.registerUniforms(m).declareVariables(h)}
        ${p.mainStart()}
        ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        output[global_idx] = uniforms.start + ${u}(global_idx) * uniforms.delta;
      }`};return{name:"Range",shaderCache:{hint:`${i}`},getShaderSource:l,getRunData:()=>({outputs:[{dims:n,dataType:i}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:d})}},Zc=e=>{let t=0,r=0,i=0;e.inputs[0].dataType===6?(t=e.inputs[0].getInt32Array()[0],r=e.inputs[1].getInt32Array()[0],i=e.inputs[2].getInt32Array()[0]):e.inputs[0].dataType===1&&(t=e.inputs[0].getFloat32Array()[0],r=e.inputs[1].getFloat32Array()[0],i=e.inputs[2].getFloat32Array()[0]),ge.webgpu.validateInputContent&&dl(t,r,i),e.compute(pl(t,r,i,e.inputs[0].dataType),{inputs:[]})}}),cl,hl,fl,ml,gl,yl,wl,$l,_l,bl,vl,ua,xl,Sl,kl,Tl,El,Qc,Xc,ig=F(()=>{"use strict";ee(),ae(),Te(),ne(),cl=(e,t)=>{if(e.every(r=>r>0||(()=>{throw new Error("Resize requires scales input values to be positive")})),e.length>0){if(t.mode==="linear"){if(!(e.length===2||e.length===3||e.length===4&&e[0]===1&&e[1]===1||e.length===4&&e[0]===1&&e[3]===1||e.length===5&&e[0]===1&&e[1]===1))throw new Error(`For linear mode, Resize requires scales to be 2D, 3D, 4D with either two outermost or one innermost and
            one outermost scale values equal to 1, or 5D with two outermost scale values equal to 1`)}else if(t.mode==="cubic"&&!(e.length===2||e.length===4&&e[0]===1&&e[1]===1||e.length===4&&e[0]===1&&e[3]===1))throw new Error("Resize requires scales input size to be 2 or 4 for cubic mode")}},hl=(e,t,r)=>{t.every(a=>a>=0&&a<r||(()=>{throw new Error("Resize requires axes input values to be positive and less than rank")}));let i=new Array(r).fill(1);return t.forEach((a,n)=>i[a]=e[n]),i},fl=(e,t,r,i,a,n)=>{let[s,d,l]=r>10?[1,2,3]:[-1,e.length>1?1:-1,-1],p=e[0].dims.length;if(s>0&&e.length>s&&e[s].dims.length>0)e[s].getFloat32Array().forEach(h=>n.push(h));else if(t.coordinateTransformMode==="tf_crop_and_resize")throw new Error("Resize requires RoI input to be specified when coordinateTransformMode is tfCropAndResize");if(d>0&&e.length>d&&e[d].dims.length===1&&e[d].dims[0]>0){if(e[d].getFloat32Array().forEach(h=>i.push(h)),i.length!==0&&i.length!==p&&r>=18&&i.length!==t.axes.length)throw new Error("Resize requires scales input size to be same as input rank or axes size for opset 18 and up");cl(i,t),t.axes.length>0&&hl(i,t.axes,p).forEach((h,u)=>i[u]=h)}if(l>0&&e.length>l&&e[l].dims.length===1&&e[l].dims[0]>0&&(e[l].getBigInt64Array().forEach(h=>a.push(Number(h))),a.length!==0&&a.length!==p&&r>=18&&a.length!==t.axes.length))throw new Error("Resize requires sizes input size to be same as input rank or axes size for opset 18 and up");if(t.axes.length>0){if(i.length!==0&&i.length!==t.axes.length)throw new Error('Resize requires "scales" input size to be of axes rank when axes attributes is specified');if(a.length!==0&&a.length!==t.axes.length)throw new Error('Resize requires "sizes" input size to be of rank axes rank when axes attributes is specified')}if(typeof i<"u"&&typeof a<"u"&&i.length>0&&a.length>p)throw new Error("Resize requires only of scales or sizes to be specified")},ml=(e,t)=>`fn getOriginalCoordinateFromResizedCoordinate(xResized: u32, xScale: f32, lengthResized: u32,
     lengthOriginal: u32, roiStart: f32, roiEnd: f32) -> ${t} { `+(()=>{switch(e){case"asymmetric":return`return ${t}(xResized) / ${t}(xScale);`;case"pytorch_half_pixel":return`if (lengthResized > 1) {
                    return (${t}(xResized) + 0.5) / ${t}(xScale) - 0.5;
                  } else {
                    return 0.0;
                  }`;case"tf_half_pixel_for_nn":return`return (${t}(xResized) + 0.5) / ${t}(xScale);`;case"align_corners":return`if (lengthResized == 1) {
                    return 0.0;
                  } else {
                    // The whole part and the fractional part are calculated separately due to inaccuracy of floating
                    // point division. As an example, f32(21) / f32(7) may evaluate to 2.99... instead of 3, causing an
                    // offset-by-one error later in floor().
                    let whole = ${t}(xResized * (lengthOriginal - 1) / (lengthResized - 1));
                    let fract =
                        ${t}(xResized * (lengthOriginal - 1) % (lengthResized - 1)) / ${t}(lengthResized - 1);
                    return whole + fract;
                  }`;case"tf_crop_and_resize":return`if (lengthResized > 1) {
                    return ${t}(roiStart) * ${t}(lengthOriginal - 1) +
                        (${t}(xResized) * ${t}(roiEnd - roiStart) * ${t}(lengthOriginal - 1)) /
                        ${t}(lengthResized - 1);
                  } else {
                    return 0.5 * ${t}(roiStart + roiEnd) * ${t}(lengthOriginal - 1);
                  }`;case"half_pixel_symmetric":return`const outputWidth = ${t}xScale * ${t}(lengthResized);
                  const adjustment = ${t}(lengthResized) / outputWidth;
                  const center = ${t}(lengthOriginal) / 2;
                  const offset = center * (1 - adjustment);
                  return offset + ((${t}(xResized) + 0.5) / ${t}(xScale)) - 0.5;`;case"half_pixel":return`return ((${t}(xResized) + 0.5) / ${t}(xScale)) - 0.5;`;default:throw new Error(`Coordinate transform mode ${e} is not supported`)}})()+"}",gl=(e,t,r)=>`fn getNearestPixelFromOriginal(xOriginal: ${r}, isDownSample: bool) -> ${r} {`+(()=>{switch(e){case"round_prefer_ceil":return"if (fract(xOriginal) == 0.5) {             return ceil(xOriginal);           } else {             return round(xOriginal);           }";case"floor":return"return floor(xOriginal);";case"ceil":return"return ceil(xOriginal);";case"round_prefer_floor":return"if (fract(xOriginal) == 0.5) {                     return floor(xOriginal);                   } else {                     return round(xOriginal);                   }";case"simple":default:if(t<11)return"if (isDownSample)                     {                       return ceil(xOriginal);                     } else {                       return xOriginal;                     }";throw new Error(`Nearest mode ${e} is not supported`)}})()+"}",yl=(e,t,r)=>{let i=new Array(r).fill(0).concat(new Array(r).fill(1)),a=e.length===0?i:e.slice();return t.length>0?(t.forEach((n,s)=>{i[n]=a[s],i[s+r]=a[t.length+s]}),i):a},wl=(e,t,r,i)=>{let a=[];if(r.length>0)if(i.length>0){if(e.forEach(n=>a.push(n)),Math.max(...i)>e.length)throw new Error("axes is out of bound");i.forEach((n,s)=>a[n]=r[s])}else r.forEach(n=>a.push(n));else{if(t.length===0)throw new Error("Resize requires either scales or sizes.");a=e.map((n,s)=>Math.round(n*t[s]))}return a},$l=(e,t,r)=>{let i=(()=>{switch(r.keepAspectRatioPolicy){case"not_larger":return r.axes.length>0?Math.min(...r.axes.map(n=>t[n]),Number.MAX_VALUE):Math.min(...t,Number.MAX_VALUE);case"not_smaller":return r.axes.length>0?Math.max(...r.axes.map(n=>t[n]),Number.MIN_VALUE):Math.max(...t,Number.MIN_VALUE);default:throw new Error(`Keep aspect ratio policy ${r.keepAspectRatioPolicy} is not supported`)}})();t.fill(1,0,t.length);let a=e.slice();return r.axes.length>0?(r.axes.forEach(n=>t[n]=i),r.axes.forEach(n=>a[n]=Math.round(e[n]*t[n]))):(t.fill(i,0,t.length),a.forEach((n,s)=>a[s]=Math.round(n*t[s]))),a},_l=(e,t,r,i,a)=>`
    fn calculateOriginalIndicesFromOutputIndices(output_indices: ${e.type.indices}) -> array<${e.type.value}, ${r.length}> {
      var original_indices: array<${e.type.value}, ${r.length}>;
      for (var i:u32 = 0; i < ${r.length}; i++) {
        var output_index = ${e.indicesGet("output_indices","i")};
        var scale = ${H("uniforms.scales","i",i)};
        var roi_low = ${H("uniforms.roi","i",a)};
        var roi_hi = ${H("uniforms.roi",`i + ${t.length}`,a)};
        if (scale == 1.0) {
          original_indices[i] = ${e.type.value}(output_index);
        } else {
          var input_shape_i = ${H("uniforms.input_shape","i",t.length)};
          var output_shape_i = ${H("uniforms.output_shape","i",r.length)};
          original_indices[i] = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                           input_shape_i, roi_low, roi_hi);
        }
      }
      return original_indices;
    }`,bl=(e,t,r,i,a,n,s)=>`
    fn calculateInputIndicesFromOutputIndices(output_indices: ${t.type.indices}) -> ${e.type.indices} {
      var input_indices: ${e.type.indices};
      for (var i:u32 = 0; i < ${i.length}; i++) {
        var output_index = ${t.indicesGet("output_indices","i")};
        var input_index: u32;
        var scale = ${H("uniforms.scales","i",a)};
        if (scale == 1.0) {
          input_index = output_index;
        } else {
          var roi_low = ${H("uniforms.roi","i",n)};
          var roi_hi = ${H("uniforms.roi",`i + ${r.length}`,n)};
          var input_shape_i = ${H("uniforms.input_shape","i",r.length)};
          var output_shape_i = ${H("uniforms.output_shape","i",i.length)};
          var original_idx = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                        input_shape_i, roi_low, roi_hi);
          if (!${s} || (original_idx >= 0 && original_idx < ${t.type.value}(input_shape_i))) {
            if (original_idx < 0) {
              input_index = 0;
            } else if (original_idx > ${t.type.value}(input_shape_i - 1)) {
              input_index = input_shape_i - 1;
            } else {
              input_index = u32(getNearestPixelFromOriginal(original_idx, scale < 1));
            }
          } else {
            input_index = u32(original_idx);
          }
        }
        ${e.indicesSet("input_indices","i"," input_index")}
      }
      return input_indices;
    }`,vl=(e,t)=>`
    fn checkInputIndices(input_indices: ${e.type.indices}) -> bool {
      for (var i:u32 = 0; i < ${t.length}; i++) {
        var input_index = ${e.indicesGet("input_indices","i")};
        if (input_index < 0 || input_index >= ${H("uniforms.input_shape","i",t.length)}) {
          return false;
        }
      }
      return true;
    }`,ua=(e,t,r,i)=>e.rank>i?`
    ${e.indicesSet("input_indices",t,"channel")};
    ${e.indicesSet("input_indices",r,"batch")};
`:"",xl=(e,t,r,i,a)=>{let[n,s,d,l]=r.length===2?[-1,0,1,-1]:[0,2,3,1],p=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, row: u32, col: u32) -> ${p} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",s,`max(0, min(row, ${r[s]} - 1))`)};
      ${e.indicesSet("input_indices",d,`max(0, min(col, ${r[d]} - 1))`)};
      ${ua(e,l,n,2)}
      return ${e.getByIndices("input_indices")};
    }

    fn bilinearInterpolation(output_indices: ${t.type.indices}) -> ${p} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var row:${p} = originalIndices[${s}];
      var col:${p} = originalIndices[${d}];
      ${i?`if (row < 0 || row > (${r[s]} - 1) || col < 0 || col > (${r[d]} - 1)) {
        return ${a};
      }`:""};
      row = max(0, min(row, ${r[s]} - 1));
      col = max(0, min(col, ${r[d]} - 1));
      var row1: u32 = u32(row);
      var col1: u32 = u32(col);
      var row2: u32 = u32(row + 1);
      var col2: u32 = u32(col + 1);
      var channel: u32 = ${r.length>2?`u32(originalIndices[${l}])`:"0"};
      var batch: u32 =  ${r.length>2?`u32(originalIndices[${n}])`:"0"};
      var x11: ${p} = getInputValue(batch, channel, row1, col1);
      var x12: ${p} = getInputValue(batch, channel, row1, col2);
      var x21: ${p} = getInputValue(batch, channel, row2, col1);
      var x22: ${p} = getInputValue(batch, channel, row2, col2);
      var dx1: ${p} = abs(row - ${p}(row1));
      var dx2: ${p} = abs(${p}(row2) - row);
      var dy1: ${p} = abs(col - ${p}(col1));
      var dy2: ${p} = abs(${p}(col2) - col);
      if (row1 == row2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (col1 == col2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      return (x11 * dx2 * dy2 + x12 * dx2 * dy1 + x21 * dx1 * dy2 + x22 * dx1 * dy1);
    }`},Sl=(e,t,r,i,a,n,s,d,l,p)=>{let h=r.length===2,u=!0,[m,$]=h?[0,1]:u?[2,3]:[1,2],f=e.type.value,y=v=>{let x=v===m?"row":"col";return`
      fn ${x}CubicInterpolation(input_indices: ${e.type.indices}, output_indices: ${t.type.indices}) -> ${f} {
        var output_index = ${t.indicesGet("output_indices",v)};
        var originalIdx: ${f} = getOriginalCoordinateFromResizedCoordinate(output_index, ${a[v]},
        ${i[v]}, ${r[v]}, ${n[v]}, ${n[v]} + ${r.length});
        var fractOriginalIdx: ${f} = originalIdx - floor(originalIdx);
        var coefs = getCubicInterpolationCoefs(fractOriginalIdx);

        if (${d} && (originalIdx < 0 || originalIdx > (${r[v]} - 1))) {
          return ${l};
        }
        var data: array<${f}, 4> = array<${f}, 4>(0.0, 0.0, 0.0, 0.0);
        for (var i: i32 = -1; i < 3; i++) {
          var ${x}: ${f} = originalIdx + ${f}(i);
          if (${x} < 0 || ${x} >= ${r[v]}) {
            ${p?`coefs[i + 1] = 0.0;
                        continue;`:d?`return ${l};`:`${x} = max(0, min(${x}, ${r[v]} - 1));`};
          }
        var input_indices_copy: ${e.type.indices} = input_indices;
          ${e.indicesSet("input_indices_copy",v,`u32(${x})`)};
          data[i + 1] = ${v===m?e.getByIndices("input_indices_copy"):"rowCubicInterpolation(input_indices_copy, output_indices)"};
        }
        return cubicInterpolation1D(data, coefs);
      }`};return`
    ${y(m)};
    ${y($)};
  fn getCubicInterpolationCoefs(s: ${f}) -> array<${f}, 4> {
    var absS = abs(s);
    var coeffs: array<${f}, 4> = array<${f}, 4>(0.0, 0.0, 0.0, 0.0);
    var oneMinusAbsS: ${f} = 1.0 - absS;
    var twoMinusAbsS: ${f} = 2.0 - absS;
    var onePlusAbsS: ${f} = 1.0 + absS;
    coeffs[0] = ((${s} * onePlusAbsS - 5 * ${s}) * onePlusAbsS + 8 * ${s}) * onePlusAbsS - 4 * ${s};
    coeffs[1] = ((${s} + 2) * absS - (${s} + 3)) * absS * absS + 1;
    coeffs[2] = ((${s} + 2) * oneMinusAbsS - (${s} + 3)) * oneMinusAbsS * oneMinusAbsS + 1;
    coeffs[3] = ((${s} * twoMinusAbsS - 5 * ${s}) * twoMinusAbsS + 8 * ${s}) * twoMinusAbsS - 4 * ${s};
    return coeffs;
  }

  fn cubicInterpolation1D(x: array<${f}, 4>, coefs: array<${f}, 4>) -> ${f} {
    var coefsSum: ${f} = coefs[0] + coefs[1] + coefs[2] + coefs[3];
    return (x[0] * coefs[0] + x[1] * coefs[1]+ x[2] * coefs[2]+ x[3] * coefs[3]) / coefsSum;
  }

  fn bicubicInterpolation(output_indices: ${t.type.indices}) -> ${f} {
    var input_indices: ${e.type.indices} = output_indices;
    return colCubicInterpolation(input_indices, output_indices);
  }
    `},kl=(e,t,r,i,a)=>{let[n,s,d,l,p]=r.length===3?[-1,0,1,2,-1]:[0,2,3,4,1],h=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, depth:u32, height: u32, width: u32) -> ${h} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",s,`max(0, min(depth, ${r[s]} - 1))`)};
      ${e.indicesSet("input_indices",d,`max(0, min(height, ${r[d]} - 1))`)};
      ${e.indicesSet("input_indices",l,`max(0, min(width, ${r[l]} - 1))`)};
      ${ua(e,p,n,3)}
      return ${e.getByIndices("input_indices")};
    }

    fn trilinearInterpolation(output_indices: ${t.type.indices}) -> ${h} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var depth:${h} = originalIndices[${s}];
      var height:${h} = originalIndices[${d}];
      var width:${h} = originalIndices[${l}];
      ${i?`if (depth < 0 || depth > (${r[s]} - 1) || height < 0 || height > (${r[d]} - 1) || width < 0 || (width > ${r[l]} - 1)) {
      return ${a};
        }`:""};

    depth = max(0, min(depth, ${r[s]} - 1));
      height = max(0, min(height, ${r[d]} - 1));
      width = max(0, min(width, ${r[l]} - 1));
      var depth1: u32 = u32(depth);
      var height1: u32 = u32(height);
      var width1: u32 = u32(width);
      var depth2: u32 = u32(depth + 1);
      var height2: u32 = u32(height + 1);
      var width2: u32 = u32(width + 1);
      var channel: u32 = ${r.length>3?`u32(originalIndices[${p}])`:"0"};
      var batch: u32 =  ${r.length>3?`u32(originalIndices[${n}])`:"0"};

      var x111: ${h} = getInputValue(batch, channel, depth1, height1, width1);
      var x112: ${h} = getInputValue(batch, channel, depth1, height1, width2);
      var x121: ${h} = getInputValue(batch, channel, depth1, height2, width1);
      var x122: ${h} = getInputValue(batch, channel, depth1, height2, width2);
      var x211: ${h} = getInputValue(batch, channel, depth2, height1, width1);
      var x212: ${h} = getInputValue(batch, channel, depth2, height1, width2);
      var x221: ${h} = getInputValue(batch, channel, depth2, height2, width1);
      var x222: ${h} = getInputValue(batch, channel, depth2, height2, width2);
      var dx1: ${h} = abs(depth - ${h}(depth1));
      var dx2: ${h} = abs(${h}(depth2) - depth);
      var dy1: ${h} = abs(height - ${h}(height1));
      var dy2: ${h} = abs(${h}(height2) - height);
      var dz1: ${h} = abs(width - ${h}(width1));
      var dz2: ${h} = abs(${h}(width2) - width);
      if (depth1 == depth2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (height1 == height2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      if (width1 == width2) {
        dz1 = 0.5;
        dz2 = 0.5;
      }
      return (x111 * dx2 * dy2 * dz2 + x112 * dx2 * dy2 * dz1 + x121 * dx2 * dy1 *dz2 + x122 * dx2 * dy1 * dz1 +
              x211 * dx1 * dy2 * dz2 + x212 * dx1 * dy2 * dz1 + x221 * dx1 * dy1 *dz2 + x222 * dx1 * dy1 * dz1);
    }`},Tl=(e,t,r,i,a,n)=>{let s=e.dims,d=yl(n,t.axes,s.length),l=wl(s,i,a,t.axes),p=i.slice();i.length===0&&(p=s.map((_,S)=>_===0?1:l[S]/_),t.keepAspectRatioPolicy!=="stretch"&&(l=$l(s,p,t)));let h=Y("output",e.dataType,l.length),u=P("input",e.dataType,s.length),m=R.size(l),$=s.length===l.length&&s.every((_,S)=>_===l[S]),f=t.coordinateTransformMode==="tf_crop_and_resize",y=t.extrapolationValue,v=u.type.value,x=_=>`
      ${$?"":`
      ${ml(t.coordinateTransformMode,v)};
      ${(()=>{switch(t.mode){case"nearest":return`
              ${vl(u,s)};
              ${gl(t.nearestMode,r,v)};
              ${bl(u,h,s,l,p.length,d.length,f)};
              `;case"linear":return`
              ${_l(h,s,l,p.length,d.length)};
              ${(()=>{if(s.length===2||s.length===4)return`${xl(u,h,s,f,y)}`;if(s.length===3||s.length===5)return`${kl(u,h,s,f,y)}`;throw Error("Linear mode only supports input dims 2, 3, 4 and 5 are supported in linear mode.")})()};
            `;case"cubic":return`
            ${(()=>{if(s.length===2||s.length===4)return`${Sl(u,h,s,l,p,d,t.cubicCoeffA,f,t.extrapolationValue,t.excludeOutside)}`;throw Error("Cubic mode only supports input dims 2 and 4 are supported in linear mode.")})()};
            `;default:throw Error("Invalid resize mode")}})()};
      `}
      ${_.registerUniform("output_size","u32").registerUniform("scales","f32",p.length).registerUniform("roi","f32",d.length).declareVariables(u,h)}
      ${_.mainStart()}
        ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
        ${$?"output[global_idx] = input[global_idx];":`
        let output_indices = ${h.offsetToIndices("global_idx")};
        var input_indices: ${u.type.indices};
        ${(()=>{switch(t.mode){case"nearest":return`input_indices = calculateInputIndicesFromOutputIndices(output_indices);
                if (checkInputIndices(input_indices)) {
                  output[global_idx] = ${u.getByIndices("input_indices")};
                } else {
                  output[global_idx] = ${t.extrapolationValue};
                }`;case"linear":return`output[global_idx] = ${s.length===2||s.length===4?"bilinearInterpolation":"trilinearInterpolation"}(output_indices);`;case"cubic":return"output[global_idx] = bicubicInterpolation(output_indices);";default:throw Error(`Unsupported resize mode: ${t.mode}`)}})()};
`}
      }`;return{name:"Resize",shaderCache:{hint:`${t.cacheKey}|${r}|${p.length>0?p:""}|${a.length>0?a:""}|${d.length>0?d:""}|${$}|${s}`,inputDependencies:["rank"]},getShaderSource:x,getRunData:()=>({outputs:[{dims:l,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(m/64)},programUniforms:[{type:12,data:m},{type:1,data:p},{type:1,data:d},...G(s,l)]})}},El=e=>{let t=e.customDataBuffer;return new Uint32Array(t,t.byteOffset,1)[0]},Qc=(e,t)=>{let r=[],i=[],a=[],n=El(e);if(t.antialias!==0)throw Error("Only default value (0) for Antialias attribute is supported");fl(e.inputs,t,n,r,i,a),e.compute(Tl(e.inputs[0],t,n,r,i,a),{inputs:[0]})},Xc=e=>{let t=e.antialias,r=e.axes,i=e.coordinateTransformMode,a=e.cubicCoeffA,n=e.excludeOutside!==0,s=e.extrapolationValue,d=e.keepAspectRatioPolicy,l=e.mode,p=e.nearestMode===""?"simple":e.nearestMode;return we({antialias:t,axes:r,coordinateTransformMode:i,cubicCoeffA:a,excludeOutside:n,extrapolationValue:s,keepAspectRatioPolicy:d,mode:l,nearestMode:p})}}),Cl,Il,Jc,ag=F(()=>{"use strict";ee(),ae(),Te(),ne(),Cl=(e,t)=>{let[r,i,a,n]=e,{numHeads:s,rotaryEmbeddingDim:d}=t;if(r.dims.length!==3&&r.dims.length!==4)throw new Error(`Input 'x' is expected to have 3 or 4 dimensions, got ${r.dims.length}`);if(!R.areEqual(i.dims,[])&&!R.areEqual(i.dims,[1])&&i.dims.length!==2)throw new Error(`Input 'position_ids' is expected to have 0, 1, or 2 dimensions, got ${i.dims.length}`);if(a.dims.length!==2)throw new Error(`Input 'cos_cache' is expected to have 2 dimensions, got ${a.dims.length}`);if(n.dims.length!==2)throw new Error(`Input 'sin_cache' is expected to have 2 dimensions, got ${n.dims.length}`);if(!R.areEqual(a.dims,n.dims))throw new Error("Inputs 'cos_cache' and 'sin_cache' are expected to have the same shape");if(d>0&&s===0)throw new Error("num_heads must be provided if rotary_embedding_dim is specified");let l=r.dims[0],p=r.dims[r.dims.length-2],h=a.dims[0],u=R.sizeFromDimension(r.dims,1)/p,m=d===0?a.dims[1]*2:u/s;if(d>m)throw new Error("rotary_embedding_dim must be less than or equal to head_size");if(i.dims.length===2){if(l!==i.dims[0])throw new Error(`Input 'position_ids' dimension 0 should be of size batch_size, got ${i.dims[0]}`);if(p!==i.dims[1])throw new Error(`Input 'position_ids' dimension 1 should be of size sequence_length, got ${i.dims[1]}`)}if(m/2!==a.dims[1]&&d/2!==a.dims[1])throw new Error(`Input 'cos_cache' dimension 1 should be same as head_size / 2 or rotary_embedding_dim / 2, got ${a.dims[1]}`);if(p>h)throw new Error("Updating cos_cache and sin_cache in RotaryEmbedding is not currently supported")},Il=(e,t)=>{let{interleaved:r,numHeads:i,rotaryEmbeddingDim:a,scale:n}=t,s=e[0].dims[0],d=R.sizeFromDimension(e[0].dims,1),l=e[0].dims[e[0].dims.length-2],p=d/l,h=e[2].dims[1],u=a===0?h*2:p/i,m=new Array(s,l,p/u,u-h),$=R.computeStrides(m),f=[{type:1,data:n},{type:12,data:m},{type:12,data:$},...e[0].dims.length===3?new Array({type:12,data:[d,p,u,1]}):[],...e[0].dims.length===4?new Array({type:12,data:[d,u,l*u,1]}):[],...G(e[0].dims,e[1].dims,e[2].dims,e[3].dims,e[0].dims)],y=v=>{let x=P("input",e[0].dataType,e[0].dims.length),_=P("position_ids",e[1].dataType,e[1].dims.length),S=P("cos_cache",e[2].dataType,e[2].dims.length),k=P("sin_cache",e[3].dataType,e[3].dims.length),T=Y("output",e[0].dataType,e[0].dims.length);return v.registerUniforms([{name:"scale",type:"f32"},{name:"global_shape",type:"u32",length:m.length},{name:"global_strides",type:"u32",length:$.length},{name:"input_output_strides",type:"u32",length:$.length}]),`
        ${v.declareVariables(x,_,S,k,T)}

        ${v.mainStart(Ht)}
          let half_rotary_emb_dim = uniforms.${S.name}_shape[1];
          let bsnh = global_idx / uniforms.global_strides % uniforms.global_shape;
          let size = uniforms.global_shape[0] * uniforms.global_strides[0];
          ${v.guardAgainstOutOfBoundsWorkgroupSizes("size")}

          if (bsnh[3] < half_rotary_emb_dim) {
            let position_ids_idx =
                ${_.broadcastedIndicesToOffset("bsnh.xy",Y("",_.type.tensor,2))};
            let position_id =
                u32(${_.getByOffset("position_ids_idx")}) + select(0, bsnh[1], position_ids_idx == 0);
            let i = dot(bsnh, uniforms.input_output_strides) + select(0, bsnh[3], ${r});
            let j = i + select(half_rotary_emb_dim, 1, ${r});
            let re = ${x.getByOffset("i")} * ${S.get("position_id","bsnh[3]")} -
                ${x.getByOffset("j")} * ${k.get("position_id","bsnh[3]")};
            ${T.setByOffset("i","re")}
            let im = ${x.getByOffset("i")} * ${k.get("position_id","bsnh[3]")} +
                ${x.getByOffset("j")} * ${S.get("position_id","bsnh[3]")};
            ${T.setByOffset("j","im")}
          } else {
            let k = dot(bsnh, uniforms.input_output_strides) + half_rotary_emb_dim;
            ${T.setByOffset("k",x.getByOffset("k"))}
          }
        }`};return{name:"RotaryEmbedding",shaderCache:{hint:we({interleaved:r}).cacheKey,inputDependencies:["rank","rank","rank","rank"]},getShaderSource:y,getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(R.size(m)/Ht)},programUniforms:f})}},Jc=(e,t)=>{Cl(e.inputs,t),e.compute(Il(e.inputs,t))}}),Al,zl,eh,ng=F(()=>{"use strict";ee(),ae(),ne(),Al=e=>{if(!e||e.length<3)throw new Error("layerNorm requires at least 3 inputs.");let t=e[0],r=e[1],i=e[2];if(t.dataType!==r.dataType||t.dataType!==i.dataType)throw new Error("All inputs must have the same data type");if(t.dims.length!==3&&t.dims.length!==2)throw new Error("Input must be 2D or 3D");if(r.dims.length!==3&&r.dims.length!==2)throw new Error("Skip must be 2D or 3D");let a=t.dims[t.dims.length-1],n=t.dims[t.dims.length-2];if(r.dims[r.dims.length-1]!==a)throw new Error("Skip must have the same hidden size as input");if(r.dims[r.dims.length-2]!==n)throw new Error("Skip must have the same sequence length as input");if(i.dims.length!==1)throw new Error("Gamma must be 1D");if(i.dims[i.dims.length-1]!==a)throw new Error("Gamma must have the same hidden size as input");if(e.length>3){let s=e[3];if(s.dims.length!==1)throw new Error("Beta must be 1D");if(s.dims[s.dims.length-1]!==a)throw new Error("Beta must have the same hidden size as input")}if(e.length>4){let s=e[4];if(s.dims.length!==1)throw new Error("Bias must be 1D");if(s.dims[s.dims.length-1]!==a)throw new Error("Bias must have the same hidden size as input")}},zl=(e,t,r,i)=>{let a=t.simplified,n=e[0].dims,s=R.size(n),d=n,l=s,p=n.slice(-1)[0],h=i?n.slice(0,-1).concat(1):[],u=!a&&e.length>3,m=e.length>4,$=i&&r>1,f=i&&r>2,y=r>3,v=64,x=Se(p),_=[{type:12,data:l},{type:12,data:x},{type:12,data:p},{type:1,data:t.epsilon}],S=T=>{let I=[{name:"output_size",type:"u32"},{name:"components",type:"u32"},{name:"hidden_size",type:"u32"},{name:"epsilon",type:"f32"}],C=[P("x",e[0].dataType,e[0].dims,x),P("skip",e[1].dataType,e[1].dims,x),P("gamma",e[2].dataType,e[2].dims,x)];u&&C.push(P("beta",e[3].dataType,e[3].dims,x)),m&&C.push(P("bias",e[4].dataType,e[4].dims,x)),C.push(Y("output",e[0].dataType,d,x)),$&&C.push(Y("mean_output",1,h)),f&&C.push(Y("inv_std_output",1,h)),y&&C.push(Y("input_skip_bias_sum",e[0].dataType,d,x));let M=Ee(e[0].dataType),N=Ee(1,x);return`

      ${T.registerUniforms(I).declareVariables(...C)}
      var<workgroup> sum_shared : array<${N}, ${v}>;
      var<workgroup> sum_squared_shared : array<${N}, ${v}>;

      ${T.mainStart([v,1,1])}
        let ix = local_id.x;
        let iy = global_id.x / ${v};

        let hidden_size_vectorized: u32 = uniforms.hidden_size / uniforms.components;
        var stride = hidden_size_vectorized / ${v};
        let offset = ix * stride + iy * hidden_size_vectorized;
        let offset1d = stride * ix;
        if (ix == ${v-1}) {
          stride = hidden_size_vectorized - stride * ix;
        }
        for (var i: u32 = 0; i < stride; i++) {
          let skip_value = skip[offset + i];
          let bias_value = ${m?"bias[offset1d + i]":M+"(0.0)"};
          let input_value = x[offset + i];
          let value = input_value + skip_value + bias_value;
          ${y?"input_skip_bias_sum[offset + i] = value;":""}
          output[offset + i] = value;
          let f32_value = ${jt(M,x,"value")};
          sum_shared[ix] += f32_value;
          sum_squared_shared[ix] += f32_value * f32_value;
        }
        workgroupBarrier();

        var reduce_size : u32 = ${v};
        for (var curr_size = reduce_size >> 1;  curr_size > 0; curr_size = reduce_size >> 1) {
          reduce_size = curr_size + (reduce_size & 1);
          if (ix < curr_size) {
            sum_shared[ix] += sum_shared[ix + reduce_size];
            sum_squared_shared[ix] += sum_squared_shared[ix + reduce_size];
          }
          workgroupBarrier();
        }

        let sum = sum_shared[0];
        let square_sum = sum_squared_shared[0];
        let mean = ${_t("sum",x)} / f32(uniforms.hidden_size);
        let inv_std_dev = inverseSqrt(${_t("square_sum",x)} / f32(uniforms.hidden_size) ${a?"":"- mean * mean"} + uniforms.epsilon);
        ${$?"mean_output[global_idx] = mean;":""}
        ${f?"inv_std_output[global_idx] = inv_std_dev;":""}

        for (var i: u32 = 0; i < stride; i++) {
          output[offset + i] = (output[offset + i] ${a?"":`- ${M}(mean)`}) *
            ${M}(inv_std_dev) * gamma[offset1d + i]
            ${u?"+ beta[offset1d + i]":""};
        }
      }`},k=[{dims:d,dataType:e[0].dataType}];return r>1&&k.push({dims:h,dataType:1}),r>2&&k.push({dims:h,dataType:1}),r>3&&k.push({dims:n,dataType:e[0].dataType}),{name:"SkipLayerNormalization",shaderCache:{hint:`${x};${$};${f};${y}`,inputDependencies:e.map((T,I)=>"type")},getShaderSource:S,getRunData:()=>({outputs:k,dispatchGroup:{x:Math.ceil(l/p)},programUniforms:_})}},eh=(e,t)=>{Al(e.inputs);let r=[0];e.outputCount>1&&r.push(-3),e.outputCount>2&&r.push(-3),e.outputCount>3&&r.push(3),e.compute(zl(e.inputs,t,e.outputCount,!1),{outputs:r})}}),Rl,tr,Ol,la,Bl,Ml,th,rh,sg=F(()=>{"use strict";ee(),ae(),Te(),ne(),Rl=(e,t)=>{if(!e||e.length<1)throw new Error("too few inputs");if(t.axes.length!==0){if(t.axes.length!==t.starts.length||t.axes.length!==t.ends.length)throw new Error("axes, starts and ends must have the same length")}else if(t.starts.length!==t.ends.length)throw new Error("starts and ends must have the same length");e.slice(1).forEach((r,i)=>{if(e[i+1].dataType!==6&&e[i+1].dataType!==7)throw new Error(`Input ${i} must be an array of int32 or int64`)})},tr=(e,t)=>{let r=[];if(e.length>t)if(e[t].dataType===7)e[t].getBigInt64Array().forEach(i=>r.push(Number(i)));else if(e[t].dataType===6)e[t].getInt32Array().forEach(i=>r.push(Number(i)));else throw new Error(`Input ${t} must be an array of int32 or int64`);return r},Ol=(e,t)=>{if(e.length>1){let r=tr(e,1),i=tr(e,2),a=tr(e,3);return a.length===0&&(a=[...Array(e[0].dims.length).keys()]),we({starts:r,ends:i,axes:a})}else return t},la=(e,t,r,i,a)=>{let n=e;return e<0&&(n+=r[i[t]]),a[t]<0?Math.max(0,Math.min(n,r[i[t]]-1)):Math.max(0,Math.min(n,r[i[t]]))},Bl=(e,t,r)=>`fn calculateInputIndices(output_indices: ${t.type.indices}) -> ${e.type.indices} {
          var input_indices: ${e.type.indices};
          var carry = 0u;
          for (var i = ${r.length}; i >= 0; i--) {
            let input_shape_i = ${H("uniforms.input_shape","i",r.length)};
            let steps_i = ${H("uniforms.steps","i",r.length)};
            let signs_i = ${H("uniforms.signs","i",r.length)};
            let starts_i = ${H("uniforms.starts","i",r.length)};
            var output_index = ${t.indicesGet("output_indices","i")};
            var input_index = output_index * steps_i + starts_i + carry;
            carry = input_index / input_shape_i;
            input_index = input_index % input_shape_i;
            if (signs_i < 0) {
              input_index = input_shape_i - input_index - 1u + starts_i;
            }
            ${e.indicesSet("input_indices","i","input_index")};
          }
          return input_indices;
      }`,Ml=(e,t)=>{let r=e[0].dims,i=R.size(r),a=t.axes.length>0?R.normalizeAxes(t.axes,r.length):[...Array(r.length).keys()],n=tr(e,4);n.forEach(x=>x!==0||(()=>{throw new Error("step cannot be 0")})),n.length===0&&(n=Array(a.length).fill(1));let s=t.starts.map((x,_)=>la(x,_,r,a,n)),d=t.ends.map((x,_)=>la(x,_,r,a,n));if(a.length!==s.length||a.length!==d.length)throw new Error("start, ends and axes should have the same number of elements");if(a.length!==r.length)for(let x=0;x<r.length;++x)a.includes(x)||(s.splice(x,0,0),d.splice(x,0,r[x]),n.splice(x,0,1));let l=n.map(x=>Math.sign(x));n.forEach((x,_,S)=>{if(x<0){let k=(d[_]-s[_])/x,T=s[_],I=T+k*n[_];s[_]=I,d[_]=T,S[_]=-x}});let p=r.slice(0);a.forEach((x,_)=>{p[x]=Math.ceil((d[x]-s[x])/n[x])});let h={dims:p,dataType:e[0].dataType},u=Y("output",e[0].dataType,p.length),m=P("input",e[0].dataType,e[0].dims.length),$=R.size(p),f=[{name:"outputSize",type:"u32"},{name:"starts",type:"u32",length:s.length},{name:"signs",type:"i32",length:l.length},{name:"steps",type:"u32",length:n.length}],y=[{type:12,data:$},{type:12,data:s},{type:6,data:l},{type:12,data:n},...G(e[0].dims,p)],v=x=>`
      ${x.registerUniforms(f).declareVariables(m,u)}
        ${Bl(m,u,r)}
        ${x.mainStart()}
          ${x.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
          let output_indices = ${u.offsetToIndices("global_idx")};
          let input_indices = calculateInputIndices(output_indices);
          ${u.setByOffset("global_idx",m.getByIndices("input_indices"))}
      }`;return{name:"Slice",shaderCache:{hint:`${l.length}_${s.length}_${n.length}`,inputDependencies:["rank"]},getShaderSource:v,getRunData:()=>({outputs:[h],dispatchGroup:{x:Math.ceil(i/64)},programUniforms:y})}},th=(e,t)=>{Rl(e.inputs,t);let r=Ol(e.inputs,t);e.compute(Ml(e.inputs,r),{inputs:[0]})},rh=e=>{let t=e.starts,r=e.ends,i=e.axes;return we({starts:t,ends:r,axes:i})}}),Pl,Dl,ih,ah,og=F(()=>{"use strict";ee(),ae(),Te(),St(),ne(),Pl=e=>{if(!e||e.length!==1)throw new Error("Softmax op requires 1 input.")},Dl=(e,t)=>{let r=e.inputs[0],i=r.dims,a=R.size(i),n=64,s=i.length,d=R.normalizeAxis(t.axis,s),l=d<i.length-1,p,h=[];l?(h=Array.from({length:s},(C,M)=>M),h[d]=s-1,h[s-1]=d,p=e.compute(Le(r,h),{inputs:[r],outputs:[-1]})[0]):p=r;let u=p.dims,m=u[s-1],$=a/m,f=Se(m),y=m/f,v=(C,M)=>M===4?`max(max(${C}.x, ${C}.y), max(${C}.z, ${C}.w))`:M===2?`max(${C}.x, ${C}.y)`:M===3?`max(max(${C}.x, ${C}.y), ${C}.z)`:C,x=P("x",p.dataType,p.dims,f),_=Y("result",p.dataType,p.dims,f),S=x.type.value,k=Ee(p.dataType)==="f32"?`var threadMax = ${S}(-3.402823e+38f);`:`var threadMax = ${S}(-65504.0h);`,T=C=>`
      var<workgroup> rowMaxShared : ${S};
      var<workgroup> rowSumShared : ${S};
      var<workgroup> threadShared : array<${S}, ${n}>;

      fn getValue(row: i32, col: i32, row_stride: i32) -> ${S} {
        let index = row * row_stride + col;
        return x[index];
      }

      fn setValue(row: i32, col: i32, row_stride: i32, value: ${S}) {
        let index = row * row_stride + col;
        result[index] = value;
      }
      ${C.registerUniform("packedCols","i32").declareVariables(x,_)}
      ${C.mainStart()}
        let gindex = i32(global_idx);
        let lindex = i32(local_idx);
        const wg = ${n};
        let row = gindex / wg;
        let cols = uniforms.packedCols;
        let row_stride : i32 = uniforms.packedCols;

        // find the rows max
        ${k}
        for (var col = lindex; col < cols; col += wg) {
          let value = getValue(row, col, row_stride);
          threadMax = max(threadMax, value);
        }
        if (lindex < cols) {
          threadShared[lindex] = threadMax;
        }
        workgroupBarrier();

        var reduceSize = min(cols, wg);
        for (var currSize = reduceSize >> 1;  currSize > 0; currSize = reduceSize >> 1) {
          reduceSize = currSize + (reduceSize & 1);
          if (lindex < currSize) {
            threadShared[lindex] = max(threadShared[lindex], threadShared[lindex + reduceSize]);
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowMaxShared = ${S}(${v("threadShared[0]",f)});
        }
        workgroupBarrier();

        // find the rows sum
        var threadSum = ${S}(0.0);
        for (var col = lindex; col < cols; col += wg) {
          let subExp = exp(getValue(row, col, row_stride) - rowMaxShared);
          threadSum += subExp;
        }
        threadShared[lindex] = threadSum;
        workgroupBarrier();

        for (var currSize = wg >> 1;  currSize > 0; currSize = currSize >> 1) {
          if (lindex < currSize) {
            threadShared[lindex] = threadShared[lindex] + threadShared[lindex + currSize];
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowSumShared = ${S}(${_t("threadShared[0]",f)});
        }
        workgroupBarrier();

        // calculate final value for each element in the row
        for (var col = lindex; col < cols; col += wg) {
          let value = exp(getValue(row, col, row_stride) - rowMaxShared) / rowSumShared;
          setValue(row, col, row_stride, value);
        }
      }`,I=e.compute({name:"Softmax",shaderCache:{hint:`${f}`,inputDependencies:["type"]},getRunData:()=>({outputs:[{dims:u,dataType:p.dataType}],dispatchGroup:{x:$},programUniforms:[{type:6,data:y}]}),getShaderSource:T},{inputs:[p],outputs:[l?-1:0]})[0];l&&e.compute(Le(I,h),{inputs:[I]})},ih=(e,t)=>{Pl(e.inputs),Dl(e,t)},ah=e=>we({axis:e.axis})}),Fl,Ul,Nl,Wl,Ll,nh,sh,ug=F(()=>{"use strict";ee(),ae(),Te(),ne(),Fl=e=>{if(!e||e.length<1)throw new Error("too few inputs")},Ul=(e,t)=>{let r=[],i=t.numOutputs;return e[1].dims[0]>0&&(e[1].getBigInt64Array().forEach(a=>r.push(Number(a))),i=r.length),we({numOutputs:i,axis:t.axis,splitSizes:r})},Nl=e=>`
fn calculateOutputIndex(index: u32) -> u32 {
    for (var i: u32 = 0u; i < ${e}u; i += 1u ) {
    if (index < ${H("uniforms.size_in_split_axis","i",e)}) {
        return i;
    }
    }
    return ${e}u;
}`,Wl=e=>{let t=e.length,r=[];for(let i=0;i<t;++i){let a=e[i].setByIndices("indices","input[global_idx]");t===1?r.push(a):i===0?r.push(`if (output_number == ${i}u) { ${a} }`):i===t-1?r.push(`else { ${a} }`):r.push(`else if (output_number == ${i}) { ${a} }`)}return`
      fn writeBufferData(output_number: u32, indices: ${e[0].type.indices}, global_idx: u32) {
        ${r.join(`
`)}
      }`},Ll=(e,t)=>{let r=e[0].dims,i=R.size(r),a=e[0].dataType,n=R.normalizeAxis(t.axis,r.length),s=new Array(t.numOutputs),d=P("input",a,r.length),l=new Array(t.numOutputs),p=[],h=[],u=0,m=[{type:12,data:i}];for(let f=0;f<t.numOutputs;f++){u+=t.splitSizes[f],l[f]=u;let y=r.slice();y[n]=t.splitSizes[f],h.push(y),s[f]=Y(`output${f}`,a,y.length),p.push({dims:h[f],dataType:e[0].dataType})}m.push({type:12,data:l},...G(r,...h));let $=f=>`
  ${f.registerUniform("input_size","u32").registerUniform("size_in_split_axis","u32",l.length).declareVariables(d,...s)}
  ${Nl(l.length)}
  ${Wl(s)}

  ${f.mainStart()}
    ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.input_size")}

    var indices = ${d.offsetToIndices("global_idx")};
    var index = ${d.indicesGet("indices",n)};
    let output_number = calculateOutputIndex(index);
    if (output_number != 0) {
      index -= ${H("uniforms.size_in_split_axis","output_number - 1u",l.length)};
      ${d.indicesSet("indices",n,"index")};
    }
    writeBufferData(output_number, indices, global_idx);
  }`;return{name:"Split",shaderCache:{hint:t.cacheKey,inputDependencies:["rank"]},getShaderSource:$,getRunData:()=>({outputs:p,dispatchGroup:{x:Math.ceil(i/64)},programUniforms:m})}},nh=(e,t)=>{Fl(e.inputs);let r=e.inputs.length===1?t:Ul(e.inputs,t);e.compute(Ll(e.inputs,r),{inputs:[0]})},sh=e=>{let t=e.axis,r=e.splitSizes,i=e.numOutputs<0?r.length:e.numOutputs;if(i!==r.length)throw new Error("numOutputs and splitSizes lengh must be equal");return we({axis:t,numOutputs:i,splitSizes:r})}}),ql,Vl,oh,lg=F(()=>{"use strict";ee(),ae(),ne(),ql=(e,t,r,i,a)=>{let n=Y("output_data",a,r.length,4),s=P("a_data",t[1].dataType,t[1].dims.length,4),d=P("b_data",t[2].dataType,t[2].dims.length,4),l=P("c_data",t[0].dataType,t[0].dims.length,4),p,h=(u,m,$)=>`select(${m}, ${u}, ${$})`;if(!i)p=n.setByOffset("global_idx",h(s.getByOffset("global_idx"),d.getByOffset("global_idx"),l.getByOffset("global_idx")));else{let u=(m,$,f="")=>{let y=`a_data[index_a${$}][component_a${$}]`,v=`b_data[index_b${$}][component_b${$}]`,x=`bool(c_data[index_c${$}] & (0xffu << (component_c${$} * 8)))`;return`
            let output_indices${$} = ${n.offsetToIndices(`global_idx * 4u + ${$}u`)};
            let offset_a${$} = ${s.broadcastedIndicesToOffset(`output_indices${$}`,n)};
            let offset_b${$} = ${d.broadcastedIndicesToOffset(`output_indices${$}`,n)};
            let offset_c${$} = ${l.broadcastedIndicesToOffset(`output_indices${$}`,n)};
            let index_a${$} = offset_a${$} / 4u;
            let index_b${$} = offset_b${$} / 4u;
            let index_c${$} = offset_c${$} / 4u;
            let component_a${$} = offset_a${$} % 4u;
            let component_b${$} = offset_b${$} % 4u;
            let component_c${$} = offset_c${$} % 4u;
            ${m}[${$}] = ${f}(${h(y,v,x)});
          `};a===9?p=`
            var data = vec4<u32>(0);
            ${u("data",0,"u32")}
            ${u("data",1,"u32")}
            ${u("data",2,"u32")}
            ${u("data",3,"u32")}
            output_data[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:p=`
            ${u("output_data[global_idx]",0)}
            ${u("output_data[global_idx]",1)}
            ${u("output_data[global_idx]",2)}
            ${u("output_data[global_idx]",3)}
          `}return`
        ${e.registerUniform("vec_size","u32").declareVariables(l,s,d,n)}
        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${p}
      }`},Vl=e=>{let t=e[1].dims,r=e[2].dims,i=e[0].dims,a=e[1].dataType,n=!(R.areEqual(t,r)&&R.areEqual(r,i)),s=t,d=R.size(t);if(n){let p=Gt.calcShape(Gt.calcShape(t,r,!1),i,!1);if(!p)throw new Error("Can't perform where op on the given tensors");s=p,d=R.size(s)}let l=Math.ceil(d/4);return{name:"Where",shaderCache:{inputDependencies:["rank","rank","rank"]},getShaderSource:p=>ql(p,e,s,n,a),getRunData:()=>({outputs:[{dims:s,dataType:a}],dispatchGroup:{x:Math.ceil(d/64/4)},programUniforms:[{type:12,data:l},...G(i,t,r,s)]})}},oh=e=>{e.compute(Vl(e.inputs))}}),uh,dg=F(()=>{"use strict";Em(),Ha(),Cm(),Im(),Am(),zm(),Rm(),Pm(),Um(),Nm(),Wm(),Lm(),qm(),Vm(),jm(),Gm(),Hm(),Km(),Ym(),Zm(),Qm(),uc(),Xm(),Ac(),Jm(),eg(),tg(),rg(),Ga(),ig(),ag(),ng(),sg(),og(),ug(),Rc(),St(),Ka(),lg(),uh=new Map([["Abs",[op]],["Acos",[up]],["Acosh",[lp]],["Add",[qp]],["ArgMax",[ip,_a]],["ArgMin",[rp,_a]],["Asin",[dp]],["Asinh",[pp]],["Atan",[cp]],["Atanh",[hp]],["Attention",[ap]],["AveragePool",[Wc,Nc]],["BatchNormalization",[np]],["BiasAdd",[sp]],["BiasSplitGelu",[Lp]],["Cast",[mp,fp]],["Ceil",[yp]],["Clip",[gp]],["Concat",[Jp,ec]],["Conv",[ka,Sa]],["ConvTranspose",[pc,dc]],["Cos",[wp]],["Cosh",[$p]],["CumSum",[cc,hc]],["DepthToSpace",[fc,mc]],["DequantizeLinear",[Kc,Yc]],["Div",[Vp]],["Einsum",[gc,yc]],["Elu",[_p,or]],["Equal",[jp]],["Erf",[bp]],["Exp",[vp]],["Expand",[wc]],["FastGelu",[$c]],["Floor",[xp]],["FusedConv",[ka,Sa]],["Gather",[bc,_c]],["GatherElements",[kc,Sc]],["GatherBlockQuantized",[vc,xc]],["Gelu",[Sp]],["Gemm",[Ec,Tc]],["GlobalAveragePool",[qc,Lc]],["GlobalMaxPool",[Hc,Gc]],["Greater",[Yp]],["GreaterOrEqual",[Qp]],["GroupQueryAttention",[Bc,Oc]],["HardSigmoid",[Rp,zp]],["InstanceNormalization",[Mc]],["LayerNormalization",[Pc]],["LeakyRelu",[kp,or]],["Less",[Zp]],["LessOrEqual",[Xp]],["Log",[Np]],["MatMul",[oc]],["MatMulNBits",[Dc,Fc]],["MaxPool",[Vc,jc]],["Mul",[Gp]],["MultiHeadAttention",[Ic,Cc]],["Neg",[Ep]],["Not",[Tp]],["Pad",[Uc]],["Pow",[Hp]],["QuickGelu",[Wp,or]],["Range",[Zc]],["Reciprocal",[Cp]],["ReduceMin",[Qd]],["ReduceMean",[Gd]],["ReduceMax",[Zd]],["ReduceSum",[Jd]],["ReduceProd",[Xd]],["ReduceL1",[Hd]],["ReduceL2",[Kd]],["ReduceLogSum",[tp]],["ReduceLogSumExp",[Yd]],["ReduceSumSquare",[ep]],["Relu",[Ip]],["Resize",[Qc,Xc]],["RotaryEmbedding",[Jc]],["Sigmoid",[Ap]],["Sin",[Op]],["Sinh",[Bp]],["Slice",[th,rh]],["SkipLayerNormalization",[eh]],["Split",[nh,sh]],["Sqrt",[Mp]],["Softmax",[ih,ah]],["Sub",[Kp]],["Tan",[Pp]],["Tanh",[Dp]],["ThresholdedRelu",[Up,or]],["Tile",[zc]],["Transpose",[Bd,Md]],["Where",[oh]]])}),lh,pg=F(()=>{"use strict";tt(),ut(),ne(),lh=class{constructor(e){this.backend=e,this.repo=new Map,this.attributesBound=!1}getArtifact(e){return this.repo.get(e)}setArtifact(e,t){this.repo.set(e,t)}run(e,t,r,i,a){ot(e.programInfo.name);let n=this.backend.device,s=this.backend.getComputePassEncoder();this.backend.writeTimestamp(this.backend.pendingDispatchNumber*2);let d=[];for(let p of t)d.push({binding:d.length,resource:{buffer:p.buffer}});for(let p of r)d.push({binding:d.length,resource:{buffer:p.buffer}});a&&d.push({binding:d.length,resource:a});let l=n.createBindGroup({layout:e.computePipeline.getBindGroupLayout(0),entries:d,label:e.programInfo.name});if(this.backend.sessionStatus==="capturing"){let p={kernelId:this.backend.currentKernelId,computePipeline:e.computePipeline,bindGroup:l,dispatchGroup:i};this.backend.capturedCommandList.get(this.backend.currentSessionId).push(p)}s.setPipeline(e.computePipeline),s.setBindGroup(0,l),s.dispatchWorkgroups(...i),this.backend.writeTimestamp(this.backend.pendingDispatchNumber*2+1),this.backend.pendingDispatchNumber++,(this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber||this.backend.queryType==="at-passes")&&this.backend.endComputePass(),this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber&&this.backend.flush(),et(e.programInfo.name)}dispose(){}build(e,t){ot(e.name);let r=this.backend.device,i=[];r.features.has("shader-f16")&&i.push("enable f16;");let a=Od(t,this.backend.device.limits),n=e.getShaderSource(a),s=`${i.join(`
`)}
${a.additionalImplementations}
${n}`,d=r.createShaderModule({code:s,label:e.name});ye("verbose",()=>`[WebGPU] ${e.name} shader code: ${s}`);let l=r.createComputePipeline({compute:{module:d,entryPoint:"main"},layout:"auto",label:e.name});return et(e.name),{programInfo:e,computePipeline:l,uniformVariablesInfo:a.variablesInfo}}normalizeDispatchGroupSize(e){let t=typeof e=="number"?e:e.x,r=typeof e=="number"?1:e.y||1,i=typeof e=="number"?1:e.z||1,a=this.backend.device.limits.maxComputeWorkgroupsPerDimension;if(t<=a&&r<=a&&i<=a)return[t,r,i];let n=t*r*i,s=Math.ceil(Math.sqrt(n));if(s>a){if(s=Math.ceil(Math.cbrt(n)),s>a)throw new Error("Total dispatch size exceeds WebGPU maximum.");return[s,s,s]}else return[s,s,1]}}}),jl,Gl,Hl,dh,cg=F(()=>{"use strict";tt(),ee(),ut(),Cd(),km(),dg(),pg(),jl=(e,t)=>{if(t.length!==e.length)throw new Error(`inputDependencies length ${t.length} is not equal to inputTensors length ${e.length}.`);let r=[];for(let i=0;i<e.length;++i){let a=e[i].dataType;switch(t[i]){case"none":{r.push("");break}case"type":{r.push(`${a}`);break}case"rank":{let n=e[i].dims.length;r.push(`${a};${n}`);break}case"dims":{let n=e[i].dims.join(",");r.push(`${a};${n}`);break}default:throw new Error(`unsupported input dependency: ${t[i]}`)}}return r.join("|")},Gl=(e,t,r)=>{let i=e.name;return e.shaderCache?.hint&&(i+="["+e.shaderCache.hint+"]"),i+=":"+r+`:${jl(t,e.shaderCache?.inputDependencies??new Array(t.length).fill("dims"))}`,i},Hl=class{constructor(e){e&&(this.architecture=e.architecture,this.vendor=e.vendor)}isArchitecture(e){return this.architecture===e}isVendor(e){return this.vendor===e}},dh=class{constructor(){this.currentSessionId=null,this.currentKernelId=null,this.commandEncoder=null,this.computePassEncoder=null,this.maxDispatchNumber=16,this.pendingDispatchNumber=0,this.pendingKernels=[],this.pendingQueries=new Map,this.sessionStatus="default",this.capturedCommandList=new Map,this.capturedPendingKernels=new Map,this.sessionExternalDataMapping=new Map}get currentKernelCustomData(){if(this.currentKernelId===null)throw new Error("currentKernelCustomData(): currentKernelId is null. (should not happen)");let e=this.kernelCustomData.get(this.currentKernelId);return e||(e={},this.kernelCustomData.set(this.currentKernelId,e)),e}async initialize(e,t){this.env=e;let r=[],i={requiredLimits:{maxComputeWorkgroupStorageSize:t.limits.maxComputeWorkgroupStorageSize,maxComputeWorkgroupsPerDimension:t.limits.maxComputeWorkgroupsPerDimension,maxStorageBufferBindingSize:t.limits.maxStorageBufferBindingSize,maxBufferSize:t.limits.maxBufferSize,maxComputeInvocationsPerWorkgroup:t.limits.maxComputeInvocationsPerWorkgroup,maxComputeWorkgroupSizeX:t.limits.maxComputeWorkgroupSizeX,maxComputeWorkgroupSizeY:t.limits.maxComputeWorkgroupSizeY,maxComputeWorkgroupSizeZ:t.limits.maxComputeWorkgroupSizeZ},requiredFeatures:r};t.features.has("chromium-experimental-timestamp-query-inside-passes")?r.push("chromium-experimental-timestamp-query-inside-passes"):t.features.has("timestamp-query")&&r.push("timestamp-query"),t.features.has("shader-f16")&&r.push("shader-f16"),this.device=await t.requestDevice(i),this.adapterInfo=new Hl(t.info||await t.requestAdapterInfo()),this.gpuDataManager=Id(this),this.programManager=new lh(this),this.kernels=new Map,this.kernelPersistentData=new Map,this.kernelCustomData=new Map,La(e.logLevel,!!e.debug),this.device.onuncapturederror=a=>{a.error instanceof GPUValidationError&&console.error(`An uncaught WebGPU validation error was raised: ${a.error.message}`)},Object.defineProperty(this.env.webgpu,"device",{value:this.device,writable:!1,enumerable:!0,configurable:!1}),Object.defineProperty(this.env.webgpu,"adapter",{value:t,writable:!1,enumerable:!0,configurable:!1}),this.setQueryType()}dispose(){typeof this.querySet<"u"&&this.querySet.destroy(),this.gpuDataManager.dispose()}getCommandEncoder(){return this.commandEncoder||(this.commandEncoder=this.device.createCommandEncoder()),this.commandEncoder}getComputePassEncoder(){if(!this.computePassEncoder){let e=this.getCommandEncoder(),t={};this.queryType==="at-passes"&&(t.timestampWrites={querySet:this.querySet,beginningOfPassWriteIndex:this.pendingDispatchNumber*2,endOfPassWriteIndex:this.pendingDispatchNumber*2+1}),this.computePassEncoder=e.beginComputePass(t)}return this.computePassEncoder}endComputePass(){this.computePassEncoder&&(this.computePassEncoder.end(),this.computePassEncoder=null)}flush(){if(!this.commandEncoder)return;ot(),this.endComputePass();let e;this.queryType!=="none"&&(this.commandEncoder.resolveQuerySet(this.querySet,0,this.pendingDispatchNumber*2,this.queryResolveBuffer,0),e=this.device.createBuffer({size:this.pendingDispatchNumber*2*8,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST}),this.pendingQueries.set(e,this.pendingKernels),this.pendingKernels=[],this.commandEncoder.copyBufferToBuffer(this.queryResolveBuffer,0,e,0,this.pendingDispatchNumber*2*8)),this.device.queue.submit([this.commandEncoder.finish()]),this.gpuDataManager.refreshPendingBuffers(),this.commandEncoder=null,this.pendingDispatchNumber=0,this.queryType!=="none"&&e.mapAsync(GPUMapMode.READ).then(()=>{let t=new BigUint64Array(e.getMappedRange()),r=this.pendingQueries.get(e);for(let i=0;i<t.length/2;i++){let a=r[i],n=a.kernelId,s=this.kernels.get(n),d=s.kernelType,l=s.kernelName,p=a.programName,h=a.inputTensorViews,u=a.outputTensorViews,m=t[i*2],$=t[i*2+1];typeof this.queryTimeBase>"u"&&(this.queryTimeBase=m);let f=Number(m-this.queryTimeBase),y=Number($-this.queryTimeBase);if(!Number.isSafeInteger(f)||!Number.isSafeInteger(y))throw new RangeError("incorrect timestamp range");if(this.env.webgpu.profiling?.ondata)this.env.webgpu.profiling.ondata({version:1,inputsMetadata:h.map(v=>({dims:v.dims,dataType:Bt(v.dataType)})),outputsMetadata:u.map(v=>({dims:v.dims,dataType:Bt(v.dataType)})),kernelId:n,kernelType:d,kernelName:l,programName:p,startTime:f,endTime:y});else{let v="";h.forEach((_,S)=>{v+=`input[${S}]: [${_.dims}] | ${Bt(_.dataType)}, `});let x="";u.forEach((_,S)=>{x+=`output[${S}]: [${_.dims}] | ${Bt(_.dataType)}, `}),console.log(`[profiling] kernel "${n}|${d}|${l}|${p}" ${v}${x}execution time: ${y-f} ns`)}qr("GPU",`${p}::${m}::${$}`)}e.unmap(),this.pendingQueries.delete(e)}),et()}run(e,t,r,i,a,n){ot(e.name);let s=[];for(let _=0;_<t.length;++_){let S=t[_].data;if(S===0)continue;let k=this.gpuDataManager.get(S);if(!k)throw new Error(`no GPU data for input: ${S}`);s.push(k)}let{outputs:d,dispatchGroup:l,programUniforms:p}=e.getRunData(t),h=r.length===0?d.map((_,S)=>S):r;if(h.length!==d.length)throw new Error(`Output size ${h.length} must be equal to ${d.length}.`);let u=[],m=[];for(let _=0;_<d.length;++_){if(!Number.isInteger(h[_])||h[_]<-3||h[_]>=n)throw new Error(`Invalid output index: ${h[_]}`);if(h[_]===-3)continue;let S=h[_]===-1,k=h[_]===-2,T=S||k?a(d[_].dataType,d[_].dims):i(h[_],d[_].dataType,d[_].dims);if(u.push(T),T.data===0)continue;let I=this.gpuDataManager.get(T.data);if(!I)throw new Error(`no GPU data for output: ${T.data}`);if(S&&this.temporaryData.push(I),k){let C=this.kernelPersistentData.get(this.currentKernelId);C||(C=[],this.kernelPersistentData.set(this.currentKernelId,C)),C.push(I)}m.push(I)}if(s.length!==t.length||m.length!==u.length){if(m.length===0)return et(e.name),u;throw new Error(`Program ${e.name} has zero-sized tensor(s) in inputs or outputs. This is not supported now.`)}let $;if(p){let _=0,S=[];p.forEach(C=>{let M=typeof C.data=="number"?[C.data]:C.data;if(M.length===0)return;let N=C.type===10?2:4,W,J;C.type===10?(J=M.length>4?16:M.length>2?8:M.length*N,W=M.length>4?16:N*M.length):(J=M.length<=2?M.length*N:16,W=16),_=Math.ceil(_/J)*J,S.push(_);let K=C.type===10?8:4;_+=M.length>4?Math.ceil(M.length/K)*W:M.length*N});let k=16;_=Math.ceil(_/k)*k;let T=new ArrayBuffer(_);p.forEach((C,M)=>{let N=S[M],W=typeof C.data=="number"?[C.data]:C.data;if(C.type===6)new Int32Array(T,N,W.length).set(W);else if(C.type===12)new Uint32Array(T,N,W.length).set(W);else if(C.type===10)new Uint16Array(T,N,W.length).set(W);else if(C.type===1)new Float32Array(T,N,W.length).set(W);else throw new Error(`Unsupported uniform type: ${Bt(C.type)}`)});let I=this.gpuDataManager.create(_,GPUBufferUsage.COPY_DST|GPUBufferUsage.UNIFORM);this.device.queue.writeBuffer(I.buffer,0,T,0,_),this.gpuDataManager.release(I.id),$={offset:0,size:_,buffer:I.buffer}}let f=this.programManager.normalizeDispatchGroupSize(l),y=f[1]===1&&f[2]===1,v=Gl(e,t,y),x=this.programManager.getArtifact(v);if(x||(x=this.programManager.build(e,f),this.programManager.setArtifact(v,x),ye("info",()=>`[artifact] key: ${v}, programName: ${e.name}`)),p&&x.uniformVariablesInfo){if(p.length!==x.uniformVariablesInfo.length)throw new Error(`Uniform variables count mismatch: expect ${x.uniformVariablesInfo.length}, got ${p.length} in program "${x.programInfo.name}".`);for(let _=0;_<p.length;_++){let S=p[_],k=S.type,T=typeof S.data=="number"?1:S.data.length,[I,C]=x.uniformVariablesInfo[_];if(k!==I||T!==C)throw new Error(`Uniform variable ${_} mismatch: expect type ${I} with size ${C}, got type ${k} with size ${T} in program "${x.programInfo.name}".`)}}if(ye("info",()=>`[ProgramManager] run "${e.name}" (key=${v}) with ${f[0]}x${f[1]}x${f[2]}`),this.queryType!=="none"||this.sessionStatus==="capturing"){let _={kernelId:this.currentKernelId,programName:x.programInfo.name,inputTensorViews:t,outputTensorViews:u};this.pendingKernels.push(_),this.sessionStatus==="capturing"&&this.capturedPendingKernels.get(this.currentSessionId).push(_)}return this.programManager.run(x,s,m,f,$),et(e.name),u}upload(e,t){this.gpuDataManager.upload(e,t)}memcpy(e,t){this.gpuDataManager.memcpy(e,t)}async download(e,t){await this.gpuDataManager.download(e,t)}alloc(e){return this.gpuDataManager.create(e).id}free(e){return this.gpuDataManager.release(e)}createKernel(e,t,r,i){let a=uh.get(e);if(!a)throw new Error(`kernel not implemented: ${e}`);let n={kernelType:e,kernelName:i,kernelEntry:a[0],attributes:[a[1],r]};this.kernels.set(t,n)}releaseKernel(e){let t=this.kernelPersistentData.get(e);if(t){for(let r of t)this.gpuDataManager.release(r.id);this.kernelPersistentData.delete(e)}this.kernelCustomData.delete(e),this.kernels.delete(e)}computeKernel(e,t,r){let i=this.kernels.get(e);if(!i)throw new Error(`kernel not created: ${e}`);let a=i.kernelType,n=i.kernelName,s=i.kernelEntry,d=i.attributes;if(this.currentKernelId!==null)throw new Error(`kernel "[${a}] ${n}" is not allowed to be called recursively`);this.currentKernelId=e,d[0]&&(d[1]=d[0](d[1]),d[0]=void 0),ye("info",()=>`[WebGPU] Start to run kernel "[${a}] ${n}"...`);let l=this.env.debug;this.temporaryData=[];try{return l&&this.device.pushErrorScope("validation"),s(t,d[1]),0}catch(p){return r.push(Promise.resolve(`[WebGPU] Kernel "[${a}] ${n}" failed. ${p}`)),1}finally{l&&r.push(this.device.popErrorScope().then(p=>p?`GPU validation error for kernel "[${a}] ${n}": ${p.message}`:null));for(let p of this.temporaryData)this.gpuDataManager.release(p.id);this.temporaryData=[],this.currentKernelId=null}}registerBuffer(e,t,r,i){let a=this.sessionExternalDataMapping.get(e);a||(a=new Map,this.sessionExternalDataMapping.set(e,a));let n=a.get(t),s=this.gpuDataManager.registerExternalBuffer(r,i,n);return a.set(t,[s,r]),s}unregisterBuffers(e){let t=this.sessionExternalDataMapping.get(e);t&&(t.forEach(r=>this.gpuDataManager.unregisterExternalBuffer(r[0])),this.sessionExternalDataMapping.delete(e))}getBuffer(e){let t=this.gpuDataManager.get(e);if(!t)throw new Error(`no GPU data for buffer: ${e}`);return t.buffer}createDownloader(e,t,r){return async()=>{let i=await ya(this,e,t);return qa(i.buffer,r)}}writeTimestamp(e){this.queryType==="inside-passes"&&this.computePassEncoder.writeTimestamp(this.querySet,e)}setQueryType(){this.queryType="none",(this.env.webgpu.profiling?.mode==="default"||(typeof this.env.trace>"u"?this.env.wasm.trace:this.env.trace))&&(this.device.features.has("chromium-experimental-timestamp-query-inside-passes")?this.queryType="inside-passes":this.device.features.has("timestamp-query")&&(this.queryType="at-passes"),this.queryType!=="none"&&typeof this.querySet>"u"&&(this.querySet=this.device.createQuerySet({type:"timestamp",count:this.maxDispatchNumber*2}),this.queryResolveBuffer=this.device.createBuffer({size:this.maxDispatchNumber*2*8,usage:GPUBufferUsage.COPY_SRC|GPUBufferUsage.QUERY_RESOLVE})))}captureBegin(){ye("info","captureBegin"),this.capturedCommandList.get(this.currentSessionId)||this.capturedCommandList.set(this.currentSessionId,[]),this.capturedPendingKernels.get(this.currentSessionId)||this.capturedPendingKernels.set(this.currentSessionId,[]),this.flush(),this.sessionStatus="capturing"}captureEnd(){ye("info","captureEnd"),this.flush(),this.sessionStatus="default"}replay(){ye("info","replay"),this.sessionStatus="replaying";let e=this.capturedCommandList.get(this.currentSessionId),t=this.capturedPendingKernels.get(this.currentSessionId),r=e.length;this.pendingKernels=[];for(let i=0;i<r;i++){let a=this.getComputePassEncoder(),n=e[i];this.writeTimestamp(this.pendingDispatchNumber*2),a.setPipeline(n.computePipeline),a.setBindGroup(0,n.bindGroup),a.dispatchWorkgroups(...n.dispatchGroup),this.writeTimestamp(this.pendingDispatchNumber*2+1),this.pendingDispatchNumber++,this.queryType!=="none"&&this.pendingKernels.push(t[i]),(this.pendingDispatchNumber>=this.maxDispatchNumber||this.queryType==="at-passes")&&this.endComputePass(),this.pendingDispatchNumber>=this.maxDispatchNumber&&this.flush()}this.flush(),this.sessionStatus="default"}onReleaseSession(e){this.unregisterBuffers(e),this.capturedCommandList.has(e)&&this.capturedCommandList.delete(e),this.capturedPendingKernels.has(e)&&this.capturedPendingKernels.delete(e),this.gpuDataManager.onReleaseSession(e)}onRunStart(e){this.currentSessionId=e,this.setQueryType()}}}),Kl,da,pa,Yl,ph,hg=F(()=>{"use strict";ut(),Kl=1,da=()=>Kl++,pa=class{constructor(e,t){this.mlContext=e,this.tensorEntry=t,this.tensorCache=t?[t]:[]}get tensor(){return this.tensorEntry?.[0]}get context(){if(!this.mlContext)throw new Error("MLContext has not been set.");return this.mlContext}set context(e){if(this.mlContext&&this.mlContext!==e)throw new Error("MLTensor in use in a different MLContext.");this.mlContext=e}destroy(){for(let[e]of this.tensorCache)e.destroy();this.tensorCache=[],this.tensorEntry=void 0}trySelectTensor(e,t){for(let[r,i,a]of this.tensorCache)if(t===r){if(this.context!==e)throw new Error("MLTensor cannot be registered with a different MLContext.");return this.tensorEntry=[r,i,a],!0}return!1}async ensureTensor(e,t,r){if(this.tensorEntry){let[n,s,d]=this.tensorEntry;if(s===e&&d.every((l,p)=>l===t[p]))return n}for(let[n,s,d]of this.tensorCache)if(s===e&&d.every((l,p)=>l===t[p])){if(r&&this.tensorEntry){ye("verbose",()=>`[WebNN] Slowdown may occur, having to copy existing tensor {dataType: ${e}, shape: ${t}}`);let l=await this.context.readTensor(this.tensorEntry[0]);this.context.writeTensor(n,l)}return this.tensorEntry=[n,s,d],n}ye("verbose",()=>`[WebNN] MLContext.createTensor {dataType: ${e}, shape: ${t}}`);let i=MLTensorUsage.READ|MLTensorUsage.WRITE,a=await this.context.createTensor({dataType:e,shape:t,dimensions:t,usage:i});return this.tensorEntry=[a,e,t],this.tensorCache.push(this.tensorEntry),this.activeUpload&&(this.mlContext?.writeTensor(a,this.activeUpload),this.activeUpload=void 0),a}upload(e){if(!this.tensorEntry){this.activeUpload=new Uint8Array(e);return}this.mlContext?.writeTensor(this.tensorEntry[0],e)}async download(e){if(this.activeUpload)if(e){e instanceof ArrayBuffer?new Uint8Array(e).set(this.activeUpload):new Uint8Array(e.buffer,e.byteOffset,e.byteLength).set(this.activeUpload);return}else return this.activeUpload.buffer;if(!this.tensorEntry)throw new Error("Tensor has not been created.");return e?this.context.readTensor(this.tensorEntry[0],e):this.context.readTensor(this.tensorEntry[0])}},Yl=class{constructor(e){this.backend=e,this.tensorsById=new Map,this.tensorIdsByContext=new Map}reserveTensorId(){let e=da();return this.tensorsById.set(e,new pa),e}releaseTensorId(e){let t=this.tensorsById.get(e);if(t){t.destroy(),this.tensorsById.delete(e);for(let[r,i]of this.tensorIdsByContext)if(i.has(e)){i.delete(e),i.size===0&&this.tensorIdsByContext.delete(r);break}}}async ensureTensor(e,t,r,i){ye("verbose",()=>`[WebNN] TensorManager.ensureTensor {tensorId: ${e}, dataType: ${t}, shape: ${r}, copyOld: ${i}}`);let a=this.tensorsById.get(e);if(!a)throw new Error("Tensor not found.");return a.context=this.backend.currentContext,this.tensorIdsByContext.has(this.backend.currentContext)||this.tensorIdsByContext.set(this.backend.currentContext,new Set),this.tensorIdsByContext.get(this.backend.currentContext)?.add(e),a.ensureTensor(t,r,i)}upload(e,t){this.tensorsById.get(e).upload(t)}async download(e,t){return ye("verbose",()=>`[WebNN] TensorManager.download {tensorId: ${e}, dstBuffer: ${t?.byteLength}}`),this.tensorsById.get(e).download(t)}releaseTensorsForContext(e){let t=this.tensorIdsByContext.get(e);if(t){for(let r of t)this.tensorsById.get(r).destroy(),this.tensorsById.delete(r);this.tensorIdsByContext.delete(e)}}registerTensor(e,t,r,i){for(let[s,d]of this.tensorsById)if(d.trySelectTensor(e,t))return s;let a=da();this.tensorsById.set(a,new pa(e,[t,r,i]));let n=this.tensorIdsByContext.get(e);return n||(n=new Set,this.tensorIdsByContext.set(e,n)),n.add(a),a}},ph=(...e)=>new Yl(...e)}),ca,ch,fg=F(()=>{"use strict";ee(),Mt(),Cd(),hg(),ut(),ca=new Map([[1,"float32"],[10,"float16"],[6,"int32"],[12,"uint32"],[7,"int64"],[13,"uint64"],[3,"int8"],[2,"uint8"],[9,"uint8"]]),ch=class{constructor(e){this.tensorManager=ph(this),this.mlContextBySessionId=new Map,this.sessionIdsByMLContext=new Map,La(e.logLevel,!!e.debug)}get currentSessionId(){if(this.activeSessionId===void 0)throw new Error("No active session");return this.activeSessionId}onRunStart(e){this.activeSessionId=e}get currentContext(){let e=this.getMLContext(this.currentSessionId);if(!e)throw new Error(`No MLContext found for session ${this.currentSessionId}`);return e}registerMLContext(e,t){this.mlContextBySessionId.set(e,t);let r=this.sessionIdsByMLContext.get(t);r||(r=new Set,this.sessionIdsByMLContext.set(t,r)),r.add(e)}onReleaseSession(e){let t=this.mlContextBySessionId.get(e);if(!t)return;this.mlContextBySessionId.delete(e);let r=this.sessionIdsByMLContext.get(t);r.delete(e),r.size===0&&(this.sessionIdsByMLContext.delete(t),this.tensorManager.releaseTensorsForContext(t))}getMLContext(e){return this.mlContextBySessionId.get(e)}reserveTensorId(){return this.tensorManager.reserveTensorId()}releaseTensorId(e){ye("verbose",()=>`[WebNN] releaseTensorId {tensorId: ${e}}`),this.tensorManager.releaseTensorId(e)}async ensureTensor(e,t,r,i){let a=ca.get(t);if(!a)throw new Error(`Unsupported ONNX data type: ${t}`);return this.tensorManager.ensureTensor(e,a,r,i)}uploadTensor(e,t){if(!Ce().shouldTransferToMLTensor)throw new Error("Trying to upload to a MLTensor while shouldTransferToMLTensor is false");ye("verbose",()=>`[WebNN] uploadTensor {tensorId: ${e}, data: ${t.byteLength}}`),this.tensorManager.upload(e,t)}async downloadTensor(e,t){return this.tensorManager.download(e,t)}createMLTensorDownloader(e,t){return async()=>{let r=await this.tensorManager.download(e);return qa(r,t)}}registerMLTensor(e,t,r){let i=ca.get(t);if(!i)throw new Error(`Unsupported ONNX data type: ${t}`);let a=this.tensorManager.registerTensor(this.currentContext,e,i,r);return ye("verbose",()=>`[WebNN] registerMLTensor {tensor: ${e}, dataType: ${i}, dimensions: ${r}} -> {tensorId: ${a}}`),a}flush(){}}}),hh={};pr(hh,{init:()=>fh});var Dr,Zl,fh,mg=F(()=>{"use strict";ee(),cg(),ut(),ae(),fg(),Dr=class mh{constructor(t,r,i,a){this.module=t,this.dataType=r,this.data=i,this.dims=a}getFloat32Array(){if(this.dataType!==1)throw new Error("Invalid data type");let t=R.size(this.dims);return t===0?new Float32Array:new Float32Array(this.module.HEAP8.buffer,this.data,t)}getBigInt64Array(){if(this.dataType!==7)throw new Error("Invalid data type");let t=R.size(this.dims);return t===0?new BigInt64Array:new BigInt64Array(this.module.HEAP8.buffer,this.data,t)}getInt32Array(){if(this.dataType!==6)throw new Error("Invalid data type");let t=R.size(this.dims);return t===0?new Int32Array:new Int32Array(this.module.HEAP8.buffer,this.data,t)}getUint16Array(){if(this.dataType!==10&&this.dataType!==4)throw new Error("Invalid data type");let t=R.size(this.dims);return t===0?new Uint16Array:new Uint16Array(this.module.HEAP8.buffer,this.data,t)}reshape(t){if(R.size(t)!==R.size(this.dims))throw new Error("Invalid new shape");return new mh(this.module,this.dataType,this.data,t)}},Zl=class{constructor(e,t,r){this.module=e,this.backend=t,this.customDataOffset=0,this.customDataSize=0,this.adapterInfo=t.adapterInfo;let i=e.HEAPU32,a=r>>>2;this.opKernelContext=i[a++];let n=i[a++];this.outputCount=i[a++],this.customDataOffset=i[a++],this.customDataSize=i[a++];let s=[];for(let d=0;d<n;d++){let l=i[a++],p=i[a++],h=i[a++],u=[];for(let m=0;m<h;m++)u.push(i[a++]);s.push(new Dr(e,l,p,u))}this.inputs=s}get kernelCustomData(){return this.backend.currentKernelCustomData}get customDataBuffer(){return this.module.HEAPU8.subarray(this.customDataOffset,this.customDataOffset+this.customDataSize)}getMaxComputeWorkgroupSizes(){return[this.backend.device.limits.maxComputeWorkgroupSizeX,this.backend.device.limits.maxComputeWorkgroupSizeY,this.backend.device.limits.maxComputeWorkgroupSizeZ]}getMaxComputeWorkgroupStoragesize(){return this.backend.device.limits.maxComputeWorkgroupStorageSize}compute(e,t){let r=t?.inputs?.map(s=>typeof s=="number"?this.inputs[s]:s)??this.inputs,i=t?.outputs??[],a=(s,d,l)=>new Dr(this.module,d,this.output(s,l),l),n=(s,d)=>{let l=Vt(s,d);if(!l)throw new Error(`Unsupported data type: ${s}`);let p=l>0?this.backend.gpuDataManager.create(l).id:0;return new Dr(this.module,s,p,d)};return this.backend.run(e,r,i,a,n,this.outputCount)}output(e,t){let r=this.module.stackSave();try{let i=this.module.stackAlloc((1+t.length)*4),a=i>>2;this.module.HEAPU32[a++]=t.length;for(let n=0;n<t.length;n++)this.module.HEAPU32[a++]=t[n];return this.module._JsepOutput(this.opKernelContext,e,i)}catch(i){throw new Error(`Failed to generate kernel's output[${e}] with dims [${t}]. If you are running with pre-allocated output, please make sure the output type/dims are correct. Error: ${i}`)}finally{this.module.stackRestore(r)}}},fh=async(e,t,r,i)=>{let a=t.jsepInit;if(!a)throw new Error("Failed to initialize JSEP. The WebAssembly module is not built with JSEP support.");if(e==="webgpu"){let n=new dh;await n.initialize(r,i),a("webgpu",[n,s=>n.alloc(s),s=>n.free(s),(s,d,l,p=!1)=>{if(p)ye("verbose",()=>`[WebGPU] jsepCopyGpuToGpu: src=${s}, dst=${d}, size=${l}`),n.memcpy(s,d);else{ye("verbose",()=>`[WebGPU] jsepCopyCpuToGpu: dataOffset=${s}, gpuDataId=${d}, size=${l}`);let h=t.HEAPU8.subarray(s>>>0,(s>>>0)+l);n.upload(d,h)}},async(s,d,l)=>{ye("verbose",()=>`[WebGPU] jsepCopyGpuToCpu: gpuDataId=${s}, dataOffset=${d}, size=${l}`),await n.download(s,()=>t.HEAPU8.subarray(d>>>0,(d>>>0)+l))},(s,d,l)=>n.createKernel(s,d,l,t.UTF8ToString(t._JsepGetNodeName(d))),s=>n.releaseKernel(s),(s,d,l,p)=>{ye("verbose",()=>`[WebGPU] jsepRun: sessionHandle=${l}, kernel=${s}, contextDataOffset=${d}`);let h=new Zl(t,n,d);return n.computeKernel(s,h,p)},()=>n.captureBegin(),()=>n.captureEnd(),()=>n.replay()])}else{let n=new ch(r);a("webnn",[n,()=>n.reserveTensorId(),s=>n.releaseTensorId(s),async(s,d,l,p)=>n.ensureTensor(s,d,l,p),(s,d)=>{n.uploadTensor(s,d)},async(s,d)=>n.downloadTensor(s,d)])}}}),Ql,Ja,en,wt,Xl,Zr,tn,rn,ha,an,nn,sn,gh=F(()=>{"use strict";xm(),Sm(),ee(),Mt(),Da(),Ed(),Ql=(e,t)=>{Ce()._OrtInit(e,t)!==0&&xe("Can't initialize onnxruntime.")},Ja=async e=>{Ql(e.wasm.numThreads,jr(e.logLevel))},en=async(e,t)=>{{let r=(mg(),Lr(hh)).init;if(t==="webgpu"){if(typeof navigator>"u"||!navigator.gpu)throw new Error("WebGPU is not supported in current environment");let i=e.webgpu.adapter;if(i){if(typeof i.limits!="object"||typeof i.features!="object"||typeof i.requestDevice!="function")throw new Error("Invalid GPU adapter set in `env.webgpu.adapter`. It must be a GPUAdapter object.")}else{let a=e.webgpu.powerPreference;if(a!==void 0&&a!=="low-power"&&a!=="high-performance")throw new Error(`Invalid powerPreference setting: "${a}"`);let n=e.webgpu.forceFallbackAdapter;if(n!==void 0&&typeof n!="boolean")throw new Error(`Invalid forceFallbackAdapter setting: "${n}"`);if(i=await navigator.gpu.requestAdapter({powerPreference:a,forceFallbackAdapter:n}),!i)throw new Error('Failed to get GPU adapter. You may need to enable flag "--enable-unsafe-webgpu" if you are using Chrome.')}await r("webgpu",Ce(),e,i)}if(t==="webnn"){if(typeof navigator>"u"||!navigator.ml)throw new Error("WebNN is not supported in current environment");await r("webnn",Ce(),e)}}},wt=new Map,Xl=e=>{let t=Ce(),r=t.stackSave();try{let i=t.stackAlloc(8);return t._OrtGetInputOutputCount(e,i,i+4)!==0&&xe("Can't get session input/output count."),[t.HEAP32[i/4],t.HEAP32[i/4+1]]}finally{t.stackRestore(r)}},Zr=e=>{let t=Ce(),r=t._malloc(e.byteLength);if(r===0)throw new Error(`Can't create a session. failed to allocate a buffer of size ${e.byteLength}.`);return t.HEAPU8.set(e,r),[r,e.byteLength]},tn=async(e,t)=>{let r,i,a=Ce();Array.isArray(e)?[r,i]=e:e.buffer===a.HEAPU8.buffer?[r,i]=[e.byteOffset,e.byteLength]:[r,i]=Zr(e);let n=0,s=0,d=0,l=[],p=[],h=[];try{if([s,l]=Td(t),t?.externalData&&a.mountExternalData){let _=[];for(let S of t.externalData){let k=typeof S=="string"?S:S.path;_.push(Wa(typeof S=="string"?S:S.data).then(T=>{a.mountExternalData(k,T)}))}await Promise.all(_)}for(let _ of t?.executionProviders??[])if((typeof _=="string"?_:_.name)==="webnn"){if(a.shouldTransferToMLTensor=!1,a.currentContext)throw new Error("WebNN execution provider is already set.");if(typeof _!="string"){let S=_,k=S?.context,T=S?.gpuDevice,I=S?.deviceType,C=S?.numThreads,M=S?.powerPreference;k?a.currentContext=k:T?a.currentContext=await navigator.ml.createContext(T):a.currentContext=await navigator.ml.createContext({deviceType:I,numThreads:C,powerPreference:M})}else a.currentContext=await navigator.ml.createContext();break}n=await a._OrtCreateSession(r,i,s),n===0&&xe("Can't create a session."),a.currentContext&&(a.jsepRegisterMLContext(n,a.currentContext),a.currentContext=void 0,a.shouldTransferToMLTensor=!0);let[u,m]=Xl(n),$=!!t?.enableGraphCapture,f=[],y=[],v=[];for(let _=0;_<u;_++){let S=a._OrtGetInputName(n,_);S===0&&xe("Can't get an input name."),p.push(S),f.push(a.UTF8ToString(S))}for(let _=0;_<m;_++){let S=a._OrtGetOutputName(n,_);S===0&&xe("Can't get an output name."),h.push(S);let k=a.UTF8ToString(S);y.push(k);{if($&&t?.preferredOutputLocation===void 0){v.push("gpu-buffer");continue}let T=typeof t?.preferredOutputLocation=="string"?t.preferredOutputLocation:t?.preferredOutputLocation?.[k]??"cpu";if(T!=="cpu"&&T!=="cpu-pinned"&&T!=="gpu-buffer"&&T!=="ml-tensor")throw new Error(`Not supported preferred output location: ${T}.`);if($&&T!=="gpu-buffer")throw new Error(`Not supported preferred output location: ${T}. Only 'gpu-buffer' location is supported when enableGraphCapture is true.`);v.push(T)}}let x=null;return v.some(_=>_==="gpu-buffer"||_==="ml-tensor")&&(d=a._OrtCreateBinding(n),d===0&&xe("Can't create IO binding."),x={handle:d,outputPreferredLocations:v,outputPreferredLocationsEncoded:v.map(_=>ga(_))}),wt.set(n,[n,p,h,x,$,!1]),[n,f,y]}catch(u){throw p.forEach(m=>a._OrtFree(m)),h.forEach(m=>a._OrtFree(m)),d!==0&&a._OrtReleaseBinding(d),n!==0&&a._OrtReleaseSession(n),u}finally{a._free(r),s!==0&&a._OrtReleaseSessionOptions(s),l.forEach(u=>a._free(u)),a.unmountExternalData?.()}},rn=e=>{let t=Ce(),r=wt.get(e);if(!r)throw new Error(`cannot release session. invalid session id: ${e}`);let[i,a,n,s,d]=r;s&&(d&&t._OrtClearBoundOutputs(s.handle),t._OrtReleaseBinding(s.handle)),t.jsepOnReleaseSession?.(e),a.forEach(l=>t._OrtFree(l)),n.forEach(l=>t._OrtFree(l)),t._OrtReleaseSession(i),wt.delete(e)},ha=(e,t,r,i,a,n=!1)=>{if(!e){t.push(0);return}let s=Ce(),d=e[0],l=e[1],p=e[3],h,u;if(d==="string"&&(p==="gpu-buffer"||p==="ml-tensor"))throw new Error("String tensor is not supported on GPU.");if(n&&p!=="gpu-buffer")throw new Error(`External buffer must be provided for input/output index ${a} when enableGraphCapture is true.`);if(p==="gpu-buffer"){let f=e[2].gpuBuffer;u=Vt(nr(d),l);let y=s.jsepRegisterBuffer;if(!y)throw new Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');h=y(i,a,f,u)}else if(p==="ml-tensor"){let f=e[2].mlTensor;u=Vt(nr(d),l);let y=s.jsepRegisterMLTensor;if(!y)throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');h=y(f,nr(d),l)}else{let f=e[2];if(Array.isArray(f)){u=4*f.length,h=s._malloc(u),r.push(h);let y=h/4;for(let v=0;v<f.length;v++){if(typeof f[v]!="string")throw new TypeError(`tensor data at index ${v} is not a string`);s.HEAPU32[y++]=Re(f[v],r)}}else u=f.byteLength,h=s._malloc(u),r.push(h),s.HEAPU8.set(new Uint8Array(f.buffer,f.byteOffset,u),h)}let m=s.stackSave(),$=s.stackAlloc(4*l.length);try{let f=$/4;l.forEach(v=>s.HEAP32[f++]=v);let y=s._OrtCreateTensor(nr(d),h,u,$,l.length,ga(p));y===0&&xe(`Can't create tensor for input/output. session=${i}, index=${a}.`),t.push(y)}finally{s.stackRestore(m)}},an=async(e,t,r,i,a,n)=>{let s=Ce(),d=wt.get(e);if(!d)throw new Error(`cannot run inference. invalid session id: ${e}`);let l=d[0],p=d[1],h=d[2],u=d[3],m=d[4],$=d[5],f=t.length,y=i.length,v=0,x=[],_=[],S=[],k=[],T=s.stackSave(),I=s.stackAlloc(f*4),C=s.stackAlloc(f*4),M=s.stackAlloc(y*4),N=s.stackAlloc(y*4);try{s.jsepOnRunStart?.(l),[v,x]=kd(n);for(let q=0;q<f;q++)ha(r[q],_,k,e,t[q],m);for(let q=0;q<y;q++)ha(a[q],S,k,e,f+i[q],m);let W=I/4,J=C/4,K=M/4,X=N/4;for(let q=0;q<f;q++)s.HEAPU32[W++]=_[q],s.HEAPU32[J++]=p[t[q]];for(let q=0;q<y;q++)s.HEAPU32[K++]=S[q],s.HEAPU32[X++]=h[i[q]];if(u&&!$){let{handle:q,outputPreferredLocations:de,outputPreferredLocationsEncoded:se}=u;if(p.length!==f)throw new Error(`input count from feeds (${f}) is expected to be always equal to model's input count (${p.length}).`);for(let j=0;j<f;j++){let re=t[j];await s._OrtBindInput(q,p[re],_[j])!==0&&xe(`Can't bind input[${j}] for session=${e}.`)}for(let j=0;j<y;j++){let re=i[j];a[j]?.[3]?s._OrtBindOutput(q,h[re],S[j],0)!==0&&xe(`Can't bind pre-allocated output[${j}] for session=${e}.`):s._OrtBindOutput(q,h[re],0,se[re])!==0&&xe(`Can't bind output[${j}] to ${de[j]} for session=${e}.`)}wt.set(e,[l,p,h,u,m,!0])}let ie;u?ie=await s._OrtRunWithBinding(l,u.handle,y,M,v):ie=await s._OrtRun(l,C,I,f,N,y,M,v),ie!==0&&xe("failed to call OrtRun().");let ue=[];for(let q=0;q<y;q++){let de=s.HEAPU32[M/4+q];if(de===S[q]){ue.push(a[q]);continue}let se=s.stackSave(),j=s.stackAlloc(4*4),re=!1,O,U=0;try{s._OrtGetTensorData(de,j,j+4,j+8,j+12)!==0&&xe(`Can't access output tensor data on index ${q}.`);let te=j/4,fe=s.HEAPU32[te++];U=s.HEAPU32[te++];let be=s.HEAPU32[te++],ke=s.HEAPU32[te++],De=[];for(let me=0;me<ke;me++)De.push(s.HEAPU32[be/4+me]);s._OrtFree(be);let qe=De.reduce((me,Ie)=>me*Ie,1);O=Bt(fe);let Fe=u?.outputPreferredLocations[i[q]];if(O==="string"){if(Fe==="gpu-buffer"||Fe==="ml-tensor")throw new Error("String tensor is not supported on GPU.");let me=[],Ie=U/4;for(let rt=0;rt<qe;rt++){let mr=s.HEAPU32[Ie++],Tt=rt===qe-1?void 0:s.HEAPU32[Ie]-mr;me.push(s.UTF8ToString(mr,Tt))}ue.push([O,De,me,"cpu"])}else if(Fe==="gpu-buffer"&&qe>0){let me=s.jsepGetBuffer;if(!me)throw new Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');let Ie=me(U),rt=Vt(fe,qe);if(rt===void 0||!Ua(O))throw new Error(`Unsupported data type: ${O}`);re=!0,ue.push([O,De,{gpuBuffer:Ie,download:s.jsepCreateDownloader(Ie,rt,O),dispose:()=>{s._OrtReleaseTensor(de)}},"gpu-buffer"])}else if(Fe==="ml-tensor"&&qe>0){let me=s.jsepEnsureTensor;if(!me)throw new Error('preferredLocation "ml-tensor" is not supported without using WebNN.');if(Vt(fe,qe)===void 0||!Na(O))throw new Error(`Unsupported data type: ${O}`);let Ie=await me(U,fe,De,!1);re=!0,ue.push([O,De,{mlTensor:Ie,download:s.jsepCreateMLTensorDownloader(U,O),dispose:()=>{s.jsepReleaseTensorId(U),s._OrtReleaseTensor(de)}},"ml-tensor"])}else{let me=Fa(O),Ie=new me(qe);new Uint8Array(Ie.buffer,Ie.byteOffset,Ie.byteLength).set(s.HEAPU8.subarray(U,U+Ie.byteLength)),ue.push([O,De,Ie,"cpu"])}}finally{s.stackRestore(se),O==="string"&&U&&s._free(U),re||s._OrtReleaseTensor(de)}}return u&&!m&&(s._OrtClearBoundOutputs(u.handle),wt.set(e,[l,p,h,u,m,!1])),ue}finally{s.stackRestore(T),_.forEach(W=>s._OrtReleaseTensor(W)),S.forEach(W=>s._OrtReleaseTensor(W)),k.forEach(W=>s._free(W)),v!==0&&s._OrtReleaseRunOptions(v),x.forEach(W=>s._free(W))}},nn=e=>{let t=Ce(),r=wt.get(e);if(!r)throw new Error("invalid session id");let i=r[0],a=t._OrtEndProfiling(i);a===0&&xe("Can't get an profile file name."),t._OrtFree(a)},sn=e=>{let t=[];for(let r of e){let i=r[2];!Array.isArray(i)&&"buffer"in i&&t.push(i.buffer)}return t}}),$t,Ge,Wt,rr,ir,Fr,fa,Ur,zt,Rt,Jl,yh,wh,$h,_h,bh,vh,xh,Sh=F(()=>{"use strict";tt(),gh(),Mt(),Xr(),$t=()=>!!ge.wasm.proxy&&typeof document<"u",Wt=!1,rr=!1,ir=!1,Ur=new Map,zt=(e,t)=>{let r=Ur.get(e);r?r.push(t):Ur.set(e,[t])},Rt=()=>{if(Wt||!rr||ir||!Ge)throw new Error("worker not ready")},Jl=e=>{switch(e.data.type){case"init-wasm":Wt=!1,e.data.err?(ir=!0,fa[1](e.data.err)):(rr=!0,fa[0]()),Fr&&(URL.revokeObjectURL(Fr),Fr=void 0);break;case"init-ep":case"copy-from":case"create":case"release":case"run":case"end-profiling":{let t=Ur.get(e.data.type);e.data.err?t.shift()[1](e.data.err):t.shift()[0](e.data.out);break}default:}},yh=async()=>{if(!rr){if(Wt)throw new Error("multiple calls to 'initWasm()' detected.");if(ir)throw new Error("previous call to 'initWasm()' failed.");if(Wt=!0,$t())return new Promise((e,t)=>{Ge?.terminate(),xd().then(([r,i])=>{try{Ge=i,Ge.onerror=n=>t(n),Ge.onmessage=Jl,fa=[e,t];let a={type:"init-wasm",in:ge};Ge.postMessage(a),Fr=r}catch(a){t(a)}},t)});try{await Pa(ge.wasm),await Ja(ge),rr=!0}catch(e){throw ir=!0,e}finally{Wt=!1}}},wh=async e=>{if($t())return Rt(),new Promise((t,r)=>{zt("init-ep",[t,r]);let i={type:"init-ep",in:{epName:e,env:ge}};Ge.postMessage(i)});await en(ge,e)},$h=async e=>$t()?(Rt(),new Promise((t,r)=>{zt("copy-from",[t,r]);let i={type:"copy-from",in:{buffer:e}};Ge.postMessage(i,[e.buffer])})):Zr(e),_h=async(e,t)=>{if($t()){if(t?.preferredOutputLocation)throw new Error('session option "preferredOutputLocation" is not supported for proxy.');return Rt(),new Promise((r,i)=>{zt("create",[r,i]);let a={type:"create",in:{model:e,options:{...t}}},n=[];e instanceof Uint8Array&&n.push(e.buffer),Ge.postMessage(a,n)})}else return tn(e,t)},bh=async e=>{if($t())return Rt(),new Promise((t,r)=>{zt("release",[t,r]);let i={type:"release",in:e};Ge.postMessage(i)});rn(e)},vh=async(e,t,r,i,a,n)=>{if($t()){if(r.some(s=>s[3]!=="cpu"))throw new Error("input tensor on GPU is not supported for proxy.");if(a.some(s=>s))throw new Error("pre-allocated output tensor is not supported for proxy.");return Rt(),new Promise((s,d)=>{zt("run",[s,d]);let l=r,p={type:"run",in:{sessionId:e,inputIndices:t,inputs:l,outputIndices:i,options:n}};Ge.postMessage(p,sn(l))})}else return an(e,t,r,i,a,n)},xh=async e=>{if($t())return Rt(),new Promise((t,r)=>{zt("end-profiling",[t,r]);let i={type:"end-profiling",in:e};Ge.postMessage(i)});nn(e)}}),ma,ed,kh,gg=F(()=>{"use strict";tt(),Sh(),ee(),Ma(),Ed(),ma=(e,t)=>{switch(e.location){case"cpu":return[e.type,e.dims,e.data,"cpu"];case"gpu-buffer":return[e.type,e.dims,{gpuBuffer:e.gpuBuffer},"gpu-buffer"];case"ml-tensor":return[e.type,e.dims,{mlTensor:e.mlTensor},"ml-tensor"];default:throw new Error(`invalid data location: ${e.location} for ${t()}`)}},ed=e=>{switch(e[3]){case"cpu":return new Oe(e[0],e[2],e[1]);case"gpu-buffer":{let t=e[0];if(!Ua(t))throw new Error(`not supported data type: ${t} for deserializing GPU tensor`);let{gpuBuffer:r,download:i,dispose:a}=e[2];return Oe.fromGpuBuffer(r,{dataType:t,dims:e[1],download:i,dispose:a})}case"ml-tensor":{let t=e[0];if(!Na(t))throw new Error(`not supported data type: ${t} for deserializing MLTensor tensor`);let{mlTensor:r,download:i,dispose:a}=e[2];return Oe.fromMLTensor(r,{dataType:t,dims:e[1],download:i,dispose:a})}default:throw new Error(`invalid data location: ${e[3]}`)}},kh=class{async fetchModelAndCopyToWasmMemory(e){return $h(await Wa(e))}async loadModel(e,t){ot();let r;typeof e=="string"?r=await this.fetchModelAndCopyToWasmMemory(e):r=e,[this.sessionId,this.inputNames,this.outputNames]=await _h(r,t),et()}async dispose(){return bh(this.sessionId)}async run(e,t,r){ot();let i=[],a=[];Object.entries(e).forEach(u=>{let m=u[0],$=u[1],f=this.inputNames.indexOf(m);if(f===-1)throw new Error(`invalid input '${m}'`);i.push($),a.push(f)});let n=[],s=[];Object.entries(t).forEach(u=>{let m=u[0],$=u[1],f=this.outputNames.indexOf(m);if(f===-1)throw new Error(`invalid output '${m}'`);n.push($),s.push(f)});let d=i.map((u,m)=>ma(u,()=>`input "${this.inputNames[a[m]]}"`)),l=n.map((u,m)=>u?ma(u,()=>`output "${this.outputNames[s[m]]}"`):null),p=await vh(this.sessionId,a,d,s,l,r),h={};for(let u=0;u<p.length;u++)h[this.outputNames[s[u]]]=n[u]??ed(p[u]);return et(),h}startProfiling(){}endProfiling(){xh(this.sessionId)}}}),Th={};pr(Th,{OnnxruntimeWebAssemblyBackend:()=>Ia,initializeFlags:()=>Ca,wasmBackend:()=>Eh});var Ca,Ia,Eh,yg=F(()=>{"use strict";tt(),Sh(),gg(),Xr(),Ca=()=>{if((typeof ge.wasm.initTimeout!="number"||ge.wasm.initTimeout<0)&&(ge.wasm.initTimeout=0),ge.wasm.simd===!1&&console.warn('Deprecated property "env.wasm.simd" is set to false. non-SIMD build is no longer provided, and this setting will be ignored.'),typeof ge.wasm.proxy!="boolean"&&(ge.wasm.proxy=!1),typeof ge.wasm.trace!="boolean"&&(ge.wasm.trace=!1),typeof ge.wasm.numThreads!="number"||!Number.isInteger(ge.wasm.numThreads)||ge.wasm.numThreads<=0)if(typeof self<"u"&&!self.crossOriginIsolated)ge.wasm.numThreads=1;else{let e=typeof navigator>"u"?im("node:os").cpus().length:navigator.hardwareConcurrency;ge.wasm.numThreads=Math.min(4,Math.ceil((e||1)/2))}},Ia=class{async init(e){Ca(),await yh(),await wh(e)}async createInferenceSessionHandler(e,t){let r=new kh;return await r.loadModel(e,t),Promise.resolve(r)}},Eh=new Ia});tt();tt();tt();var wg="1.20.1";{let e=(yg(),Lr(Th)).wasmBackend;qt("webgpu",e,5),qt("webnn",e,5),qt("cpu",e,10),qt("wasm",e,10)}Object.defineProperty(ge.versions,"web",{value:wg,enumerable:!0});var Kt=class{constructor(t){this.factors=[];this.sign=1;this.n=t;let r=t;for(let i of[4,2,3,5])for(;r%i===0;)this.factors.push(i),r/=i;if(r!==1)throw new Error(`FFT size ${t} has a prime factor other than 2, 3, 5`);this.cos=new Float64Array(t),this.sin=new Float64Array(t);for(let i=0;i<t;i++)this.cos[i]=Math.cos(-2*Math.PI*i/t),this.sin[i]=Math.sin(-2*Math.PI*i/t);this.outRe=new Float64Array(t),this.outIm=new Float64Array(t)}transform(t,r,i=!1){this.sign=i?-1:1,this.rec(t,r,0,1,0,this.n,0),t.set(this.outRe),r.set(this.outIm)}rec(t,r,i,a,n,s,d){let l=this.outRe,p=this.outIm;if(s===1){l[n]=t[i],p[n]=r[i];return}let h=this.factors[d],u=s/h;for(let S=0;S<h;S++)this.rec(t,r,i+S*a,a*h,n+S*u,u,d+1);let m=this.n,$=m/s,f=this.cos,y=this.sin,v=this.sign;if(h===2){for(let S=0;S<u;S++){let k=n+S,T=k+u,I=S*$,C=f[I],M=v*y[I],N=l[T]*C-p[T]*M,W=l[T]*M+p[T]*C,J=l[k],K=p[k];l[k]=J+N,p[k]=K+W,l[T]=J-N,p[T]=K-W}return}if(h===4){for(let S=0;S<u;S++){let k=n+S,T=k+u,I=T+u,C=I+u,M=S*$,N=2*M,W=3*M,J=l[k],K=p[k],X=f[M],ie=v*y[M],ue=l[T]*X-p[T]*ie,q=l[T]*ie+p[T]*X;X=f[N],ie=v*y[N];let de=l[I]*X-p[I]*ie,se=l[I]*ie+p[I]*X;X=f[W],ie=v*y[W];let j=l[C]*X-p[C]*ie,re=l[C]*ie+p[C]*X,O=J+de,U=K+se,te=J-de,fe=K-se,be=ue+j,ke=q+re,De=ue-j,qe=q-re,Fe=v*qe,me=-v*De;l[k]=O+be,p[k]=U+ke,l[T]=te+Fe,p[T]=fe+me,l[I]=O-be,p[I]=U-ke,l[C]=te-Fe,p[C]=fe-me}return}let x=new Float64Array(h),_=new Float64Array(h);for(let S=0;S<u;S++){for(let k=0;k<h;k++){let T=n+k*u+S,I=k*S*$%m,C=f[I],M=v*y[I];x[k]=l[T]*C-p[T]*M,_[k]=l[T]*M+p[T]*C}for(let k=0;k<h;k++){let T=0,I=0;for(let C=0;C<h;C++){let M=C*k%h*(m/h)%m,N=f[M],W=v*y[M];T+=x[C]*N-_[C]*W,I+=x[C]*W+_[C]*N}l[n+k*u+S]=T,p[n+k*u+S]=I}}}};var Ch={inst_hq3:{file:"UVR-MDX-NET-Inst_HQ_3.onnx",label:"Inst HQ 3",nFft:6144,dimF:3072,dimT:256,hop:1024,compensate:1.022,primary:"instrumental"},kim_vocal2:{file:"Kim_Vocal_2.onnx",label:"Kim Vocal 2",nFft:7680,dimF:3072,dimT:256,hop:1024,compensate:1.009,primary:"vocals"},kara2:{file:"UVR_MDXNET_KARA_2.onnx",label:"Karaoke 2",nFft:5120,dimF:2048,dimT:256,hop:1024,compensate:1.065,primary:"instrumental"}};function _g(e){let t=new Float64Array(e);for(let r=0;r<e;r++)t[r]=.5-.5*Math.cos(2*Math.PI*r/e);return t}var ti=class{constructor(t){this.c=t;this.fft=new Kt(t.nFft),this.win=_g(t.nFft),this.re=new Float64Array(t.nFft),this.im=new Float64Array(t.nFft),this.chunk=t.hop*(t.dimT-1);let r=this.chunk+t.nFft,i=new Float64Array(r);for(let a=0;a<t.dimT;a++)for(let n=0;n<t.nFft;n++)i[a*t.hop+n]+=this.win[n]*this.win[n];this.envInv=i.map(a=>a>1e-10?1/a:0)}stft(t,r){let{nFft:i,dimF:a,dimT:n,hop:s}=this.c,d=i/2,l=this.chunk;for(let p=0;p<2;p++){let h=t[p];for(let u=0;u<n;u++){let m=u*s-d;for(let y=0;y<i;y++){let v=m+y;v<0?v=-v:v>=l&&(v=2*(l-1)-v),this.re[y]=h[v]*this.win[y],this.im[y]=0}this.fft.transform(this.re,this.im);let $=p*2*a*n,f=(p*2+1)*a*n;for(let y=0;y<a;y++)r[$+y*n+u]=this.re[y],r[f+y*n+u]=this.im[y]}}}istft(t){let{nFft:r,dimF:i,dimT:a,hop:n}=this.c,s=r/2,d=this.chunk+r,l=[];for(let p=0;p<2;p++){let h=new Float64Array(d),u=p*2*i*a,m=(p*2+1)*i*a;for(let f=0;f<a;f++){this.re.fill(0),this.im.fill(0);for(let v=0;v<i;v++)this.re[v]=t[u+v*a+f],this.im[v]=t[m+v*a+f];for(let v=1;v<s;v++)this.re[r-v]=this.re[v],this.im[r-v]=-this.im[v];this.im[0]=0,this.im[s]=0,this.fft.transform(this.re,this.im,!0);let y=f*n;for(let v=0;v<r;v++)h[y+v]+=this.re[v]/r*this.win[v]}let $=new Float32Array(this.chunk);for(let f=0;f<this.chunk;f++)$[f]=h[f+s]*this.envInv[f+s];l.push($)}return l}};function on(e){let t=atob(e),r=new Uint8Array(t.length);for(let n=0;n<t.length;n++)r[n]=t.charCodeAt(n);let i=new Int16Array(r.buffer),a=new Float32Array(i.length);for(let n=0;n<i.length;n++)a[n]=i[n]/32767;return a}var Ne=44100,Ke=new AudioContext({sampleRate:Ne,latencyHint:"interactive"}),Oh=Ke.createGain(),fr=Ke.createGain();Oh.connect(Ke.destination);fr.connect(Ke.destination);fr.gain.value=0;var z={running:!1,mode:"auto",using:"classic",cfg:null,session:null,sp:null,t0:0,L:new Float32Array(0),R:new Float32Array(0),len:0,done:0,segs:[],clock:{t:0,at:0,playing:!1},speed:0,busy:!1,loadingModel:!1,blocks:0,lastTap:-1,played:0,resets:0,lastError:""},cr=Ne/2,un=1024,Ih=512,Pe={buf:new Float32Array(0),t:0};function Ah(e,t){let r=t[0].length>>1;if(!r)return;let i=new Float32Array(r),a=t[0],n=t[1]??t[0];for(let p=0;p<r;p++)i[p]=(a[2*p]+a[2*p+1]+n[2*p]+n[2*p+1])/4;let s=Pe.t+Pe.buf.length/cr;if(!Pe.buf.length||Math.abs(e-s)>.05)Pe.buf=i,Pe.t=e;else{let p=new Float32Array(Pe.buf.length+r);p.set(Pe.buf),p.set(i,Pe.buf.length),Pe.buf=p}let d=[],l=0;for(;l+un<=Pe.buf.length;l+=Ih){let p=zs(Pe.buf.subarray(l,l+un),cr,.9,.006);d.push(p?Math.round(Rs(p.freq)*10)/10:null)}d.length&&ct({type:"pitch",t:Pe.t+un/2/cr,hop:Ih/cr,midi:d}),Pe.buf=Pe.buf.slice(l),Pe.t+=l/cr}var ct=e=>chrome.runtime.sendMessage({to:"page",msg:e}).catch(()=>{});function dn(e){z.resets++,Sg(),z.t0=e,z.len=0,z.done=0;for(let t of z.segs)t.src?.forEach(r=>r.stop());z.segs=[]}function bg(e,t,r){let i=z.t0+z.len/Ne;if((z.len===0||Math.abs(e-i)>.25)&&dn(e),z.len+t.length>z.L.length){let a=Math.max(z.L.length*2,z.len+t.length+Ne*30),n=new Float32Array(a),s=new Float32Array(a);n.set(z.L.subarray(0,z.len)),s.set(z.R.subarray(0,z.len)),z.L=n,z.R=s}z.L.set(t,z.len),z.R.set(r,z.len),z.len+=t.length}var ce=2048,pt=512,ln=new Float64Array(ce).map((e,t)=>.5-.5*Math.cos(2*Math.PI*t/ce)),hr=new Kt(ce),$e={inL:new Float32Array(ce),inR:new Float32Array(ce),fill:0,olaL:new Float64Array(ce*2),olaR:new Float64Array(ce*2),olaV:[new Float64Array(ce*2),new Float64Array(ce*2)]},vg=Math.round(150/Ne*ce),xg=Math.round(7e3/Ne*ce);function Sg(){$e.inL.fill(0),$e.inR.fill(0),$e.fill=0,$e.olaL.fill(0),$e.olaR.fill(0),$e.olaV.forEach(e=>e.fill(0))}function kg(e,t){let r=[],i=[],a=[],n=[],s=[new Float64Array(ce),new Float64Array(ce)],d=[new Float64Array(ce),new Float64Array(ce)];for(let l=0;l<e.length;l++){if($e.inL.copyWithin(0,1),$e.inR.copyWithin(0,1),$e.inL[ce-1]=e[l],$e.inR[ce-1]=t[l],++$e.fill<pt)continue;$e.fill=0;for(let f=0;f<ce;f++)s[0][f]=$e.inL[f]*ln[f],s[1][f]=$e.inR[f]*ln[f],d[0][f]=0,d[1][f]=0;hr.transform(s[0],d[0]),hr.transform(s[1],d[1]);let p=new Float64Array(ce),h=new Float64Array(ce);for(let f=vg;f<=xg;f++){let y=s[0][f],v=d[0][f],x=s[1][f],_=d[1][f],S=y*y+v*v,k=x*x+_*_,T=Math.hypot(y*x+v*_,v*x-y*_),I=S+k>1e-12?2*T/(S+k):0,C=Math.min(1,Math.max(0,(I-.55)/.4))**2,M=(y+x)/2*C,N=(v+_)/2*C;p[f]=M,h[f]=N,f>0&&(p[ce-f]=M,h[ce-f]=-N)}let u=[new Float64Array(ce),new Float64Array(ce)],m=[new Float64Array(ce),new Float64Array(ce)],$=[p.slice(),h.slice()];for(let f=0;f<ce;f++)u[0][f]=s[0][f]-p[f],u[1][f]=d[0][f]-h[f],m[0][f]=s[1][f]-p[f],m[1][f]=d[1][f]-h[f];hr.transform(u[0],u[1],!0),hr.transform(m[0],m[1],!0),hr.transform($[0],$[1],!0);for(let f=0;f<ce;f++){let y=ln[f]/ce/1.5;$e.olaL[f]+=u[0][f]*y,$e.olaR[f]+=m[0][f]*y,$e.olaV[0][f]+=$[0][f]*y}for(let f=0;f<pt;f++)r.push($e.olaL[f]),i.push($e.olaR[f]),a.push($e.olaV[0][f]),n.push($e.olaV[0][f]);$e.olaL.copyWithin(0,pt),$e.olaR.copyWithin(0,pt),$e.olaV[0].copyWithin(0,pt),$e.olaL.fill(0,ce*2-pt),$e.olaR.fill(0,ce*2-pt),$e.olaV[0].fill(0,ce*2-pt)}return{inst:[Float32Array.from(r),Float32Array.from(i)],voc:[Float32Array.from(a),Float32Array.from(n)]}}async function zh(e,t,r){ge.wasm.wasmPaths=chrome.runtime.getURL("ort/"),ge.wasm.numThreads=self.crossOriginIsolated?Math.min(8,navigator.hardwareConcurrency||2):1,ge.webgpu.powerPreference="high-performance";let i=await fetch(e),a;if(i.ok)a=await i.arrayBuffer();else{let s=await(await fetch(e+".parts.json")).json(),d=new Uint8Array(s.size),l=0;for(let p=0;p<s.parts;p++){let h=new Uint8Array(await(await fetch(`${e}.part${p}`)).arrayBuffer());d.set(h,l),l+=h.length}a=d.buffer}let n="gpu"in navigator?["webgpu","wasm"]:["wasm"];for(let s of n)try{z.session=await Qr.create(new Uint8Array(a),{executionProviders:[s]});break}catch{}z.cfg=Ch[r],z.sp=new ti(z.cfg)}async function Tg(){if(!(z.busy||!z.running)){z.busy=!0;try{for(;;){if(z.using==="classic"){if(z.len-z.done<2048)break;let T=z.done,{inst:I,voc:C}=kg(z.L.subarray(z.done,z.len),z.R.subarray(z.done,z.len));z.done=z.len;let M=ce-pt;if(I[0].length){let N=z.t0+(z.len-I[0].length-M)/Ne;z.segs.push({t:N,inst:I,voc:C}),Ah(N,C)}break}let e=z.cfg,t=z.sp,r=t.chunk,i=e.nFft/2,a=r-2*i;if(z.len<z.done+a+i)break;let n=z.done-i,s=k=>{let T=new Float32Array(r);for(let I=0;I<r;I++){let C=n+I;T[I]=C>=0&&C<z.len?k[C]:0}return T},d=s(z.L),l=s(z.R),p=new Float32Array(4*e.dimF*e.dimT),h=performance.now();t.stft([d,l],p);let u=await z.session.run({[z.session.inputNames[0]]:new Oe("float32",p,[1,4,e.dimF,e.dimT])}),[m,$]=t.istft(u[z.session.outputNames[0]].data),f=(performance.now()-h)/1e3;z.speed=a/Ne/f;let y=[m.subarray(i,i+a),$.subarray(i,i+a)].map(k=>k.map(T=>T*e.compensate)),x=[d.subarray(i,i+a),l.subarray(i,i+a)].map((k,T)=>k.map((I,C)=>I-y[T][C])),_=e.primary==="instrumental"?y:x,S=e.primary==="instrumental"?x:y;z.segs.push({t:z.t0+z.done/Ne,inst:_,voc:S}),Ah(z.t0+z.done/Ne,S),z.done+=a,z.mode==="auto"&&z.speed<1.05&&(z.using="classic",ct({type:"status",state:"fallback",mode:"classic",speed:z.speed}))}}catch(e){z.lastError=String(e?.message??e),ct({type:"status",state:"error",message:z.lastError})}finally{z.busy=!1}}}var pn=()=>z.clock.t+(z.clock.playing?(performance.now()-z.clock.at)/1e3:0);function Eg(){if(!z.running||!z.clock.playing)return;let e=pn();for(let t of z.segs){if(t.src)continue;let r=t.inst[0].length/Ne;if(t.t+r<e)continue;let i=Math.max(0,e-t.t),a=Ke.currentTime+Math.max(0,t.t-e)-(Ke.outputLatency||0),n=(s,d)=>{let l=Ke.createBuffer(2,s[0].length,Ne);l.copyToChannel(s[0],0),l.copyToChannel(s[1],1);let p=Ke.createBufferSource();return p.buffer=l,p.connect(d),p.start(Math.max(Ke.currentTime,a),i),p};t.src=[n(t.inst,Oh),n(t.voc,fr)],z.played++}z.segs=z.segs.filter(t=>t.t+t.inst[0].length/Ne>e-2)}function Rh(){for(let e of z.segs)e.src?.forEach(t=>{try{t.stop()}catch{}}),e.src=void 0}setInterval(()=>{if(Eg(),z.running){let e=z.t0+z.done/Ne-pn();z.using==="ai"&&z.mode==="auto"&&z.clock.playing&&e<1&&(z.using="classic",ct({type:"status",state:"fallback",mode:"classic",speed:z.speed,message:"too slow for the AI model"})),ct({type:"status",state:z.loadingModel?"loading":"running",mode:z.using,speed:z.speed,buffered:e,diag:{blocks:z.blocks,lastTap:z.lastTap,segments:z.segs.length,played:z.played,resets:z.resets,clock:z.clock.t,playing:z.clock.playing,ctx:Ke.state,err:z.lastError}})}},250);chrome.runtime.onMessage.addListener(e=>{if(e?.to!=="engine")return;let t=e.msg;if(t.type==="tap"){if(!z.running)return;z.blocks++,z.lastTap=t.t,bg(t.t,on(t.l),on(t.r)),Tg()}else if(t.type==="start")z.running=!0,Pe.buf=new Float32Array(0),z.blocks=0,z.played=0,z.resets=0,z.lastError="",z.mode=t.mode,fr.gain.value=t.vocal,Ke.resume(),dn(0),t.mode==="classic"?z.using="classic":(z.using="classic",ct({type:"status",state:"loading"}),z.loadingModel=!0,zh(t.modelUrl,t.ortBase,t.model).finally(()=>z.loadingModel=!1).then(()=>{z.using="ai",z.done=Math.max(0,z.len-z.cfg.nFft/2)}).catch(r=>ct({type:"status",state:"fallback",mode:"classic",message:String(r?.message??r)})));else if(t.type==="clock")(Math.abs(t.t-pn())>.5||t.playing!==z.clock.playing)&&Rh(),z.clock={t:t.t,at:performance.now(),playing:t.playing};else if(t.type==="setmode"){let r=t,i=r.mode;if(z.mode=i,i==="classic"&&z.using==="ai")z.using="classic",z.done=z.len;else if(i==="ai"&&z.using==="classic"){let a=()=>{z.mode==="ai"&&(z.using="ai",z.done=Math.max(0,z.len-z.cfg.nFft/2))};z.session?a():!z.loadingModel&&r.modelUrl&&(z.loadingModel=!0,ct({type:"status",state:"loading"}),zh(r.modelUrl,r.ortBase,r.model).finally(()=>z.loadingModel=!1).then(a).catch(n=>ct({type:"status",state:"fallback",mode:"classic",message:String(n?.message??n)})))}}else t.type==="vocal"?fr.gain.setTargetAtTime(t.level,Ke.currentTime,.03):t.type==="stop"&&(z.running=!1,Rh(),dn(0))});
/*! Bundled license information:

onnxruntime-web/dist/ort.webgpu.bundle.min.mjs:
  (*!
   * ONNX Runtime Web v1.20.1
   * Copyright (c) Microsoft Corporation. All rights reserved.
   * Licensed under the MIT License.
   *)

onnxruntime-web/dist/ort.webgpu.bundle.min.mjs:
  (**
   * @license
   * Copyright 2021 Google LLC. All Rights Reserved.
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   * =============================================================================
   *)
  (**
   * @license
   * Copyright 2020 Google LLC. All Rights Reserved.
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   * =============================================================================
   *)
  (**
   * @license
   * Copyright 2019 Google LLC. All Rights Reserved.
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   * =============================================================================
   *)
*/
